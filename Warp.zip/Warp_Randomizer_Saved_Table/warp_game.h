#ifndef WARP_GAME_H
#define WARP_GAME_H
#include <stdint.h>
/* Frozen graph: 56 identity + 532 * 2 destination indexes + 4 CRC. */
#define WARP_RANDO_SAVE_BYTES 1124u
/* Engine adapter; this header does not expose the solver internals. */
void WarpRando_NewGame(void (*success)(void), void (*failure)(void));
void WarpRando_Continue(const uint8_t *save, void (*success)(void), void (*failure)(void));
int WarpRando_Save(uint8_t *save);
int WarpRando_Resolve(int sg, int sm, int sw, uint16_t x, uint16_t y, uint8_t elevation, int8_t *dg,
                      int8_t *dm, int8_t *dw);
/* Narrow, active-randomizer League compatibility hooks. */
void WarpRando_Arrival(void);
void WarpRando_MapLoaded(void);
void WarpRando_PrepareMap(void);
/* Native script specials for the early plotless reward chain. */
uint16_t WarpRando_DevonReward(void);
void WarpRando_RustboroAfterBattle(void);
void WarpRando_WeatherReward(void);
void WarpRando_VolcanoReward(void);
/* Intro hooks own no engine task: naming screens may reset the task array. */
void WarpRando_IntroStart(void);
void WarpRando_IntroFrameBegin(void);
void WarpRando_IntroPump(void);
void WarpRando_IntroHide(void);
void WarpRando_IntroResume(void);
struct WarpRandoMetrics
{
    uint32_t pumps, cpuTicks, maxStepTicks, maxPumpTicks, maxSceneTicks, busyFrames;
};
const struct WarpRandoMetrics *WarpRando_Metrics(void);
#endif
