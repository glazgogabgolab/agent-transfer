"""Strict normalized graph -> deterministic C99 data; Python standard library only."""

import argparse, hashlib, json, pathlib, sys

NONE = 65535


def fail(message):
    raise ValueError(message)


def integer(v, lo, hi, label):
    if type(v) is not int or not lo <= v <= hi:
        fail(f"{label}: expected integer {lo}..{hi}, got {v!r}")
    return v


def key(v):
    if not isinstance(v, list) or len(v) != 3:
        fail(f"bad triple: {v!r}")
    return [integer(x, 0, 127, "triple") for x in v]


def normalize(d):
    if d.get("schema") != 2:
        fail("schema must be 2")
    nodes = d["nodes"]
    n = len(nodes)
    integer(n, 1, 1024, "node count")
    ids = [x["name"] for x in nodes]
    if len(set(ids)) != n or any((not isinstance(x, str) or not x for x in ids)):
        fail("duplicate/invalid node name")
    if ids != sorted(ids):
        fail("nodes must be sorted by name")
    ni = {s: i for i, s in enumerate(ids)}
    caps = d["capabilities"]
    integer(len(caps), 0, 32, "capabilities")
    if caps != sorted(set(caps)) or any((not isinstance(x, str) for x in caps)):
        fail("capabilities must be unique sorted strings")
    ci = {s: i for i, s in enumerate(caps)}

    def ref(name):
        if name not in ni:
            fail(f"unknown node: {name}")
        return ni[name]

    def cap(name):
        if name is None:
            return NONE
        if name not in ci:
            fail(f"unknown requirement: {name}")
        return ci[name]

    outnodes = []
    seen = set()
    triggers = {}
    for v in nodes:
        k = tuple(key(v["id"]))
        tr = tuple(key(v["trigger"]))
        if k in seen:
            fail("duplicate physical endpoint")
        seen.add(k)
        if type(v["active"]) is not bool:
            fail("active must be Boolean")
        tags = integer(v.get("tags", 0), 0, 3, "tags")
        r = ref(v["rep"])
        if nodes[r]["rep"] != v["rep"]:
            fail("representative is not canonical")
        if nodes[r]["active"] != v["active"] or nodes[r].get("tags", 0) != tags:
            fail("inconsistent group participation/tags")
        if tr in triggers and triggers[tr] != v["active"]:
            fail("trigger shared by participating and excluded events")
        triggers[tr] = v["active"]
        outnodes.append([list(k), list(tr), r, int(v["active"]), tags])
    edges = sorted(
        set(((ref(e["from"]), ref(e["to"]), cap(e.get("requires"))) for e in d["edges"]))
    )
    integer(len(edges), 0, 65534, "edges")
    req = []
    rules = []
    for r in sorted(d["rules"], key=lambda r: json.dumps(r, sort_keys=True)):
        grant = cap(r["grant"])
        if grant == NONE:
            fail("rule needs grant")
        start = len(req)
        for q in r["requires"]:
            if set(q) == {"location"}:
                req.append([ref(q["location"]), 0])
            elif set(q) == {"capability"}:
                if q["capability"] is None:
                    fail("capability requirement cannot be null")
                req.append([cap(q["capability"]), 1])
            else:
                fail(f"bad rule requirement {q}")
        rules.append([grant, start, len(req) - start])
    for name, value in [
        ("requirements", len(req)),
        ("rules", len(rules)),
        ("goals", len(d["goals"])),
    ]:
        integer(value, 0, 65534, name)
    goals = sorted(set((ref(s) for s in d["goals"])))
    if not goals:
        fail("at least one explicit objective is required")
    digest = hashlib.sha256(
        json.dumps(d, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return dict(
        nodes=outnodes,
        edges=edges,
        rules=rules,
        reqs=req,
        goals=goals,
        root=ref(d["root"]),
        caps=len(caps),
        sha256=digest,
    )


def emit(d):
    x = normalize(d)
    n = len(x["nodes"])

    def arr(ctype, name, rows):
        rows = list(rows)
        return (
            f"static const {ctype} {name}[{max(1, len(rows))}] = {{\n"
            + "".join(
                (
                    "    " + s + ",\n"
                    for s in rows or (["{0}"] if ctype.startswith("struct") else ["0"])
                )
            )
            + "};\n"
        )

    def triple(k):
        return "{" + ",".join(map(str, k)) + "}"

    out = '#ifndef WR_GENERATED_H\n#define WR_GENERATED_H\n#include "warp_rando.h"\n'
    out += f"/* schema 2; SHA-256 {x['sha256']}; no timestamp or paths */\n"
    out += arr(
        "struct WrNode",
        "wr_nodes",
        (
            "{" + triple(a) + "," + triple(b) + f",{r},{active},{tags}" + "}"
            for a, b, r, active, tags in x["nodes"]
        ),
    )
    for suffix, edges in [
        ("", x["edges"]),
        ("_reverse", sorted(((b, a, c) for a, b, c in x["edges"]))),
    ]:
        bounds = [sum((a < i for a, b, c in edges)) for i in range(n + 1)]
        out += arr(
            "struct WrEdge", "wr_edges" + suffix, ("{" + f"{b},{c}" + "}" for a, b, c in edges)
        )
        out += arr("uint16_t", "wr_bounds" + suffix, map(str, bounds))
    for typ, name in [("WrRule", "rules"), ("WrReq", "reqs")]:
        out += arr(
            "struct " + typ, "wr_" + name, ("{" + ",".join(map(str, row)) + "}" for row in x[name])
        )
    out += arr("uint16_t", "wr_goals", map(str, x["goals"]))
    digest = ",".join((str(b) for b in bytes.fromhex(x["sha256"])))
    out += emit_index(d)
    out += "static const struct WrGraph wr_graph = {\n"
    out += f"    {n},{x['caps']},{len(x['edges'])},{len(x['rules'])},{len(x['reqs'])},{len(x['goals'])},{x['root']},\n"
    out += "    wr_nodes,wr_edges,wr_edges_reverse,wr_bounds,wr_bounds_reverse,wr_rules,wr_reqs,wr_goals,\n"
    out += "    {" + digest + "}, &wr_index\n};\n"
    out += emit_routes(d)
    out += "#endif\n"
    return out


def emit_routes(data):
    """Keep the source signature gate and graph in ONE fingerprinted input."""
    nodes = {tuple(v["id"]): v for v in data["nodes"] if v["active"]}
    routes = data.get("source_routes", [])
    counts = data.get("target_map_counts", [])
    if not counts or len(counts) > 128:
        fail("target needs 1..128 map groups")
    for count in counts:
        integer(count, 1, 128, "target map count")
    seen = set()
    rows = []
    for route in sorted(routes, key=lambda r: r["source"]):
        source = tuple(key(route["source"]))
        expected = key(route["expected"])
        trigger = key(route["trigger"])
        if source in seen or source not in nodes:
            fail("duplicate or nonparticipating source route")
        if trigger != nodes[source]["trigger"]:
            fail("source route does not match graph trigger")
        for group, map_id, warp in (source, expected):
            if group >= len(counts) or map_id >= counts[group]:
                fail("source signature exceeds target map counts")
        seen.add(source)
        x = integer(route["x"], 0, 65535, "source x")
        y = integer(route["y"], 0, 65535, "source y")
        elevation = integer(route["elevation"], 0, 255, "elevation")
        triples = ",".join(("{" + ",".join(map(str, k)) + "}" for k in (source, expected, trigger)))
        rows.append("    {" + triples + f",{x},{y},{elevation}" + "},")
    if seen != set(nodes):
        fail("source routes must cover every participating physical endpoint")
    return (
        "static const struct WrSourceRoute wr_source_routes[] = {\n"
        + "\n".join(rows or ["    {{0,0,0},{0,0,0},{0,0,0},0,0,0},"])
        + "\n};\n"
        + "#define WR_SOURCE_COUNT "
        + str(len(rows))
        + "u\n"
        + "static const uint8_t wr_target_map_counts[] = {"
        + ",".join(map(str, counts))
        + "};\n"
    )


def build_index(data):
    x = normalize(data)
    n = len(x["nodes"])
    sys.setrecursionlimit(max(3000, n * 3))
    adjacency = [[] for _ in range(n)]
    for source, target, capability in x["edges"]:
        if capability == NONE:
            adjacency[source].append(target)
    index = [-1] * n
    low = [0] * n
    stack = []
    on_stack = [False] * n
    components = []

    def visit(node):
        index[node] = low[node] = visit.clock
        visit.clock += 1
        stack.append(node)
        on_stack[node] = True
        for target in adjacency[node]:
            if index[target] < 0:
                visit(target)
                low[node] = min(low[node], low[target])
            elif on_stack[target]:
                low[node] = min(low[node], index[target])
        if low[node] == index[node]:
            row = []
            while True:
                target = stack.pop()
                on_stack[target] = False
                row.append(target)
                if target == node:
                    break
            components.append(sorted(row))

    visit.clock = 0
    for node in range(n):
        if index[node] < 0:
            visit(node)
    components.sort(key=lambda row: row[0])
    node_component = [0] * n
    for component, row in enumerate(components):
        for node in row:
            node_component[node] = component
    count = len(components)
    if count > 400:
        fail("more than 400 unconditional regions; increase the runtime limit deliberately")
    words = (count + 31) // 32
    dag = [set() for _ in range(count)]
    for source in range(n):
        for target in adjacency[source]:
            a, b = node_component[source], node_component[target]
            if a != b:
                dag[a].add(b)

    def closures(graph):
        memo = {}

        def walk(component):
            if component in memo:
                return memo[component]
            bits = 1 << component
            for target in sorted(graph[component]):
                bits |= walk(target)
            memo[component] = bits
            return bits

        return [walk(component) for component in range(count)]

    forward = closures(dag)
    reverse_dag = [set() for _ in range(count)]
    for source, row in enumerate(dag):
        for target in row:
            reverse_dag[target].add(source)
    reverse = closures(reverse_dag)
    conditional = sorted(
        set(
            (node_component[a], node_component[b], cap)
            for a, b, cap in x["edges"]
            if cap != NONE and node_component[a] != node_component[b]
        )
    )
    active = sorted((node_component[node], node) for node, row in enumerate(x["nodes"]) if row[3])

    def offsets(rows, key, count):
        result = []
        position = 0
        for component in range(count):
            result.append(position)
            while position < len(rows) and key(rows[position]) == component:
                position += 1
        result.append(position)
        return result

    reverse_conditional = sorted(conditional, key=lambda row: (row[1], row[0], row[2]))
    capability_conditional = sorted(conditional, key=lambda row: (row[2], row[0], row[1]))
    return {
        "normalized": x,
        "node_component": node_component,
        "components": count,
        "words": words,
        "forward": forward,
        "reverse": reverse,
        "active_nodes": [node for _, node in active],
        "active_offsets": offsets(active, lambda row: row[0], count),
        "forward_conditional": conditional,
        "forward_offsets": offsets(conditional, lambda row: row[0], count),
        "reverse_conditional": reverse_conditional,
        "reverse_offsets": offsets(reverse_conditional, lambda row: row[1], count),
        "capability_conditional": capability_conditional,
        "capability_offsets": offsets(capability_conditional, lambda row: row[2], x["caps"]),
    }


def emit_index(data):
    """All immutable discovery happens here, never behind a running intro."""
    built = build_index(data)
    x = built["normalized"]
    n = len(x["nodes"])

    def arr(ctype, name, values):
        values = list(values)
        empty = "{0}" if ctype.startswith("struct") else "0"
        return (
            f"static const {ctype} idx_{name}[{max(1,len(values))}] = {{\n"
            + "".join("    " + str(v) + ",\n" for v in values or [empty])
            + "};\n"
        )

    def offsets(groups):
        result = [0]
        flat = []
        for group in groups:
            flat.extend(group)
            result.append(len(flat))
        return result, flat

    active_position = {node: i for i, node in enumerate(built["active_nodes"])}
    representatives = [i for i, row in enumerate(x["nodes"]) if row[3] and row[2] == i]
    aliases = [[] for _ in range(n)]
    component_reps = [[] for _ in range(built["components"])]
    ordinals = [NONE] * n
    for node, row in enumerate(x["nodes"]):
        if row[3]:
            aliases[row[2]].append(active_position[node])
    for ordinal, node in enumerate(representatives):
        ordinals[node] = ordinal
        component_reps[built["node_component"][node]].append(ordinal)
    alias_offsets, alias_indices = offsets(aliases)
    rep_offsets, rep_indices = offsets(component_reps)
    groups = {}
    for node, row in enumerate(x["nodes"]):
        if row[3]:
            groups.setdefault(tuple(row[1]), []).append(node)
    emit_nodes = []
    emit_indices = [NONE] * n
    for trigger, members in sorted(groups.items()):
        if len({x["nodes"][v][2] for v in members}) != 1:
            fail("one trigger belongs to different representatives")
        for v in members:
            emit_indices[v] = len(emit_nodes)
        emit_nodes.append(min(members))
    arrays = {
        "node_component": built["node_component"],
        "active_offsets": built["active_offsets"],
        "active_nodes": built["active_nodes"],
        "representatives": representatives,
        "alias_offsets": alias_offsets,
        "alias_indices": alias_indices,
        "ordinals": ordinals,
        "rep_offsets": rep_offsets,
        "rep_indices": rep_indices,
        "emit_nodes": emit_nodes,
        "emit_indices": emit_indices,
        "forward_offsets": built["forward_offsets"],
        "reverse_offsets": built["reverse_offsets"],
        "capability_offsets": built["capability_offsets"],
    }
    out = "".join(arr("uint16_t", k, v) for k, v in arrays.items())
    for direction in ["forward", "reverse"]:
        values = [
            f"0x{(bits>>(32*word))&0xffffffff:08x}u"
            for bits in built[direction]
            for word in range(built["words"])
        ]
        out += arr("uint32_t", direction, values)
    for order in ["forward", "reverse", "capability"]:
        out += arr(
            "struct WrConditional",
            order + "_conditional",
            ("{" + ",".join(map(str, row)) + "}" for row in built[order + "_conditional"]),
        )
    out += "static const struct WrIndex wr_index = {\n"
    out += f"{n},{built['components']},{built['words']},{len(built['active_nodes'])},{len(built['forward_conditional'])},{len(representatives)},{(len(representatives)+31)//32},{len(emit_nodes)},\n"
    out += "idx_node_component,idx_active_offsets,idx_active_nodes,\n"
    out += "idx_representatives,idx_alias_offsets,idx_alias_indices,idx_ordinals,idx_rep_offsets,idx_rep_indices,idx_emit_nodes,idx_emit_indices,\n"
    out += "idx_forward,idx_reverse,idx_forward_offsets,idx_forward_conditional,idx_reverse_offsets,idx_reverse_conditional,idx_capability_offsets,idx_capability_conditional\n};\n"
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", default="world.json")
    parser.add_argument("output", nargs="?", default="warp_data.h")
    args = parser.parse_args()
    try:
        text = emit(json.loads(pathlib.Path(args.input).read_text()))
        destination = pathlib.Path(args.output)
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_text(text)
        temporary.replace(destination)
        print("Wrote", destination)
    except (ValueError, KeyError, TypeError) as error:
        parser.exit(1, f"error: {error}\n")
