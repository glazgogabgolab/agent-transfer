# Understanding and working on the code

Start with INTRODUCTION.md. Then read `step_inner` in warp_rando.c alongside the phase explanation below. The small functions around it implement graph operations; warp_game.c decides when that portable job gets CPU time.

This folder is a replacement development workspace. It does not depend on the old archive's folders. Keep the original ZIP as history; do not combine its experiment files with this version.

## Run the host checks

Use Python 3.10+ and a C99 compiler named `cc` (or set `CC`). No Python packages are required. From this folder:

```sh
python3 build.py
python3 test.py
```

The first command checks world.json and writes warp_data.h. The second compiles temporary C executables, runs synthetic cases and the bundled-world sample, and writes verification.json. It creates temporary files with Python's temporary-directory facility and cleans them on exit. Each compilation/executable invocation has a 45-second timeout; tests are divided into small cases rather than one unbounded experiment.

On a compiler/platform supporting GCC-compatible sanitizers:

```sh
SANITIZE=1 python3 test.py
```

That command uses AddressSanitizer and UndefinedBehaviorSanitizer. The harness disables LeakSanitizer's exit inspection because the original restricted host could not enumerate processes; the portable core itself allocates no heap memory. This does not test the target adapter's allocations.

A returned status of zero means the tests passed. Merely finding verification.json does not mean a complete suite passed: the file records executed cases even if a later assertion failed. Read the test process's final result.

The compiler can also take explicit paths:

```sh
python3 build.py world.json warp_data.h
```

Do not hand-edit warp_data.h. It is a mechanical translation of the one maintained input.

## The data, with a concrete example

A world.json node has these fields:

| Field | Meaning |
|---|---|
| `name` | Human-searchable stable identifier, usually `E,group,map,warp` |
| `label` | Original descriptive map/door name, where supplied; for reading, not routing |
| `id` | Physical endpoint triple: map group, map index, warp-event index |
| `trigger` | Reference lookup key, usually the source's original destination |
| `rep` | Name of the representative for this entrance group |
| `active` | Whether this group participates in randomized pairing |
| `tags` | Bit 1: needs-return; bit 2: no-return; their forbidden combination is checked |

For example, a grouped doorway can have two nodes with different `id` values and the same `rep`. Both physical events must lead to the same chosen partner. The representative is a real endpoint, not a separate invented room.

An edge resembles:

```json
{"from": "E,0,0,0", "to": "E,0,0,1", "requires": null}
```

This example illustrates the schema; it is not an instruction to add that route. `null` means unconditional travel. A capability name means the edge opens after earning that capability. The reverse direction needs its own edge. Do not turn every edge into a two-way edge merely because most walking feels reversible.

A rule resembles:

```json
{
  "grant": "SURF",
  "requires": [
    {"location": "BADGE_LOCATION"},
    {"location": "HM_LOCATION"}
  ]
}
```

These illustrative names would need real declarations. Requirements within a rule are ANDed. Multiple rules granting the same capability provide alternatives: either rule is sufficient. A requirement can name an already earned `capability` instead of a `location`, supporting chains. Empty requirements deliberately mean an unconditional grant.

Rule labels and granted capability names are different namespaces in the original source. In this normalized model, `HOENN_FLASH_1` remains a declared condition without a provider, while the actual Flash rule grants `HOENN_FLASH`. `WEATHER_INSTITUTE` also has no provider. Their closure is deliberate retained policy. Do not silently strip suffixes or open these edges.

Excluded nodes are still in the graph. Excluding a warp from randomization does not remove its walking routes or certify that all of its vanilla transitions are modeled. The inherited fixed edges contain the resolvable excluded travel; unresolved destinations remain a limitation.

The `source_routes` section adds actual target event signatures: source triple, expected vanilla destination, reference trigger, x, y and elevation. This is the bridge between the target's event and the reference model. `target_map_counts` bounds map lookup before indexing the engine's map tables.

## What build.py does

`normalize` checks names, numeric limits, group consistency, participation collisions, capability references, rules and goals. It replaces names with small numeric indexes. Sorted nodes and canonical rule/edge ordering make the output deterministic.

`emit` writes static C arrays. Forward adjacency lets traversal quickly find outgoing edges. Reverse adjacency lets the same traversal find routes back to the root. `bounds[v]` through `bounds[v+1]` describe node v's slice of an edge array; this is just a compact substitute for an array of lists.

`emit_routes` verifies that the source table covers every participating physical node exactly once and agrees with its trigger. It also checks coordinate ranges and map-count bounds. It cannot inspect collision tiles or infer what a script does.

The SHA-256 fingerprint covers a canonical JSON serialization of the entire input, including source signatures, map counts and provenance. Whitespace and object-key order do not affect it. Array order and explanatory content can affect it. This intentionally errs toward rejecting an old save after an input edit. It does not automatically hash C code: bump the local algorithm version when algorithm semantics change.

## Reading the C types

Most functions take a pointer to immutable `WrGraph`, mutable `WrWork`, or published `WrActive`.

| Type | Lifetime and role |
|---|---|
| `WrGraph` | Read-only ROM description, generated from world.json |
| `WrWork` | Temporary indexed constructor state |
| `WrActive` | Complete accepted mapping plus identity; lives while playing |
| `WrVerifyWork` | Separate slow node-level validator workspace, used by host tests |
| `WrIndex` | ROM indexes and unconditional reachability prepared by Python |
| `WrJob` | Continuation record: current attempt, RNG state, remaining pool and pointers |
| `WrIdentity` | Seed, algorithm, ruleset and input fingerprint |
| `WrRecord` | One trigger triple and its landing triple |

The workspace is deliberately explicit. There are no hidden allocations in the portable core. The adapter allocates it when starting the intro or loading screen and frees it on completion or failure. The active table remains allocated in EWRAM. Do not put WrWork on the GBA stack.

`WR_NONE` is the value 65535, meaning “no partner/destination/condition.” It is different from index zero, which is valid. The maintained limits are 1,024 nodes, 400 unconditional components and 32 capabilities, enough for the frozen 879-node/16-capability model. Widening them changes memory use and needs a new target budget check.

Within traversal helpers, `i` and `j` are indexes, `v` is a vertex, `t` is a destination, and `r` is often a representative or rule. These are local loop names, not additional conceptual state.

## Why there are two headers

A C header declares how another file may call a function. The `.c` file defines what that function does. A declaration does not need to share the implementation file's name: the earlier `WarpRando_*` declarations in warp_rando.h were legal. That header simply combined two interfaces to save a file.

Here `warp_rando.h` describes the portable solver. `warp_game.h` declares the engine adapter implemented by warp_game.c. Engine call sites include the latter. warp_game.c includes both because it translates between them. This boundary is worth one extra small file.

## The compiled graph index

`build_index` groups endpoints that can reach one another using unconditional edges into strongly connected components. This does **not** mean one component per map: ledges can separate areas on one map. It keeps conditional edges separate. It then precomputes the forward and reverse unconditional closure of each component.

A bitset is simply an array of 32-bit words. Bit k says whether component k belongs to a set. OR combines sets, AND intersects them, and `reached & ~home` identifies places that can be entered but cannot return. `__builtin_ctz` locates the lowest set bit; clearing `bits & (bits - 1)` removes that bit. These loops only call ctz when the word is nonzero.

Other generated arrays answer practical questions directly: which physical sources belong to a representative, which representatives belong to a component, and which sorted physical nodes supply unique output triggers. Offsets mark each list's beginning and end. This avoids repeatedly searching all nodes or sorting output on the GBA.

`wr_begin` trusts this immutable, compiler-produced index after checking identity and capacity. It does not validate arbitrary user-built C pointer graphs. The checked generic `wr_graph_check`, `wr_emit`, `wr_validate` and `wr_publish` remain available for independent host checks and externally supplied tables. Do not expose the trusted indexed path to unvalidated runtime data.

## The constructor, phase by phase

`wr_begin` invalidates the active table, clears caller-owned work, records the seed and starts the job. `wr_advance` advances one phase step. `wr_generate` is only a convenience loop over the same job for host callers; there is no second synchronous generator.

| Phase family in `step_inner` | Work and reason |
|---|---|
| ATTEMPT_INIT | Clear partners, derive `seed + 0x9e3779b9 * attempt`, establish initial reachability |
| SELECT | Scan free representatives a word at a time; choose an unsafe reached source first if repair is needed |
| TRIAL_SETUP | Sample a distinct partner with partial Fisher–Yates, temporarily pair it, restore cached zero-capability state |
| TRIAL_PAIR / TRIAL_CAP | Propagate added pair or newly granted capability edges through queues |
| TRIAL_CHECK | Stop on the first unsafe stage, or grant the next capability round |
| TRIAL_SCORE / REPAIR | Count remaining reachable exits; reject exhausted frontier or an unsafe area with no route to an available exit |
| TRIAL_FINISH | Undo the trial and retain the best score/state, using random tie-breaking |
| COMMIT | Install the best pair, update cached zero-capability closure, restore the winning trial's final state |
| EMIT | Write one sorted trigger/landing record per step and check its reciprocal partner |
| VALIDATE | Recompute completed-world reachability from scratch, reject any unsafe stage or unreachable goal |

There are up to three trials per pair and eight attempts in the adapter. Failing to complete a seed returns an error; no partial world is published. Source and partner scans now yield per bitset word, avoiding the earlier large selection operation. Traversal yields per component and emission per record. Initial closure and commit still contain bounded loops: this is not a mathematically exact fixed-cycle instruction scheduler.

The `base_*` arrays mean reachability with current committed pairs and **zero capabilities**, not the most recent trial's final state. This is what allows a new trial to test every capability stage without rebuilding all previously established unconditional reachability. The `best_*` arrays save the winning trial. `reverse_head` and `reverse_next` give incoming randomized edges so reverse traversal is efficient.

Capabilities are granted only when their location requirements are both reached and returning. `grant` collects a round separately before installing it, preserving staged semantics. `unsafe` asks whether any reached component lacks a return route. `repair` searches backward from still-free reached entrances; a currently unsafe component must be able to reach such an entrance. That heuristic admits temporary repair obligations during construction but does not override final validation.

## Acceptance remains an independent check

The runtime VALIDATE phases rebuild reachability on the completed partner graph; they do not accept the winning trial's cached state as proof. Compilation established alias ownership and output order; EMIT checks reciprocal, compatible representative landings before producing each record. `wr_advance` copies the completed records and sets `valid` last, only after all phases succeed.

The generic `wr_validate` independently reconstructs physical travel from remap records and uses ordinary node queues, without SCC indexes. test.py also validates accepted generated records using a separate Python implementation. These checks protect against implementation mistakes. They cannot establish whether a declared graph edge matches the real game's scripts.

## Lookup and save identity

`wr_source_normalize` binary-searches sorted physical source signatures and compares the expected destination, x, y and elevation. A mismatch leaves the output untouched. `wr_lookup` then checks active identity and searches for the normalized trigger. The table is small enough that a simple linear lookup is retained.

The saved table starts with this 56-byte explicitly encoded identity:

| Byte offset | Contents |
|---|---|
| 0–3 | `WR08` format marker |
| 4–7 | Seed |
| 8–11 | Local algorithm ID 8 |
| 12–15 | Ruleset 1 |
| 16–47 | SHA-256 input fingerprint |
| 48–49 | Successful zero-based attempt |
| 50–51 | Reserved zero bytes |
| 52–55 | CRC32 of bytes 0–51 |

Multibyte values are little-endian. The CRC detects accidental corruption; it is not authentication. The fingerprint identifies the input model, not a proof of gameplay safety. This local ID/format is not an upstream registration and does not migrate old Algorithm-3/5/6/7 saves.

Continue decodes the saved identity and destination indexes, checks integrity and structure, and runs fresh indexed capability-stage validation before entering the field. It does not retry construction on a failed saved table. Corruption, changed identity, invalid pairing or unsafe graph state refuses entry. A randomized save must never silently resume using an unrelated or vanilla table.

The target follow-up measured a 60-byte SaveBlock3 with this field under default configuration, passed its compile-time size assertion, and verified the identity through actual flash save/load. Recheck capacity if you enable other save features.

## Manual integration into a clean target

These are concrete manual edits for a **clean** Expansion 1.17.0 target at the commit in INTRODUCTION.md. They are not a patch to layer on top of the old C10/C11/proof wiring. Use a separate branch/worktree. These edits have now been applied to that exact target, compiled and linked. integration.patch contains the same edits plus a TESTING-only accessor for exercising the real static SetupWarp function.

This adapter is enabled by installing the following edits; there is no runtime enable/disable switch. Existing saves are rejected. Keep an ordinary build separately. Do not use these instructions on your only copy of a save.

### 1. Add two C files, two interface headers and one generated header

Run `python3 build.py`, then copy:

| This folder | Target checkout |
|---|---|
| warp_rando.h | include/warp_rando.h |
| warp_game.h | include/warp_game.h |
| warp_data.h | include/warp_data.h |
| warp_rando.c | src/warp_rando.c |
| warp_game.c | src/warp_game.c |

Only warp_game.c includes warp_data.h in the normal ROM (the test file also includes it), so the large static arrays are defined once. Ensure the target build discovers both new `.c` files. The host suite compiles only the portable core; it does not compile the engine adapter.

### 2. Reserve identity storage

At the end of `struct SaveBlock3` in `include/global.h`, before its closing brace, append:

```c
    // Compact warp randomizer: explicit identity, not a saved C struct.
    u8 warpRando[1124];
```

Do not append the field twice. Default target size and flash serialization now pass the tests below. The engine's existing SaveBlock3 maximum remains the guard when other save features are enabled.

### 3. Wrap new game and Continue

In `src/overworld.c`, add includes:

```c
#include "warp_game.h"
#include "title_screen.h"
```

Rename the existing `void CB2_NewGame(void)` implementation to `static void CB2_NewGameReady(void)`. Insert this wrapper before it:

```c
static void CB2_NewGameReady(void);

void CB2_NewGame(void)
{
    WarpRando_NewGame(CB2_NewGameReady, CB2_InitTitleScreen);
}
```

Inside the renamed implementation, immediately **after** `NewGameInitData();`, insert:

```c
    if (!WarpRando_Save(gSaveBlock3Ptr->warpRando))
    {
        SetMainCallback2(CB2_InitTitleScreen);
        return;
    }
```

Writing before NewGameInitData would let initialization erase the new identity. No special save hook is needed afterward if the target's normal flash save really serializes the appended field: the identity is constant throughout this world.

Similarly rename the existing `void CB2_ContinueSavedGame(void)` body to `static void CB2_ContinueSavedGameReady(void)`, and place this wrapper before it:

```c
static void CB2_ContinueSavedGameReady(void);

void CB2_ContinueSavedGame(void)
{
    WarpRando_Continue(gSaveBlock3Ptr->warpRando,
                       CB2_ContinueSavedGameReady,
                       CB2_InitTitleScreen);
}
```

Keep the existing bodies' other initialization steps. The adapter finishes generation or saved-table validation first; only success reaches those bodies. Generation remains inside the ROM. `WARP_RANDO_SEED` in warp_game.c is the development seed, as opposed to a finished seed-entry UI.

### 4. Intercept only the ordinary event path

In `src/field_control_avatar.c`, add `#include "warp_game.h"`. In `SetupWarp`, locate the ordinary `else` branch which currently declares `const struct MapHeader *mapHeader;`, calls `SetWarpDestinationToMapWarp`, then updates the escape/dynamic warp state. Replace that branch's contents with:

```c
        const struct MapHeader *mapHeader;
        s8 destGroup = warpEvent->mapGroup;
        s8 destMap = warpEvent->mapNum;
        s8 destWarp = warpEvent->warpId;
        bool8 redirected = FALSE;

        if (!trainerHillMapId)
            redirected = WarpRando_Resolve(
                gSaveBlock1Ptr->location.mapGroup,
                gSaveBlock1Ptr->location.mapNum, warpEventId,
                warpEvent->x, warpEvent->y, warpEvent->elevation,
                &destGroup, &destMap, &destWarp);

        SetWarpDestinationToMapWarp(destGroup, destMap, destWarp);
        UpdateEscapeWarp(position->x, position->y);
        mapHeader = Overworld_GetMapHeaderByGroupAndId(destGroup, destMap);
        if (redirected)
        {
            if (destWarp >= 0 && destWarp < mapHeader->events->warpCount
                && mapHeader->events->warps[destWarp].mapNum == MAP_NUM(MAP_DYNAMIC))
                SetDynamicWarp(mapHeader->events->warps[destWarp].warpId,
                    gSaveBlock1Ptr->location.mapGroup,
                    gSaveBlock1Ptr->location.mapNum, warpEventId);
        }
        else
        {
            // Preserve this pinned target's existing vanilla branch.
            if (mapHeader->events->warps[warpEvent->warpId].mapNum == MAP_NUM(MAP_DYNAMIC))
                SetDynamicWarp(mapHeader->events->warps[warpEventId].warpId,
                    gSaveBlock1Ptr->location.mapGroup,
                    gSaveBlock1Ptr->location.mapNum, warpEventId);
        }
```

The apparently inconsistent `warpEventId` in the vanilla branch is copied from the clean target context supplied in the old proof patch. This rewrite intentionally does not certify or fix that unrelated engine behavior. If your target has changed that branch, preserve your target's own vanilla logic and review the difference explicitly.

Keep the dynamic-destination handling that precedes this branch intact. Do not hook the general destination setter: scripts, Dive, falls, escape actions and other special paths also call setters, and are outside this implementation's interception scope. The adapter bounds-checks a randomized landing before returning it.

There is no old proof arrival correction in this integration. The old four-door experiment's hard-coded coordinate fix was specific to that experiment and is not a general landing solution.

## Birch integration and scheduling

integration.patch adds these hooks to main_menu.c (include warp_game.h):

1. After `AddBirchSpeechObjects` in `Task_NewGameBirchSpeech_Init`, call `WarpRando_IntroStart` once.
2. Before `RunTasks` in `CB2_MainMenu`, call `WarpRando_IntroFrameBegin`; after `RunTasks`, call `WarpRando_IntroPump`. Their flags make them inactive for ordinary menu use.
3. Before freeing sprite/window resources on entering naming or leaving the intro, call `WarpRando_IntroHide`.
4. In `CB2_NewGameBirchSpeech_ReturnFromNamingScreen`, after resetting/rebuilding sprites and before initializing text windows, call `WarpRando_IntroResume`.

The job is not a game task. Naming resets that task array, but keeps our EWRAM job and allocated work alive. Naming does not advance generation; returning resumes the same RNG state. `sHasIntro` remembers that a new-game job exists even while its indicator is hidden. New-game entry consumes that job: a ready table skips loading, pending work continues on the loading screen, and failure takes the failure path. Continue first discards any old job and restores its saved table.

The seed is fixed at IntroStart using `WARP_RANDO_SEED`, currently a development setting. Never change it halfway through the intro. The constructor uses its own LCG; it does not consume the gameplay or naming RNG. NewGameInitData clears save blocks, so the wrapper writes the completed identity **after** that call.

`PumpWork` uses timer 3 at CPU/64 (262,144 ticks/second). The intro first uses it to measure scene tasks, then generation uses it for its own budget. It stops the timer afterward and reserves it against other users in these callbacks. Audio uses timers 0/1; naming uses timers 1/2; flash uses timer 2. If another modification needs timer 3, resolve that ownership explicitly. Background budget is 524 ticks (~2 ms); foreground is 2,621 ticks (~10 ms). A step started before the budget expires may finish after it. If scene tasks already took 1,600 ticks (~6.1 ms), the intro skips generation that frame. Initialization also gets its own frame. Keep measured worst-step margin, and measure the whole main callback too.

The indicator is one 8×8 sprite, one tile and one allocated object palette, tagged `0xFDF0`. It is red while pending, green when accepted, then fades toward white over 60 frames after a 30-frame hold and releases its resources. This is a color fade, not hardware alpha transparency. Allocation failure merely omits the decoration. Hiding before sprite resets prevents dangling sprite IDs. Failure stays red until the foreground failure path returns to title; a richer error message is future work.

No work happens in VBlank. This is cooperative scheduling on one CPU, not parallel computation. A short intro may still need a loading tail. The first iteration intentionally pauses during naming rather than inserting a global pump into every screen.

## A manageable development loop

Make one data or algorithm change at a time. Add a small synthetic test when it exposes a new correctness issue, run the host suite, then regenerate the header. For algorithm changes, change `WR_ALGORITHM` and the save marker/version policy deliberately. For data changes, the fingerprint changes automatically.

Then build the target, start a fresh save, try an ordinary door in both directions, save, power-cycle and Continue. Also hold B during generation, test a known second-attempt seed such as 42, and confirm an incompatible save returns to title. Check an excluded source and special transition to establish they still follow their expected vanilla behavior.

Treat source-coordinate agreement as the beginning of a map audit, not its end. Confirm arrival elevation, collisions, event activation and the real starting position. The supplied graph starts at Oldale while the normal engine starts through its vanilla sequence. Resolve that deliberately before interpreting a full-world playtest as a progression test.

Keep brief findings in the appropriate section of these three documents. Regenerate machine outputs when needed. You do not need a new checkpoint README for every experiment.

## Target verification follow-up

### Apply the tested integration

After copying the files in step 1 above, an alternative to the manual edits is:

```sh
# Run inside the clean, pinned target checkout. Replace this path with yours.
git apply --check /path/to/warp-randomizer/integration.patch
git apply /path/to/warp-randomizer/integration.patch
make -j4
```

Do not apply both methods. The patch changes global.h, overworld.c, main_menu.c, field_control_avatar.c, script.c, data/specials.inc and the Rustboro/Mauville/Petalburg Gym scripts. A TESTING-only accessor in the latter lets the regression call the actual SetupWarp implementation. It is absent from normal ROM code.

The patch was checked against clean copies of the four files from commit `e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. No source from the older proof or C10/C11 runtime is required.

### Run the engine regression tests

Keep `WARP_RANDO_SEED` at its default zero for this suite. Copy target_test.c to `test/warp_compact.c` in the integrated target checkout, then run:

```sh
make -j4 TEST=1 \
  TEST_SRCS_IN="test/test_runner.c test/test_runner_battle.c test/test_runner_args.c test/test_test_runner.c test/warp_compact.c" \
  TESTS="WarpCompact:" check
```

This uses the target's own test framework and bundled mGBA runner. The test file contains seven groups and expected hashes derived from independently host-validated layouts. Foreground loops stop at 5,000 callbacks and background completion at 4,000; naming waits are also bounded. Timer 2 measurements temporarily replace the runner’s hardware watchdog, so the outer host-process timeout remains important. Flash tests temporarily restore the engine’s real flash timer interrupt handler, then restore the runner’s handler. This is a targeted suite, not the entire game's battle test suite.

In the restricted test environment used here, `/dev/fd` process substitution and Hydra's temporary-file assumptions were unavailable. The build used the supplied original archive's build-without-dev-fd.patch to replace its two `cat - <(...)` suffixes with `{ cat && printf '.text\n\t.align\t2, 0\n'; }`. This is an environment-only Makefile workaround, not part of integration.patch.

The test ELF was built with the command above using `pokeemerald-test.elf` in place of `check`, then run with ordinary files under `build/`:

```sh
cp pokeemerald-test.elf build/compact-headless.elf
tools/patchelf/patchelf build/compact-headless.elf \
  gTestRunnerHeadless '\x01' gTestRunnerSkipIsFail '\x01' \
  gTestRunnerN '\x01' gTestRunnerI '\x00'
arm-none-eabi-objcopy -O binary build/compact-headless.elf build/compact-headless.gba
tools/mgba/mgba-rom-test -l15 -ClogLevel.gba.dma=16 -Rr0 build/compact-headless.gba
```

That emulator process also had a 300-second host wall-clock limit. This fallback runs the same ELF/tests in one process; it does not replace the engine with stubs. Standard environments can use the ordinary `make ... check` path.

### Historical algorithm-7 measurements

The following construction/timing baseline predates stored tables. The new saved-table results appear below; the former Continue timings are retained for comparison.

That earlier revision passed all **18 host groups**, both normally and with AddressSanitizer/UndefinedBehaviorSanitizer, and all **six headless engine groups**. Both normal ROM and test ELF link. Target: expansion/1.17.0 commit `e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`, ARM GCC 13.2.1, binutils 2.42, newlib 4.4.0, normal Thumb/ARM7TDMI `-O2`, default EMERALD configuration. The target's bundled mGBA runner executes the real engine callbacks.

| Loading measurement | Seed 0 new game | Seed 0 Continue | Seed 42 Continue (attempt 1) |
|---|---:|---:|---:|
| Callbacks | 513 | 513 | 731 |
| Elapsed ticks, including VBlank waits | 2249987 | 2252113 | 3209051 |
| Elapsed emulated seconds | 8.583 | 8.591 | 12.241 |
| Generator CPU ticks | 1359230 | 1359189 | 1935851 |
| Maximum generator step ticks | 558 | 557 | 503 |
| Maximum whole loading callback ticks | 3013 | 3013 | 2948 |

Ticks are CPU/64, or 262,144 per second. These are emulated GBA times, not host wall-clock times. The longest measured loading callback is 11.49 ms. Timer 2 measures callbacks independently of timer 3; its 16-bit difference assumes a measured callback stays below 250 ms. No physical-hardware or universal worst-case timing claim is made.

| Birch/naming measurement, seed 0 | Observed value |
|---|---:|
| Background pumps to completion | 2452 (about 41 seconds of active intro frames) |
| Generator CPU ticks | 1358640 |
| Maximum generator step | 558 ticks / 2.13 ms |
| Maximum background pump | 902 ticks / 3.44 ms |
| Maximum whole callback that advanced generation | 2515 ticks / 9.59 ms |
| Maximum whole measured scene callback | 5351 ticks / 20.41 ms |
| Generation during that longest callback | None; busy-frame check skipped it |

Naming and transition pauses add elapsed time. The test runs the actual intro callback, enters the actual naming screen, supplies Start/A to finish naming, and resumes the actual return callback. It verifies unchanged generation pump count while naming, unchanged gameplay RNG during the measured resumed generation, correct final source mappings, green palette state, indicator resource release, and no second generation at ready handoff. It calls NewGameInitData and confirms the identity can be written afterward. A separate shortened-intro test forces early cleanup and proves the existing unfinished job is adopted by loading; it needs 488 more callbacks in that case.

The longer scene callback occurs during the naming-return textbox/graphics transition. Its scene tasks alone cost 3736 ticks, so the generator skips that frame; the full callback still exceeds one frame. This revision removes generator stalls, but does not claim to eliminate every engine graphics transition hitch. Timing covers controlled scene paths, not every possible dialogue/input sequence. Palette/sprite state is tested; a human visual playthrough of the dot is still pending.

| Normal ROM resource | Observed use |
|---|---:|
| Linked EWRAM | 234904 / 262144 bytes |
| Linked IWRAM | 28376 / 32768 bytes |
| Linked ROM region | 26866424 bytes |
| Temporary WrWork, target ABI | 17320 bytes |
| Retained WrActive, target ABI | 8244 bytes |
| Default SaveBlock3, including identity | 60 bytes |

The linked EWRAM figure includes the reserved engine heap; it is not an additional measure of free heap. Foreground tests check heap recovery after success, cancellation and allocation failure. The actual intro/naming test demonstrates successful concurrent allocation on the pinned default target; it is not a stack high-water or all-configurations memory proof.

The source checks cover all 608 participating target event signatures, including coordinate rejection. Selected calls exercise real SetupWarp/WarpIntoMap behavior for normalized, ordinary and excluded sources. Actual flash save/load preserves the 56-byte identity and Continue reproduces all source/landing pairs. Blank, CRC-corrupt and incompatible identities are refused. The host suite also checks all 879 nodes' compiled forward/reverse unconditional closure against direct physical-node walks and checks an empty randomized pool.

The previous compact revision took 64.4/101.5 seconds and stalled about 6.4 seconds. The supplied C11B logs report 917/1291 elapsed frames for the corresponding first-/second-attempt cases, approximately 15.4/21.6 seconds. Our loading examples finish sooner, but use a larger foreground work budget and fewer historical profiling checks. This is evidence of practical improvement on these examples, not proof of universally lower CPU cost or an equivalent worst-case deadline guarantee. Preserve the same seeds, compiler, model and budget when comparing future changes.

Starting-position/Oldale alignment, arrival collision safety, special transitions, real progression and Champion/credits completion remain unproven. Those are model and integration tasks, not solved by faster generation.


## Tutorial: learning to implement the remaining transitions

This tutorial is a development path, not a patch that already implements special warps. Its engine function names were checked against the pinned Expansion checkout used for this package. Suggested new types and APIs below are designs to implement and test; they do not exist in this revision. The tested runtime remains unchanged.

The achievable goal is to add one understood transition family at a time. “Support” can mean accurately modeling a transition that stays vanilla. It does not require shuffling every mechanism. A ferry whose story sequence stays vanilla but whose real travel is represented in the graph may be better support than a shuffled ferry that breaks its arrival script.

### Lesson 1: learn the path a warp takes

You need enough C to read a struct, a pointer, a function call and a conditional. In `WarpRando_Resolve`, an argument such as `int8_t *dg` means the caller supplies an address; assigning `*dg` changes the caller's destination group. A header declares that calling convention; the C file implements it. You do not need to understand the whole engine before tracing a single route.

Learn these four engine concepts next:

- A map script is a sequence of commands interpreted by C functions. Script commands are not ordinary C calls, although commands such as `special` can dispatch to C.
- A callback runs later as the engine advances frames. Returning from a script command can leave the script waiting while a transition animation runs.
- A flag or variable may determine whether travel is available, where it goes, or what happens after arrival.
- A saved destination is mutable history. It is not necessarily another fixed edge in your map description.

Follow an ordinary door first. Search from the target checkout:

```sh
rg -n 'static void SetupWarp|WarpRando_Resolve' src/field_control_avatar.c src/warp_game.c
rg -n 'SetWarpDestinationToMapWarp|SetPlayerCoordsFromWarp|void WarpIntoMap' src/overworld.c
```

Read the surrounding functions, not just matching lines. Write down this chain in your own words: identify the source event; normalize its reference key; look up the accepted landing; set a pending destination; run the engine transition; load the map and determine the actual player position. Then locate where escape and dynamic return information is updated.

In this target, `SetPlayerCoordsFromWarp` uses a valid destination warp event's coordinates first. Otherwise it uses supplied coordinates when valid, and otherwise falls back to the map center. Reaching the center of a map after a bad index can look like a successful warp while hiding an invalid destination. Your tests should catch that fallback, not accept it.

**Exercise:** pick one currently supported Oldale doorway. Predict its destination from the generated mapping, traverse it, and explain each function involved. Repeat with an excluded source and explain why it is left alone.

### Lesson 2: inventory transitions by behavior

Search is discovery, not proof that the inventory is complete. Some scripts call shared labels; some C functions choose a destination indirectly. Trace the callers and the arrival scripts too.

```sh
rg -n '\b(warp|warpsilent|warpdoor|warphole|warpteleport|warpmossdeepgym|setwarp|setdynamicwarp|setdivewarp|setholewarp|setescapewarp)\b' data/maps data/scripts
rg -n 'SetWarpDestination|SetDynamicWarp|SetFixedDiveWarp|SetFixedHoleWarp|SetEscapeWarp|SetLastHealLocationWarp' src
rg -n 'CONNECTION_DIVE|CONNECTION_EMERGE|TrySetDiveWarp|RunOnDiveWarpMapScript' src include
```

For each candidate, keep a short entry in your working notes or a table in FUTURE.md:

| Question | What to record |
|---|---|
| What activates it? | Exact map, script label or C caller; tile/NPC/menu action |
| When is it available? | Flags, variables, party/move requirements, movement mode |
| How is its destination chosen? | Constant event, explicit coordinates, variable, stored return, connection |
| What changes before departure? | Flags, objects, escape/return state, inventory, transport position |
| What happens after arrival? | Entry scripts, forced movement, facing, Surf/Dive state, control locks |
| Can it be repeated and reversed? | Actual reverse action and its requirements; “unknown” is useful |
| What will our mode do? | Keep and model, randomize narrowly, or exclude from a supported preset |

For example, the pinned `Route104_MrBrineysHouse/scripts.inc` contains a coordinate warp to Route104; `SSTidalCorridor/scripts.inc` has harbor warps alongside transport-state specials. These are good reading exercises. They are poor first production edits because the surrounding story and transport behavior matters.

Do not count ordinary warp events again as new scripted entrances just because an arrival script mentions them. Similarly, two script branches may implement the same logical action, or two actions on the same map may require different identities.

### Lesson 3: prove one fixed scripted redirection without changing the solver

Make your first experiment a temporary, controlled engine test. Choose or create a repeatable test interaction with a constant destination, no consumed item, no one-time story flag and no transport state. Use a destination with a real, already inspected warp event. Do not begin with the intro, a ferry, whiteout, or a coordinate-preserving fall.

Read `ScrCmd_warp` in `src/scrcmd.c`. It reads destination operands, calls `SetWarpDestination`, starts `DoWarp`, resets the initial avatar state, and returns `TRUE`. Nearby commands deliberately use different transition functions. `ScrCmd_setwarp` only sets a destination and returns `FALSE`; it does not perform the whole travel operation.

For the first experiment, redirect exactly one identified test site to exactly one known-safe destination. The purpose is to learn the engine contract before adding randomness. Preserve that command's animation, script suspension, avatar reset and arrival sequence.

Conceptually the hook belongs here:

```text
read the original destination
identify the explicitly supported script site
if that site has an accepted replacement:
    use the replacement destination
set the pending engine destination
run this command's original transition and script-control behavior
```

This is pseudocode, not a copy-paste C patch. A shared `ScrCmd_warp` handler does not inherently know a stable semantic site ID. You must provide one deliberately. Options include a narrowly scoped special for the experiment or a new script command carrying an explicit site ID. If using a temporary source/script check, document precisely what identifies that one call.

Do not identify a site using only its requested destination: unrelated scripts can go to the same place. Do not use a compiled script pointer as a permanent identity: code movement can change its address. A named numeric ID, resolved consistently by the build, is easier to preserve and inspect.

Also beware of overwrite order. A special that changes the pending destination followed by an ordinary `warp` command may have its change overwritten when `warp` reads and installs its own operands. Follow the actual setter order.

Test activation, arrival, walking away, a second activation and the intended return. Check script control is released and movement mode is correct. Check a neighboring unregistered script still behaves normally. Remove the temporary hard-coded redirection before integrating the real mapping.

**Exit criterion:** you can explain and demonstrate one specific scripted transition end to end. This still does not mean it belongs in the randomized pool.

### Lesson 4: extend the representation before adding new pool members

The current representation has a real limit: `WrKey` means a physical event triple, `WrRecord` maps a reference trigger to a physical endpoint, and `source_routes` validates ordinary event signatures. `build.py` expects participating physical nodes to have the corresponding source coverage. A coordinate landing or a menu action is not automatically representable by inventing another event triple.

Do not put `WARP_ID_NONE` into a normal unsigned `WrKey`, make up a warp index, or silently bypass source coverage. Those shortcuts confuse “not an event” with a real array index and can reach the map-center fallback.

The most comprehensible generalization is to distinguish **logical sites**, **physical landing descriptions**, and **traversal policy**. A site is an action or entrance in the solver; its landing describes how the engine enters that place. For a first script-only extension, keep landings restricted to real events. Add coordinate landings only when the next family requires them.

One possible eventual design is:

```text
Site:
    stable ID
    activation kind: ordinary event, script action, dive region, ...
    source signature appropriate to that kind
    landing: event address OR explicit map/x/y plus arrival policy
    representative/group information where meaningful

Mapping:
    source site ID -> destination site ID
```

“Arrival policy” should be a small set of supported behaviors, such as walking or underwater arrival, not a collection of arbitrary callbacks stored in world data. Keep the engine responsible for performing each policy.

Do not force every site into a coupled pair. The current solver specifically constructs reciprocal pairs, and its validator checks that contract. A genuinely paired scripted entrance may fit that model after the representation change. A one-way fall or a history-dependent escape does not gain a valid reverse action merely because the table contains a reciprocal number.

For the first generalized version, keep two clear categories: coupled randomized entrances, and directed fixed travel. Extend to directed randomized mappings only as a separate algorithm change. Such a change affects partner selection, trial edges, reverse indexes, repair logic, emission and final acceptance—not just a new tag.

Work through the affected code in this order:

1. Define the site and landing schema in `world.json`, with a schema-version change and a tiny example.
2. Teach `normalize` to reject duplicate site IDs, invalid source signatures, unsupported landing kinds and incompatible arrival policies.
3. Build physical/logical adjacency and alias indexes from that schema. The existing bitset constructor can remain conceptually similar for genuine coupled sites, but its physical-node assumptions must be audited.
4. Update portable types, emission, lookup and both validators together. Search every use of `WrKey`, `.rep`, `.trigger`, `.active` and `source_routes` to locate assumptions.
5. Add separate engine-facing resolution functions for the supported families in warp_game.h/warp_game.c. They may share a site lookup internally while retaining different source checks.
6. Update identity/version policy, host fixtures and target tests before adding the large dataset.

A simpler migration is to retain the existing ordinary-event path while adding a small explicit script-site table. That minimizes the first edit, but becomes a second representation to reconcile. Once several families need the same concepts, replace the duplication with a shared site model rather than keeping permanent parallel systems.

Coordinate types need particular care: this pinned `SetWarpDestination` accepts signed 8-bit coordinates even though some script operands and other APIs use wider types. Validate the supported range before narrowing, or deliberately widen the complete engine path after reviewing its storage and callers. Use map-local coordinates at the correct boundary; player positions often include `MAP_OFFSET`. Subtracting it twice is as wrong as forgetting it.

### Lesson 5: make the graph tell the truth

A transition needs both engine support and an accurate graph interpretation. Record edges for how the player reaches its activation site, the transition itself, and where the landing lets the player go. Add the reverse only if the player can actually perform it.

Remember what an edge means here: repeatable travel available whenever its declared permanent prerequisite holds. A rule says a permanent capability can be obtained at safe reachable locations. It does not simulate every inventory, party, story or historical state.

For a fixed ferry that remains vanilla, for example, add its real travel only after understanding availability and destination state. If two prerequisites must hold, a derived capability with an AND rule can describe them when both are permanent. If choosing a destination depends on changing vehicle history, a single permanent capability is not enough.

For a randomized transition, do not leave its original vanilla travel as an unconditional graph edge unless the game genuinely retains that alternative. Otherwise the validator may “escape” along a route you removed from the ROM. Audit inherited edges before adding new ones; some excluded/fixed travel is already represented.

Avoid treating dynamic recovery as “there is an edge to every possible saved return location.” That gives the solver routes the player does not currently possess. Conversely, ignoring real extra travel is not automatically safe: it may let the player enter a trap absent from your model.

Two legitimate ways to contain complexity are to expand solver state, or simplify the mode's rules explicitly. For instance, a guaranteed return-to-hub action is much easier to model than arbitrary last-heal history. But the game must actually provide the action, with the availability the graph assumes. That is a gameplay rule change, not a harmless optimization.

**Exercise:** create a small synthetic graph in test.py in which the new transition is the only route to a goal. Then create a version where its prerequisite is self-locked and a version where its landing is a directed sink. The first should pass only under the real availability conditions; the others should fail. Run the independent Python validator as well as the C path.

### Lesson 6: handle each remaining family deliberately

| Family | Start reading here in the pinned target | First sensible implementation boundary |
|---|---|---|
| Fixed scripted travel | `ScrCmd_warp`, `ScrCmd_warpdoor`, `ScrCmd_warpsilent` in scrcmd.c; caller and arrival scripts | One explicitly named, repeatable site with an inspected event landing |
| Dive/surface | `TrySetDiveWarp` in field_control_avatar.c; `SetDiveWarp`, `SetDiveWarpDive`, `SetDiveWarpEmerge` in overworld.c | One audited surface/underwater region pair with a declared coordinate mapping |
| Holes/falls | `ScrCmd_warphole`; `SetFixedHoleWarp`, `SetWarpDestinationToFixedHoleWarp`; `DoFallWarp` callers | One directed drop and a verified escape from its landing |
| Dynamic returns | `SetDynamicWarp`, `SetDynamicWarpWithCoords`, `SetWarpDestinationToDynamicWarp` | One entrance/return protocol, with ownership of the remembered destination |
| Escape Rope/Dig | fldeff_dig.c, escape calls in field_effect.c, `UpdateEscapeWarp`, `SetWarpDestinationToEscapeWarp` | Preserve the real return contract, then model availability conservatively |
| Teleport/whiteout | fldeff_teleport.c, field_effect.c, `SetWarpDestinationForTeleport`, `SetWarpDestinationToLastHealLocation` | Declare a recovery policy and verify both its state updates and respawn scripts |
| Ferries/Briney/cable car | Their map scripts and specials; cable-car destination calls in field_specials.c | One complete journey, including flags, menu choice and arrival sequence |
| Fly and other registered travel | Follow the field move/menu to its destination setter and registration flags | Model destination registration before relying on it as recovery |

**Dive is often a region operation.** The pinned engine normally follows a Dive/emerge map connection with the supplied coordinates; without a connection it can run the map's Dive script and use a fixed Dive warp. Replacing an entire underwater map while preserving coordinates is unsafe unless the corresponding tiles, boundaries and exits were audited. Begin by preserving one region's coordinate relationship. Test multiple activation tiles, not just one center point, and verify Surf/underwater state on both sides. Group by actual navigable region, not merely map name.

**A fall is directed travel.** The hole helper can use a fixed destination or fall back to `gLastUsedWarp`. That fallback is history-dependent. Inspect the scripts setting it before classifying a hole as fixed. A coupled door pairing is not a model of climbing back up the hole. Keep fixed falls as directed edges first; leave their destinations unshuffled until you have a directed-randomization design.

**A dynamic return is a protocol.** Find every writer of the remembered destination and identify which subsequent action consumes it. This target's `SetDynamicWarp` has an unused first parameter, and `SetWarpDestinationToDynamicWarp` reads the saved `dynamicWarp`; do not assume the parameter indexes a bank of independent slots. Test nested journeys: enter A, visit B through another dynamic action, then return. Decide whether overwriting A's return is intended. A stack of returns is a substantial engine/save-state change, not something to add casually.

**Escape Rope and Dig have related destinations but different availability.** The current ordinary-event path already calls `UpdateEscapeWarp`, which can record an outdoor-to-indoor entry coordinate. The randomizer can therefore change the circumstances in which vanilla escape state is written even though the escape action itself remains unmodified. Test entry from outdoors and indoors, repeated entries and Save/Continue. A consumable Rope is not an unlimited graph edge; Dig depends on the real field-move rules. Do not grant an automatic return edge merely because either feature exists in the game.

**Teleport and whiteout share some state but are different actions.** Teleport uses the last-heal location here. Whiteout can additionally use a configured respawn/healer cutscene. Trace when last-heal state changes, any home/start exceptions, healing, money loss, and control restoration. If defeat is intended as a valid escape strategy, say so explicitly and model its consequences. Otherwise do not use it to certify a seed's safety. A fixed-hub recovery rule can simplify both, but must preserve their respective arrival behavior.

**Transport is a whole journey.** For Briney or the S.S. Tidal, read the menu, departure, intermediate state and arrival together. Moving the final warp may leave the boat, NPC or story flag at the wrong end. Start with fixed transport accurately represented in the model, or randomize a complete audited journey as a unit. Avoid changing just the final `SetWarpDestination` call and calling the family finished.

### Lesson 7: test the contract, including sequences

Use a fixed destination for early debugging, then connect the accepted randomized mapping. Randomness makes a broken engine path harder to reproduce; it does not help diagnose it.

For each new family, collect these forms of evidence:

1. **Compiler rejection:** malformed site IDs, unsupported landings, coordinate overflow and incompatible pair types fail before ROM generation.
2. **Small graph cases:** reachable goal, unavailable prerequisite, directed trap, grouped activation and relevant return-state counterexample. Update both validators when semantics change.
3. **Real engine activation:** exercise the script command or field action and its transition callback. Calling only your resolver proves too little.
4. **Arrival inspection:** map, exact tile, elevation, facing, movement mode, collision, script completion and ability to leave. A correct destination triple alone is insufficient.
5. **History tests:** repeat the action, take a different journey in between, save before and after updating a return point, restart, and Continue. For dynamic travel the sequence is often the bug.
6. **Isolation:** a nearby unsupported source and a changed source signature remain untouched. Failed or incomplete generation never supplies a partial mapping.

Extend target_test.c with a small family-specific test rather than creating a new testing framework. Use the existing expected-output style, but test actual state that the family changes. Keep a host wall-clock limit around emulator runs; the runner's timer and engine timers can conflict during naming or flash operations, as the existing tests explain.

After extending the graph, measure generator CPU time, background steps, whole callbacks and temporary heap again. More endpoints or capabilities can change queue work and retry behavior even if the adapter is only a few lines long. Compare a known first-attempt seed and a retry seed, then expand the sample only to answer a concrete remaining risk.

Finally do a short manual route test with the same ROM and seed. Headless state assertions are useful, but a camera lock, wrong animation or landing on an impassable tile deserves visual inspection.

### Lesson 8: work in milestones you can finish

A practical sequence is:

1. Trace one ordinary warp and one fixed script without changing either.
2. Complete the single-site fixed-redirection exercise and undo the temporary hack.
3. Add explicit script-site identity and event landings, with compiler/host/target coverage.
4. Audit and model fixed directed falls and transport before attempting to shuffle them.
5. Add coordinate landing support and one paired Dive region, including movement state.
6. Choose and implement dynamic-return and recovery policies, with sequence/save tests.
7. Expand the supported data gradually, then prove a small real progression route.
8. Resolve the actual starting contract, complete a reproducible Champion/Hall of Fame/credits run, and document its ROM identity and seed.

Do not postpone the starting contract until you interpret progression results: the current Oldale graph root does not move the player there. Similarly, reachable League locations are not a credits condition. You may finish the new transition adapters before full progression support, but describe that milestone accurately.

Use one branch per family or coherent change. Run `git diff --stat` to see its size and `git diff --check` before reviewing it. Keep commits small enough that one can be reverted without removing unrelated discoveries. Record the decision, evidence and remaining limitation in these three guides. Machine-generated tables remain generated; new capability should replace obsolete special cases rather than accumulating layers around them.

A useful definition of “done” is: “This named family has explicit identities and valid landings; its runtime and graph agree; its activation, arrival, return/history and Save/Continue tests pass; other families remain unaffected; and timing still fits the intended screens.” That is a stronger and more useful milestone than “I found another setter to hook.”


## Saved-table implementation, space audit and installation

### Why this fits without redesigning flash storage

The pinned save.h reserves 116 SaveBlock3 bytes in each of 14 sectors of each normal save slot: **1,624 bytes per logical SaveBlock3**. save.c has a static size assertion and copies that block in 116-byte pieces through CopyFromSaveBlock3/CopyToSaveBlock3. The ROM's normal rotating save slots carry those pieces. We have not borrowed Hall of Fame sectors, changed sector sizes, or removed other save features.

The default old SaveBlock3 used 60 bytes including a 56-byte identity. This edition uses **1,128 bytes including a 1,124-byte warp field**, leaving **496 bytes** under the same limit. The increase is **1,068 bytes**. Optional fake RTC, followers, first-time item descriptions, DexNav levels or apricorn features can consume the same block: the default fit is not a guarantee that every configuration fits. The existing target size assertion remains the final gate.

The earlier idea of 532 three-byte destinations would use 1,596 bytes before metadata, which does not fit here. Instead each destination is the index of a node in the fingerprinted immutable graph. Every trigger and its sorted position already exists in ROM, so no trigger needs saving again.

| Offset | Stored contents |
|---|---|
| 0–55 | WR08 identity envelope described above, including its metadata CRC |
| 56–1119 | 532 unsigned 16-bit destination node indexes, little-endian |
| 1120–1123 | CRC32 over bytes 0–1119 |

This is an explicit disk format, not `memcpy` of WrRecord or WrActive. Its interpretation requires the exact data fingerprint and supported algorithm/ruleset. The payload CRC covers the stored table independently of the engine's sector checks. It detects accidental damage, not deliberate forgery.

### Follow the new code

`wr_table_bytes` derives the exact required envelope length from the graph's emitted-record count. `wr_table_encode` checks the active identity and sorted triggers, finds each landing's node index, and writes the envelope and CRC. This happens when WarpRando_Save writes the completed world after NewGameInitData; later ordinary flash saves carry the already stored bytes. It is not regenerated for each door or ordinary save.

`wr_table_begin` checks length, both checksums, identity, attempt range, destination bounds, representative status, compatible tags, alias consistency and reciprocal partners. It builds the incoming pair-edge index and candidate records. It then jumps directly into the existing VALIDATE phases; it never selects a source or trials a partner. A failed validation is terminal, with no fallback that could silently produce a different world.

`WarpRando_Continue` allocates the normal temporary workspace, advances those validation phases synchronously, frees work and calls the success/failure continuation. Only a complete accepted table is published. There is no per-load loading-screen setup. There is a short validation pause, not an assertion that load time is zero. If larger future models make that pause excessive, validation itself is already resumable and can be pumped behind a transition screen.

The game header's `WARP_RANDO_SAVE_BYTES` is 1,124. Compile-time assertions in warp_game.c compare it with both the generated output count and the actual SaveBlock3 field. When the model grows, deliberately review the field size, flash budget and format rather than silently overflowing an old allocation.

### Which patch to use

For a **clean pinned Expansion checkout**, follow the existing copy table and apply the current integration.patch. The warp field is now 1,124 bytes. The engine patches now affect global.h, overworld.c, main_menu.c, field_control_avatar.c, script.c, data/specials.inc and the Rustboro/Mauville/Petalburg Gym scripts.

For the **previous compact source folder**, apply `saved-table.patch` from that folder after `git apply --check`. It updates maintained source, tests, guides and integration.patch. Then regenerate warp_data.h and recopy the changed C/header files to your already integrated engine checkout. In that engine checkout change the previous `u8 warpRando[56]` to `u8 warpRando[1124]`; do not reapply the clean-target integration patch over installed hooks. Start a fresh save. The patch does not install archive bytes; the download already includes the archive.

To revisit seed-only saves later, extract `archive/per-load-reconstruction.zip` into a separate folder. It contains the complete preceding implementation and instructions, including per-load reconstruction/loading. Keep this saved-table version intact while comparing. Reverting software does not convert save identities or layouts; old/new save migration is separate work. The loading screen also remains in current code for **unfinished new-game generation**, which still needs it.

### Target verification of stored tables

Seven engine groups pass, including real flash Save/Continue, all 608 source mappings, the Birch/naming lifecycle and short-intro handoff, cancellation, allocation pressure, damaged identity, damaged payload CRC, and an out-of-range destination with a deliberately recomputed valid CRC. Host round trips restore the sampled worlds with zero constructor attempts, compare all emitted records and reject truncation/payload damage. The 18-group host suite also passes with address/undefined-behavior sanitizers.

| Measurement | Seed 0 | Seed 42 |
|---|---:|---:|
| Complete Continue adapter, CPU/64 ticks | 32685 | 32206 |
| Approximate emulated time | 124.7 ms | 122.9 ms |
| Observed VBlank interrupts during call | 7 | 7 |
| Generation pumps on Continue | 0 | 0 |

The VBlank count independently checks that the 16-bit timing counter did not wrap. These are two controlled mGBA samples, not a bound for every future graph or physical hardware result. The table is freshly graph-validated; faster loading was not obtained by dropping progression-stage checks.

The normal ROM links at **235,972 bytes EWRAM**, **28,376 bytes IWRAM**, and **26,867,572 bytes ROM region use**. WrWork remains 17,320 bytes and WrActive 8,244 bytes on the target ABI. The EWRAM total includes the reserved engine heap, so it is not another free-heap allowance. Source/arrival/progression limitations remain unchanged by caching.


## League arrival hooks: following the actual code

Read the last three functions in warp_game.c together. `LeagueRoom` first checks that the randomizer table is valid, then compares the current map against four named target constants. Its result is the room's position in the Sidney/Phoebe/Glacia/Drake sequence, or -1 for no change. Explicit names keep a change in numerical map ordering from silently changing the rule.

`WarpRando_Arrival` runs immediately after `SetPlayerCoordsFromWarp` inside `WarpIntoMap` in overworld.c. It only adjusts rear event 1 of those four rooms to (6,3). The target event itself is at (6,2), on the north doorway. Front event 0 keeps its target coordinate (6,13). This applies to a new event-based arrival while the table is active, including a vanilla transition into one of these rooms; it does not intercept or randomize scripted destinations. Ordinary saved-map restoration does not call this coordinate hook.

`WarpRando_MapLoaded` runs at the end of `RunOnLoadMapScript` in script.c, after the vanilla script. It sets `VAR_ELITE_4_STATE` to room index + 1. Each room's OnFrame table triggers its forced entrance walk on the preceding value, so the walk is no longer scheduled. It opens the centre tiles of both doors: (6,1)/(6,2) and (6,12)/(6,13). `MapGridSetMetatileIdAt` copies the ID and collision bits while preserving elevation; these named open tiles have no impassability bits. The surrounding panels remain as the vanilla script left them. Map initialization draws the resulting layout; no new task, animation callback or per-frame check is required.

Both `InitMap` and `InitMapFromSavedGame` run this OnLoad hook. That matters because vanilla OnLoad can close the entrance again based on a defeated flag or the shared League state. We repair the doorway after it, consistently on entry and reload, without clearing victories. A valid saved table activates exactly the same behavior as a newly generated table.

For **manual integration**, add `WarpRando_Arrival();` immediately after `SetPlayerCoordsFromWarp();` in `WarpIntoMap`. Add `#include "warp_game.h"` to script.c and `WarpRando_MapLoaded();` immediately after `MapHeaderRunScriptType(MAP_SCRIPT_ON_LOAD);` in `RunOnLoadMapScript`. These additions are already in the clean-target integration.patch.

For an **already installed saved-table edition**, replace the adapter C/header and test file, then add those two calls and the script.c include. No save-layout change or regeneration is needed for that upgrade. `arrival-compatibility.patch` upgrades the preceding saved-table *compact source folder*, including its guides and integration.patch; check it with `git apply --check` before applying. It is not a patch to apply directly to the game checkout. Existing older seed-only installations still need the saved-table storage upgrade described above. The included saved-table.patch now upgrades that older compact folder directly to the current maintained source; upgrade patches themselves and archive bytes are supplied by this ZIP, not recursively embedded in each patch.

### Target evidence and its limits

The League regression loads real target map layouts and executes their actual vanilla OnLoad scripts. Its matrix is 4 rooms × 2 entrances × 6 prior state values × 2 defeated states = 96 arrivals. It checks landing coordinates, north/south doorway collision, the absence of a matching forced-walk OnFrame script, and preservation of all four defeat flags. It exercises both ordinary exits from every room through the actual SetupWarp hook. A stored-table Continue followed by saved-map initialization preserves an interior saved coordinate and passable doors. It also checks that an unrelated map keeps the League state, and that an invalid table leaves the vanilla rear coordinate and forced-walk script intact.

This is engine-state verification in the target's headless emulator. It is not a recorded player walkthrough, a visual animation review, a completed Elite Four battle, or a Champion run. Battle availability is supported by unchanged battle scripts and preserved defeat flags, rather than an automated battle interaction. The existing flash Save/Continue regression tests serialization separately; the League fixture specifically tests stored-table restoration and saved-map initialization.

### Starting-state contract and first HM audit

Our current choice is to retain the normal opening. A useful checkpoint for a future route test is: starter obtained, player under normal overworld control, able to walk from Littleroot through Route 101 into Oldale. Route101's `BirchsBag` script sets the starter/rescue flags, invokes `ChooseStarter`, heals the party and uses a scripted warp back to Birch's lab. That scripted destination and Littleroot's ordinary exits remain vanilla. The graph root is the Oldale Pokémon Center exterior event (`E,0,10,2`), a logical starting location rather than an instruction to enter that randomized door. The post-rival Pokédex return is a further opening milestone; reaching Oldale alone does not prove it. The route remains a source-traced expectation awaiting an actual opening walkthrough. The new-game state and excluded event behavior now also have direct target tests, described below.

Cut is the first concrete progression chain to verify. In world.json, `HOENN_CUT` currently requires the Rustboro Gym entrance `E,11,3,0` and Cut giver's house entrance `E,11,11,0`. In target scripts, Roxanne's defeated sequence grants `FLAG_BADGE01_GET`; the Cut giver supplies `ITEM_HM_CUT` and sets `FLAG_RECEIVED_HM_CUT`. The target field-move table separately gates Cut on the Stone Badge. A regression calls the real `IsFieldMoveUnlocked(FIELD_MOVE_CUT)` with the four badge/received-HM flag combinations: the badge decides this gate; the received-HM flag does not. This tests one prerequisite, not the entire ability to use Cut.

Finish the chain by playing from a fresh seed to both providers, winning the actual battle, collecting the HM, teaching a compatible party member, and cutting a real obstruction. Check both provider orders, revisits, Save/Continue, and that the opened path matches the graph edge. Until then the location-based grant is an abstraction, not verified gameplay progression. Do not label it a completed chain merely because the badge gate test passes.


The arrival edition passed nine target groups, including the two new League and Cut checks. The normal Expansion 1.17.0 ROM links at 235,972 bytes EWRAM, 28,376 bytes IWRAM and 26,867,828 bytes ROM: the compatibility code adds 256 ROM bytes to the preceding build and no measured RAM/save allocation. The portable generator and graph did not change; its previous 18-group host and sanitizer results remain applicable, rather than being represented as newly rerun gameplay tests.


## Opening and Cut checkpoint: using the new evidence

The preceding progression checkpoint passed **11 target groups** and **18 host groups**. Two new target groups exercise starting state and Cut's actual script instruction. This checkpoint changes the tests and reports, not the runtime, graph, seed identity, save format or pairing algorithm. Existing saved-table saves retain their worlds; no new save is required for this checkpoint.

### What the opening test establishes

With an active generated world, the test calls the real `NewGameInitData`. It confirms the truck map, an empty party, and unset starter/rescue/Pokédex/Stone Badge flags. It then sends every event in Littleroot and its five interiors through the actual ordinary SetupWarp implementation: all 13 keep their vanilla destination. An Oldale event still resolves through the randomizer. Finally, the coordinate-form destination used by Birch's rescue script lands in his lab at (6,5), unchanged.

That last check invokes the destination API with the script's parameters; it does not execute the rescue dialogue, starter chooser, first battle or subsequent walking. The target's bundled overworld-script testing interface explicitly supports isolated commands, not a running overworld. The included headless mGBA runner has no external button/screenshot interface. Completing the full route needs a graphical emulator session or an additional bounded input-and-frame driver. Do not mistake a flag assertion for passing the story sequence.

Use a fresh seed-0 game for the first actual walkthrough. Finish the truck/home sequence, meet the rival, select a starter and finish the initial encounter, return to Birch's lab, then walk north through Route 101 to Oldale. Continue to the Route 103 rival and back for the Pokédex. At each milestone check that dialogue ends, movement returns, required actors are present and the next passage is accessible. Save and Continue after the lab and after the Pokédex; confirm your position and party survive. Both player choices should eventually be checked because their house/rival scripts differ. Littleroot being excluded protects its doors, not every possible story-state assumption.

### What the Cut test establishes

The earlier test checked only `IsFieldMoveUnlocked`. The new test runs the real interpreter on `checkfieldmove FIELD_MOVE_CUT, TRUE`, the instruction used by `EventScript_CutTree`. It creates a Treecko, confirms the target says Treecko can learn Cut, and tests all eight combinations of badge present/absent, Cut known/unknown, and egg/not egg. The command selects the party member only when the badge and learned move are present and it is not an egg. An empty party is rejected. Once Cut is learned, clearing the received-HM flag does not prevent selection.

The test gives the move directly to establish the script gate. It does not earn the HM, navigate the teaching menu, fight Roxanne or remove a tree. In the real route, obtaining and teaching Cut are required interactions. The tree script next asks for confirmation, runs a field effect and removes the selected tree object; those steps remain outside this fixture.

### A reproducible graph route to the providers

`python3 test.py` now adds `cut_routes` to each of the 12 reference-world seed results in verification.json. This is generated evidence, not another maintained input. Each entry records the capabilities assumed **before Cut is granted**, plus an outward and return path between the Oldale root and each provider. A breadth-first search chooses a short path in that stage's graph. The ordinary validator still checks the complete world independently of the C generator.

For seed 0, the assumed capability list is empty. The Gym path has 15 graph edges and the Cut giver path has 10. These are graph edges, not footsteps or guaranteed usable doorways. A `randomized warp` edge uses the emitted table; a `reference connection` edge comes from world.json and may involve walking, a map connection, a fall or another vanilla transition. Human-readable labels are inherited from the old reference and can name floors differently from the target: for example `E,24,28` is the target's SeafloorCavern_Room1 despite its reference label saying F2. Use numerical node IDs to locate the actual target event; never paste coordinates from a label as an authoritative landing correction.

To print seed 0's routes after the host suite:

```sh
python3 - <<'PY'
import json
rows = json.load(open("verification.json"))
row = next(r for r in rows if r["case"] == "test_reference_world" and r["seed"] == 0)
routes = row["cut_routes"]
print("Assumed capabilities:", routes["assumed_capabilities"])
for provider in routes["providers"]:
    print("Provider:", provider["node"])
    for direction in ("outward", "return"):
        print(direction)
        for edge in provider[direction]:
            print(edge["from"], "->", edge["to"], edge["kind"], edge["to_label"])
PY
```

Follow those routes only as a test itinerary. Record the first mismatch: exact map/event, party, badges, story state, expected next node and actual obstruction. A blocked reference connection is evidence to revise that connection or add a prerequisite, not justification to clear every plot flag. A path through an unfamiliar cave also needs encounters and trainer battles checked. The full Cut chain remains incomplete until its interactions and a real cuttable obstruction pass in the game.

For this checkpoint, replace test.py, target_test.c and the three guides in your compact folder, regenerate verification.json by running the host suite, and copy target_test.c into the target test directory. Runtime source and integration.patch are unchanged from the arrival edition. `progression-checkpoint.patch` applies those changes to the immediately preceding arrival compact folder; the other included source-upgrade patches now also lead to this checkpoint. Apply only the upgrade appropriate to your starting version.


## Compatibility port: why map preparation is a separate hook

`WarpRando_PrepareMap` is the new helper at the end of warp_game.c. It runs **before** the vanilla OnTransition and OnLoad scripts, and only with a valid active randomizer table. `WarpRando_MapLoaded` still runs **after** OnLoad for the League door-tile correction. The order has a concrete reason: Norman's transition script chooses his position from the Gym state, and his load script opens doors from that state. Setting the state afterward would be too late.

The helper compares the current map with named 1.17.0 constants. In Mauville Gym it clears Wattson's hide flag, because Norman's ordinary reward script can hide Wattson even when a randomized route has not yet taken the player to his battle. It leaves Wattson's defeat flag, badge and reward state untouched.

In Petalburg Gym before `FLAG_SYS_GAME_CLEAR`, it derives `VAR_PETALBURG_GYM_STATE` from `FLAG_DEFEATED_PETALBURG_GYM`: 6 means first battle ready; 7 means post-battle dialogue. This is intentionally stronger than copying upstream's raw state assignment. Other badge rewards increment the same variable, so retaining it as a simple count could accidentally select the wrong Norman branch during out-of-order play. Earned victory determines the branch on each entry/load. Postgame state and rematch selection remain with the target scripts.

A zero Petalburg City state becomes 1 to remove the initial westward restriction; nonzero states, particularly the pending Surf escort state 4, are preserved. The in-Gym Wally actor is hidden and Norman is visible. The helper finds Norman's named object in the target map header and restores its canonical position in the saved object templates. This also repairs the tutorial position when continuing an older save in the Gym. No hard-coded old-fork object index or map coordinate is used for that restoration. It does not relocate the saved player.

The Gym's existing OnLoad then opens its entrance doors and handles its remaining trainer-door progression. No trainer is marked defeated. Norman's actual battle and Surf escort remain unchanged and still need a gameplay walkthrough; the early plotless port adds a Weather bypass after his badge. This adaptation skips the Wally catching tutorial on Gym entry; the Woods bypass is now ported, while the deeper Jagged Pass/Magma changes associated with the upstream tutorial remain deferred. See inventory G1 and P2 rather than assuming the whole tutorial dependency chain is finished.

### Install or upgrade

For a clean pinned target, use the current integration.patch and copy the runtime files as above. For an already integrated preceding checkpoint, recopy warp_game.c and warp_game.h. In script.c add `WarpRando_PrepareMap();` immediately before `MapHeaderRunScriptType(MAP_SCRIPT_ON_LOAD);` in `RunOnLoadMapScript`, and immediately before `MapHeaderRunScriptType(MAP_SCRIPT_ON_TRANSITION);` in `RunOnTransitionMapScript`. Keep the existing `WarpRando_MapLoaded();` after OnLoad. Copy the revised target_test.c for regression testing.

`compatibility-port.patch` upgrades the preceding progression compact source folder, including guides and integration.patch. As with the other compact-folder patches, do not apply it directly to the engine checkout. Only choose the patch matching your starting source version; the download already contains the complete current source and historical per-load archive. Save storage, format, graph fingerprint and generated pairs are unchanged. Existing saved-table worlds can load, but now use the documented Gym behavior. Keep an older ROM/save copy if you want the previous gameplay rules.

### Verification boundary

The new Gym group exercises 20 combinations of prior state 0–9 and defeated/not defeated through real transition/load scripts. It checks the resulting Norman state, canonical saved NPC position, open entrance collision, no Wally forced-frame script, visibility and unmodified badge/HM/victory flags. It checks saved-map initialization after stored-table Continue, preservation of the Surf escort state, the postgame rematch guard, Wattson availability and disabled behavior when the table is invalid. These are target engine-state tests; they do not constitute completed battles, visual path tests or proof that every plotless dependency has been ported.

The graph still requires the four earlier Gym locations before deriving its modeled Surf capability. Allowing an earlier Norman battle does not update those rules or make room access equivalent to earning Surf. When the reward/provider groups are ported, review those prerequisites together rather than claiming the graph now mirrors every interaction.


Gym-port verification: **12 target groups passed** in the bundled headless mGBA runner, and the normal pinned-target ROM builds. Linked usage is 235,972 bytes EWRAM, 28,376 bytes IWRAM and 26,867,956 bytes ROM: 128 additional ROM bytes, no additional RAM or save storage versus the preceding runtime. The portable generator, graph and host tests are unchanged; the preceding 18 host-group pass remains the applicable result, not a newly rerun suite.


## Early plotless reward port: control flow and installation

Four small native specials live in the existing warp_game.c and are declared in warp_game.h. Their registrations are appended to data/specials.inc, preserving the IDs of existing specials. All changes remain conditional on a valid active randomizer table; no new saved mode flag is allocated.

* `WarpRando_RustboroAfterBattle` replaces the city-state write in Roxanne's defeated sequence. With an active table it initializes only state zero; without a table it performs the original state-1 write. This prevents a first Roxanne win from undoing a Devon sequence reached earlier through randomized doors.
* `WarpRando_DevonReward` runs at the beginning of the existing Rock Tomb reward. It requires the Stone Badge and returns 0 for no announcement/inactive mode, 1 for newly enabled Nav setup, or 2 when the needed Letter cannot fit. The script sends result 2 to the ordinary bag-full message, announces result 1, then gives Rock Tomb normally. Letter addition happens before the helper changes Nav/Devon state. If Rock Tomb itself cannot fit afterward, its existing retry path is retained; the earlier Letter is not duplicated.
* `WarpRando_VolcanoReward` runs after Wattson's badge flag is set. It prepares Meteor Falls, Mt. Chimney and the cable-car access flags, then calls the Weather helper.
* `WarpRando_WeatherReward` runs after Norman's badge too. Either the Dynamo or Balance Badge permits this plotless bypass. It clears the Route119 Aqua blockade, hides the additional second-floor grunt, and adjusts worker visibility. It never grants Surf or Castform.

The helpers do not run on every warp. They are reward events. The Woods bypass is different: it is part of Petalburg Gym preparation because this mode skips the Wally tutorial that applied it upstream. Its state advances from zero to one without resetting a later state. None of these helpers claims a new battle victory for the player; the Mt. Chimney story-completion flag explicitly skips that villain confrontation as part of the selected plotless rules.

The Letter helper uses existing item/delivery flags instead of a new bookkeeping flag. A Letter in the bag is retained; a delivered Letter is not reissued. Advanced Rustboro/Devon states remain advanced. An already-open Rusturf Tunnel keeps its departed couple hidden. Briney is initialized at home only when his location is zero and Norman's badge has not been earned. This preserves later travel state and Norman's removal. The tests cover these cases; they do not prove that all transport interactions are already safe in randomizer mode.

### Upgrade from the preceding Gym-port target

For a clean pinned checkout, the current integration.patch contains all nine modified engine/data files; copy the current runtime C/headers and generated header as usual.

For a checkout with the **immediately preceding Gym port already installed**, run from the target repository:

```sh
git apply --check /path/to/early-plot-target.patch
git apply /path/to/early-plot-target.patch
```

This incremental patch updates the installed adapter C/header, special table and three Gym scripts together. Do not apply both it and the clean-target integration.patch. Copy the current target_test.c to test/warp_compact.c when running the expanded regressions. Replace your compact development folder with the current source from this download so future builds use the same code. Older compact-folder upgrade patches retain their documented starting versions; they are not substitutes for this installed-target patch.

For manual integration, copy the adapter files, append the four `def_special` entries, and apply the three small Gym-script hunks shown in integration.patch. The Roxanne hunk includes both the guarded city-state special and the item-reward branch/message; installing only the latter loses the earlier-state protection. Wattson and Norman call their helper immediately after their corresponding badge flag is set.

The save layout and generator are unchanged, but earlier saves do not automatically replay already-completed reward scripts. **Use a fresh save for a coherent acceptance run of this expanded gameplay ruleset.** Loading an old table successfully establishes format compatibility, not migration of old plot progress.

### Target checks and limits

Two additional target groups execute the native instruction copied from each linked production script. This uses the real interpreter and special table while deliberately stopping before dialogue/movement. Cases include no badge, a fully occupied key-item pocket, retry, repeated rewards, an already-delivered Letter, completed Rusturf progress, Briney's later location, later city states, stored-table Continue and disabled randomizer behavior. Volcano/Weather checks exercise both Wattson-first and Norman-first orders and confirm no HM/Castform reward is granted. The existing Gym fixture now also checks Woods bypass flags and preservation of a later Woods state.

The full battle/dialogue sequence, visible NPC changes and regional traversal still need a gameplay session. The generator, graph and host suite were not modified by this port, so the previous host results remain applicable; no new host run is claimed.


Current port verification: **14 target groups pass**, and the normal pinned-target ROM builds. Linked usage is 235,972 bytes EWRAM, 28,376 bytes IWRAM and 26,868,804 bytes ROM: 848 additional ROM bytes, with no additional RAM or save storage versus the preceding Gym port. Clean-target, compact-source upgrade and installed-target incremental patches are checked by applying them to their stated baselines and comparing the resulting files.
