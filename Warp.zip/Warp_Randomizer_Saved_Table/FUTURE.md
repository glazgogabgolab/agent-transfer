# What to improve next, and why

The purpose of this rewrite is to make the project small enough to reason about. The next changes should buy something concrete: a better match to the game, a demonstrated reduction in latency, or a clearer player experience. File count alone is not the objective. A second well-named helper can be cheaper to understand than a clever state machine hidden in one enormous function.

## The approach we chose

The constructor keeps a conservative progression model with compiled unconditional closure and incremental graph searches. It samples a few possible pairs, preserves the unused-exit frontier, repairs directed return obligations, and validates the emitted result independently. The engine adapter advances small steps during Birch’s speech, pauses during naming, and restores and validates a saved completed table on Continue.

This preserves on-device generation and the useful optimizations while dropping the historical include stack and alternate implementations. The measured loading cases finish sooner than the supplied C11B examples, with a different frame budget. That does not establish the best possible CPU efficiency or a universal frame bound.

The development direction is now a documented compatibility port from KittyPBoxx, keeping our compact generator. The inventory below defines the work by gameplay dependency, rather than discovering isolated exceptions indefinitely. Target tests and the opening/Cut itinerary remain acceptance tools for that port.

## Fix the model before trusting larger seed sweeps

The original audit reported 12 destination disagreements, one missing reference endpoint, 1,729 target-only events, two coordinate changes, and 13 unresolved excluded transitions. The later source-aware gate prevents known source/trigger confusion; it does not resolve all of those gameplay questions.

Use canonical map names and the target's map-group order to review each participating event. Numeric triples are compact runtime addresses, but fragile human identities. A future data compiler could accept map names and resolve numbers from the exact target checkout. That would eliminate some hand-maintained numeric risk while adding a modest build-time dependency.

A source signature should eventually include whatever actually matters to arrival: target event identity, coordinates, elevation, relevant collision/tile properties and any special arrival rule. A checksum of more files can detect change, but does not interpret it. Someone still needs to establish that the arrival is usable.

Choose a real starting contract. Either model the vanilla opening from its actual start or deliberately relocate the randomized mode after completing necessary tutorial setup. Verify party/control state and relevant scripts. Calling Oldale the graph root does not perform any of these actions.

Review capability providers against interactions, rather than marking a capability granted whenever a doorway is reached. Badges, HMs, story conversations and key items may have distinct prerequisites. The graph's current permanent-fact model handles AND prerequisites and OR alternatives, but not every restriction in the game.

Do not decide the Weather Institute or Flash behavior solely from names. Keep the current unavailable policy until target behavior is understood, then change the rule explicitly and start a new model identity. Also inspect actual routes that the conservative model omits: extra real travel can introduce access to an unmodeled trap, not merely help the player.

## Special transitions: separate questions, not one catch-all hook

For the step-by-step learning and implementation workflow, see “Tutorial: learning to implement the remaining transitions” in DOCS.md. Its proposed APIs and schema changes are future designs, not implemented runtime support.

A general warp setter does not tell us why the player is travelling or what state must be updated. Intercepting every call would make the code shorter while making its behavior much harder to understand. Give each family a declared policy.

| Transition | Questions before randomizing or modeling it |
|---|---|
| Scripted warps | Which script owns it? Is it repeatable? Does it set flags, move NPCs or assume a particular destination? |
| Dive/surface | Is a surface/underwater pair tied by coordinates? What capabilities, collision and return constraints apply? |
| Falls/holes/ledges | Is travel directed? Where can the player regain a safe exit? Is a remembered last warp involved? |
| Dynamic destinations | Which state chooses the destination? Does an arrival update the return slot? Can the same event mean different things later? |
| Escape Rope/Dig | Where are these allowed? Is the action repeatable, does it consume an item, and how is the escape destination remembered? |
| Teleport | Which heal location is remembered? Which maps allow the action? Does changing the last heal alter the solver state? |
| Whiteout | Which respawn scripts and recovery states apply? Is relying on defeat acceptable design? What resources are lost? |
| Ferries/Briney/cable car | What story flags, menus, vehicles or one-time sequences gate each route? Is the route symmetric? |
| Fly | Which destinations have been registered, where can Fly be used, and is it intended as a guaranteed recovery action? |

For each family, reasonable choices are: keep it vanilla and model its real effect; exclude its region from a supported preset; or implement a narrow explicit adapter. “Vanilla” is an implementation scope decision, not evidence that it is irrelevant to progression.

A truly repeatable fixed escape with known prerequisites can be an ordinary directed edge. A consumable escape is different. Treating a single Rope as an unlimited edge can produce a false safety proof. History-dependent teleport and whiteout destinations may require expanded state or a deliberately simplified mode rule.

## Progression and victory

The current rules assume permanent capabilities and repeatable travel. Consumable keys, mutually exclusive choices, one-time doors, disappearing NPCs and temporary restrictions do not fit that model automatically.

There are three practical approaches. First, intentionally simplify the randomized mode's story so the monotone model is true, and test each script change. Second, expand the solver state to include the relevant facts, accepting additional complexity and search cost. Third, restrict the supported preset to regions whose behavior already fits the simpler model. A small honest preset can be more useful than a full map with unsupported guarantees.

Champion completion needs a separate finish condition grounded in the engine. Reaching League room nodes or Steven's location is not equivalent to winning battles, triggering the Hall of Fame and seeing credits. Establish the intended badge/HM order, availability of required interactions, and a reproducible actual run. Combat balance is another constraint, not something doorway reachability proves.

Record the seed, model fingerprint, ROM build identity, significant progression steps, save/Continue observations and final outcome in a compact section of DOCS.md. Do not turn every run into another implementation layer.

## Ways to make generation simpler or faster

### What is implemented now

The first compact rewrite established a useful reference, but target tests exposed 64–102 second loading and multi-second pauses. This revision restores the effective C9/C10 ideas as a single maintained generator: build-time unconditional SCC closure, bitsets, alias indexes, sorted emission, incremental reachability and small resumable phases. It also removes repeated immutable-graph audits from gameplay while retaining independent checked validators for development.

The game pumps that job during Birch's speech with a small timer budget, pauses during naming, and adopts any unfinished job on a loading screen. This hides work in time the player already spends reading, but does not reduce CPU work. A red/green fading dot supplies activity and completion feedback without a second dialog flow.

### Improve measured efficiency before adding more scheduler layers

Current foreground target samples take about 8.6 and 12.2 emulated seconds. Measure changes against identical seeds, compiler flags, frame budgets and acceptance policy. Compare CPU ticks separately from elapsed frames. A larger per-frame budget may make loading finish earlier without improving the algorithm at all.

Queue operations process one component; initial closure and commit still contain larger bounded operations. If measured whole-frame cost approaches the deadline, split the specific expensive phase further. A per-edge cursor everywhere would enlarge the state machine and add overhead even where unnecessary. Keep a hard step-count ceiling or timer wrap guard if supporting arbitrary larger models.

A useful next optimization may be eliminating duplicate generic C validation code from the ROM build while retaining it in host tests. Another is shrinking fixed workspace maxima to generated dimensions. Both reduce memory/ROM with modest complexity, but variable-sized layout structures make the interface harder to teach. Measure actual stack and concurrent intro heap use before choosing.

### Decide how far background generation should extend

It can also run during naming or other safe screens, but that requires a deliberate pump hook and time budget for each callback. Naming uses timers 1/2 for RNG and resets tasks; the current independent job already survives that reset. Timer 3 still needs exclusive ownership while pumping. Avoid a global main-loop hook until all callbacks that could coexist with the workspace and indicator have been audited.

Do not let different numbers of frames produce different maps. Lock the seed once, keep randomness inside the job, and compare results with different pump sizes and naming delays. Never allow partial mappings into gameplay. Skipping the intro must still use the foreground completion gate. Resetting the console safely discards unfinished work; Continue restores and validates only a completed saved table.

Indicator alternatives include a short start/finish text popup, a spinner, or no decoration until a loading tail is needed. Text explains the dot's meaning but consumes more window/palette resources and must coexist with dialogue. A percentage is misleading when an attempt can restart. The current red-to-green dot is deliberately an activity/status signal, not a prediction.

### Backtrack instead of restarting an entire attempt

Store a small stack of committed pairs and untried alternatives. When the frontier dies, undo a recent pair and choose another partner. This can salvage late failures, but makes deterministic replay, state restoration and bounded execution harder.

A very shallow rollback, with a clear maximum depth and search budget, may be an understandable compromise. It must restore RNG policy and construction state consistently. Do not turn “retry until it works” into an unbounded loading screen.

### Use a region skeleton, then attach leaves

Construct a connected skeleton among regions with several free entrances before attaching one-exit interiors. This directly addresses frontier exhaustion and can be cheaper than trial closure after every choice.

The challenge is defining a region correctly under directed and conditional travel. A spanning tree over maps is insufficient. Return paths, capability gates and grouped entrances still require validation. A region approach could work particularly well for a deliberately restricted preset where those assumptions are verified.

### Start from a known safe layout and perform validated swaps

Begin with a target-approved coupled topology. Repeatedly select two pairs and reconnect their endpoints, accepting a swap only if the full validator still passes. This has a simple rollback story and always retains a valid layout.

The current reference's vanilla topology is not established as a safe starting layout, and not every vanilla event is a symmetric pair. Even with a valid start, local swaps may explore a narrow portion of possible worlds and introduce substantial bias. Measure diversity as well as acceptance and runtime. It is an experiment worth comparing, not a guaranteed shortcut.

### Move generation off-device

For maximum simplicity and responsiveness in the ROM, generate and validate one layout on the computer, then compile its table into ROM. Save a fingerprint of that exact table. The runtime becomes a small source-checked lookup, with no loading constructor or temporary workspace.

This changes the player-facing requirement: a new seed requires another build. It is therefore an alternative, not what this edition quietly does. A precomputed bank permits quick in-game selection but offers only finitely many worlds; hashing arbitrary seed text into a small bank does not create new layouts.

If the owner decides in-game generation is less important than simplicity, this is probably the largest architectural reduction available. Make that product decision explicitly.

### Use a stronger offline solver as a reference

Constraint programming, SAT/SMT or systematic search can express pairing and reachability constraints more directly, especially for small fixtures. Such a solver can produce counterexamples, assess whether the greedy sampler rejects solvable inputs, or generate a trusted comparison corpus.

A solver dependency is rarely the most comprehensible GBA runtime. It also cannot rescue an inaccurate world model. Keep it an optional development experiment unless its benefit is clear.

## Improvements that are not algorithm changes

A seed-entry screen should distinguish the requested seed from the accepted retry. Keep gameplay RNG separate. Show an understandable failure message on exhausted attempts rather than simply returning to title. If timings permit, show honest attempt/pair progress; a retry means work can be discarded, so do not imply a guaranteed remaining duration.

Saved tables are now implemented: 1,124 bytes for this graph and about 123–125 ms for the measured Continue validation calls. The preceding seed-only loading edition is archived. If future optional features need the remaining space, compare restoring that edition with storing representative partners or packed indexes; do not complicate the encoding without a measured need.

A mode toggle needs a save policy. Disabling randomization while standing in a randomized world can silently change topology. Prefer a separate build or mode identity chosen at new game until this behavior is designed. Old save migration should be an explicit converter, not a relaxed version check.

For diagnostics, report a short route to the first trap and the missing goal or requirement. A failure with an explanation is more useful than thousands of counters. A generated spoiler mapping keyed by map names would also help manual door testing without changing runtime behavior.

## Keep the project understandable as it grows

Maintain one source of world data, one active constructor and one acceptance policy. Keep experiments on branches or outside the maintained folder. When an experiment wins, replace the old implementation and put the essential reasoning in these documents; do not retain every predecessor as a production include.

Never remove a safeguard merely because its reason is obscure. First reduce its failure to a small example. Conversely, a historical measurement does not need a permanent runtime abstraction just because it once mattered. The goal is a codebase where a reader can explain what each piece protects and what evidence supports it.

## Compatibility port inventory (2026-09-16)

We are adopting upstream's map-randomizer gameplay accommodations deliberately, on Expansion 1.17.0, while retaining our generator, scheduler, source gate and saved table. This is a functional inventory of the identified runtime hooks, explicit map-rando branches, plotless branches and associated preset dependencies. It is **not an exhaustive historical diff of every unconditional change** in the old fork: the available pinned checkout is shallow. Unconditional map edits, trainer changes and further native behavior still require comparison before we claim equivalent gameplay.

The reference is Speedchoice commit `f539267677ec3686c7f22bae2a63dc6f1a5267e9`, whose README describes a 1.9.1 base with some 1.9.2 fixes. The target remains Expansion commit `e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7`. Review source behavior and named target constants; do not copy old numeric flags, coordinates or object IDs.

Source links: [README](https://github.com/KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9/blob/f539267677ec3686c7f22bae2a63dc6f1a5267e9/README.md), [central warp handling](https://github.com/KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9/blob/f539267677ec3686c7f22bae2a63dc6f1a5267e9/src/random_warps.c), [preset definition](https://github.com/KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9/blob/f539267677ec3686c7f22bae2a63dc6f1a5267e9/src/speedchoice.c), [new-game inventory](https://github.com/KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9/blob/f539267677ec3686c7f22bae2a63dc6f1a5267e9/src/new_game.c), [UPR generator](https://github.com/KittyPBoxx/upr-speedchoice-ex-gen9/blob/5abfca86134872dbb3c54fa48e5920b6549cfb69/src/main/java/com/dabomstew/pkrandom/romhandlers/emeraldex/EmeraldExWarpRandomizer.java).

### The preset is part of the specification

Read `gPresetMapRando`, not a nearby Race/Bingo preset. It selects `PLOT_FULL`, **EARLYSURF off and EARLYFLY off**, plus UI/combat/convenience choices. Consequently, the Surf/Strength reward swap in Rusturf Tunnel and Wally's house is not a requirement of this map-rando preset. The party-menu Dive badge exemption is a separate plotless behavior. Its applicability across menu and interaction paths must be checked on 1.17.0 before any port.

Current policy: preserve the vanilla Littleroot opening and its 13 excluded events; keep normal badge/HM acquisition unless an explicitly documented compatibility rule changes it; permit out-of-order access to battles; progressively port the story bypasses needed by the retained graph. Broad plotless compatibility is the destination, not something this first Gym port has already achieved. All implemented rules are enabled by a valid active table, not by a newly allocated save flag.

### Inventory and decisions

“Planned” means selected for further translation, not active in this ROM. “Audit” means the policy or target dependency is unresolved. The verification column states the gate still needed unless it explicitly says passed.

| ID | Upstream behavior / source entry | Decision and 1.17.0 implementation | Verification or dependency |
|---|---|---|---|
| A1 | `InterceptWarp`, duplicate proxy lookup | Keep our source-signature gate and five normalizations; do not replace with broad setter interception | Existing all-source target tests pass; special sources remain separate |
| A2 | `fixPositionAfterWarp`: outdoor, cave, tower, room corrections | Audit each against target coordinates and arrival movement; only E4 rear correction implemented | Per-entrance collision and animation checks; old labels are not authoritative |
| A3 | `warpNeedsXOffetShift` plus `fldeff_escalator.c` | Planned together; old descending escalator animation is mode-suppressed upstream | Coordinate correction alone is insufficient; test both directions and exits |
| A4 | Four E4 scripts and front/rear state fixes | Implemented adaptation: both doorways open, no forced entry walk, rear landing one tile inward | 96-case map/script/collision fixture passed; battles/visual walkthrough outstanding |
| G1 | Petalburg destination state and coordinate-return tutorial branch | Implemented adaptation: pre-Champion Norman state derives from his defeat flag; restore canonical NPC position; skip Wally Gym tutorial, open westward town state | 20-state target fixture plus saved-map reload; actual battle/Surf escort still needed |
| G2 | Mauville destination unhides Wattson | Implemented in map preparation; leave battle and reward scripts intact | Target visibility flag and no-awarded-victory checks; interaction walkthrough needed |
| G3 | Steven's house state/visibility and Dive/ticket reward script | Planned as one provider dependency group, not just setting state 1 | Audit automatic approach movement, reward duplication, downstream plot flags, tickets and Continue |
| P1 | Roxanne plotless reward: Letter, PokéNav, Devon/Briney setup | Implemented adaptation, with guarded Letter addition and non-regressing states | Linked reward command tests pass for full bag, retry, repeat and delivered Letter; full dialogue/Devon visit remains |
| P2 | Wally tutorial / Petalburg Woods / Jagged Pass plotless flags | Woods state and employee/grunt bypass implemented with G1; deeper Jagged Pass/Magma flags deferred | Woods state/flags tested; Magma dependency remains with W6 |
| P3 | Wattson plotless reward: Meteor Falls, Mt. Chimney, Weather Institute | Implemented at his badge reward using named target flags | Both Gym orders and repeat-state preservation tested; field traversal not yet proven |
| P4 | Norman plotless reward: Weather Institute workers/bridge | Implemented through shared Weather helper after his badge | Shared result tested without granting Surf or Castform |
| P5 | Tate/Liza plotless reward suppresses Space Center invasion | Planned with G3 and the Mossdeep/Seafloor sequence | Verify that Dive remains obtainable and no battle partner/script waits remain |
| P6 | Granite Cave Steven, Route120, MtChimney, SkyPillar_Outside plotless branches | Audit individually in dependency pass | Item delivery, Devon Scope visibility, volcano and tower entry assumptions |
| W1 | Every-warp Regi doors and per-destination Regice/Regirock/Registeel puzzle flags | Planned as puzzle-access group | Use named target maps; preserve encounters; check both sides of doors |
| W2 | New Mauville state; Jagged Pass state; Abandoned Ship storage-key flag; Sky Pillar Wallace flag | Audit per destination | Determine access bypass versus false reward claim; update corresponding graph prerequisite if changed |
| W3 | Sootopolis state, weather, Archie/Maxie/resident blockers, Cave of Origin expert, Gym door | Planned with W4 and G3 | Whole regional state transition; no blanket reset copied yet |
| W4 | Sootopolis map-rando Wallace positioning and Waterfall giver replacement | Planned provider port | NPC template, script, reward flag, bad bag/revisit cases, and graph Waterfall rule |
| W5 | Route120 Steven/Devon Scope and two Kecleon removals | Planned regional access review | Retain Scope acquisition and prevent Scorched Slab return traps |
| W6 | Mt Pyre/Magma Emblem and Jagged Pass guard handling | Planned item/visibility review | Inventory-dependent resets and repeat rewards; no unconditional item grant |
| W7 | Devon Goods flags opening Tunneler's Rest House and Devon 1F | Access flags implemented through P1 reward, not on every warp | Actual entrance/NPC traversal remains; explicit story-bypass flags are not inventory rewards |
| W8 | Slateport/Route110 Aqua, Route119 bridge, Space Center, Aqua Hideout entrance and cable-car blockers | Planned in regional groups with P3–P5 | Check field objects and scripts together; world graph must match actual access |
| W9 | Cycling Road flag clear; Slateport state-zero workaround | Audit separately | Upstream itself questions whether Slateport workaround is ROM-relevant; scope Cycling Road cleanup to proven need |
| S1 | Trick House reward-room door and level clamp | Planned together | Closed exit, level >7, repeat tent reward and return behavior |
| S2 | Lilycove Wailmer metatiles and Department Store 5F roof access | Planned regional access group | OnLoad/OnTransition order and repeat visits |
| S3 | Devon Corp 3F facing correction | Audit alongside A2 and P1 | Player-facing direction is meaningful only with the chosen arrival position |
| S4 | Meteor Falls Steven cave opened before credits | Planned | Target entrance metatiles, usable exit, and intended postgame encounter access |
| S5 | Sky Pillar Rayquaza availability/return and cry resets | Audit | Repeated encounters and story state; do not blindly respawn a caught legendary |
| T1 | Slateport and Lilycove harbor map-rando service-unavailable branches | Planned explicit transport policy | Upstream disables these ferries; ours still leaves them vanilla, so graph equivalence is not established |
| T2 | Briney, scripted/coordinate warps, Dive, falls, Dig/Rope, Teleport, whiteout | Audit route families; not all are randomized upstream either | Central `warpId == -1` path returns early; inspect caller-specific behavior |
| R1 | Teleport tool, sleeping bag, other tools and initial heal location | Planned recovery contract before importing escape assumptions | Real allowed-map and last-heal restrictions, first launch and Continue; no universal escape edge |
| R2 | Both bikes, running shoes and initial consumables | Audit traversal necessities separately from conveniences | Mach Bike/bike-switch requirements must match graph paths; do not duplicate the entire starting inventory |
| C1 | Plotless Dive badge exemption in `party_menu.c` | Audit both menu and interaction paths before port | Target centralized field-move API differs; Surf/Fly badge rules remain normal |
| C2 | EARLYSURF reward swap / EARLYFLY branches | Retain target normal behavior; those switches are off in the map-rando preset | Avoid accidentally importing Race/Bingo behavior |
| C3 | Always-obey, no catch EXP, fast catch, X items, combat speed, autosave, debug and menu changes | Leave out of compatibility port unless a concrete dependency is established | Combat balance/obedience assumptions still need declared gameplay policy |
| V1 | UPR EscapePaths priorities and `validateInOrderLogic` | Keep our independent validator; review graph assumptions against each ported group | Pinned equality-filter issue means upstream validation is not an oracle; full credits run required |

### Reproduce and extend the inventory

In the pinned upstream checkout, search `FLAG_MAP_RANDO` across src, data/maps and data/scripts; search `checkspeedchoice PLOTLESS`, `EARLYSURF` and `EARLYFLY` in scripts; inspect `gPresetMapRando`, new_game.c and native `CheckSpeedchoiceOption` callers. Read the full surrounding labels and downstream state consumers, not just matching lines. The mode flag appears in 14 map-script files; plot/early-HM branches add further files and native paths. These counts describe search coverage, not proof that unconditional changes are all accounted for.

Explicit map-rando script coverage: the four Elite Four rooms, SkyPillar_Top, Route110_TrickHouseEnd, both harbor scripts, PetalburgCity, SootopolisCity, LilycoveCity_DepartmentStore_5F, LilycoveCity, RustboroCity_DevonCorp_3F and MeteorFalls_1F_1R. Plot/early-HM coverage additionally includes GraniteCave_StevensRoom, PetalburgCity_Gym, MauvilleCity_Gym, MossdeepCity_Gym, MossdeepCity_StevensHouse, MtChimney, Route120, Route110, Route119, PetalburgCity_WallysHouse, RusturfTunnel, RustboroCity_Gym and SkyPillar_Outside. Some sets overlap in purpose without sharing a mode flag.

For each retained group: identify the 1.17.0 actors and state variables; choose when the rule runs; ensure its reward scripts cannot undo it later; update graph prerequisites if gameplay meaning changes; test entry, interaction and reload. Record omissions explicitly. Do not invent a large generic rule framework: a named helper or a direct map-script branch is easier to review at this scale.

### Next dependency group

The early P1/P3/P4 reward port and Woods portion of P2 are implemented. Next handle G3/P5/W3/W4 as the linked Dive/Space Center/Seafloor/Sootopolis/Waterfall group. Keep the deeper Magma/Jagged Pass part of P2 with W6. Do not mark whole upstream families complete merely because a subset of their state writes is ported.

Keep the opening/Cut itinerary as an acceptance route rather than the sole method of discovering missing compatibility changes. Existing target tests establish initial truck/party state, all Littleroot exclusions, the Cut script eligibility gate, source mappings, League/Gym preparation and saved-table restoration. The full opening, HM acquisition/teaching/tree removal, visual arrival review, battles and Champion/credits remain unproven.


### Early reward port adaptations and outstanding gates

The current port invokes small native helpers from the existing Gym scripts instead of introducing Speedchoice's option system or copying a long script block three times. A separate guarded helper replaces Roxanne's early city-state write: a player can reach Devon before defeating her, so preserving progress only at the later item-reward hook would be too late.

Intentional differences from the old fork: do not copy its unexplained numeric flag 2050; do not repeatedly grant the Letter; do not reset later Rustboro/Devon/Meteor Falls/Weather states; do not bring back Briney after Norman or move him back from another port; do not respawn Wanda after the reunion. The 1.17.0 bypass also hides Meteor Falls' Magma actors and the Weather Institute's separately flagged second-floor grunt. These actors have distinct target flags; blindly copying only the old list would leave part of the skipped scenes present. Rustboro's rival visibility is left to target progression rather than unconditionally respawned by the reward.

The tests execute the native-call instruction taken from each linked production reward script, stopping before dialogue and animation. They establish actual special-table wiring and state/item behavior, not complete reward conversations or completed battles. Remaining acceptance work: finish each battle, observe the new Roxanne message and Rock Tomb retry, visit Devon and Briney, walk the Woods/volcano/Weather routes, collect the intended provider rewards, and repeat after real Save/Continue. Plotless state 2 at the Weather Institute does not mean Castform has been awarded.

No automatic migration replays past reward events. Older saved-table saves retain their bytes/pairings, but may lack a bypass tied to an already-completed battle. Use a fresh game for the port's acceptance run; a future migration would need explicit versioned gameplay-state handling. The graph's unavailable WEATHER_INSTITUTE condition is still unchanged: implementing game flags is not sufficient justification to silently grant a graph capability.
