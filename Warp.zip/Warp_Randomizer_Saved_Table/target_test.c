/* Target-only regression tests for the compact implementation.
 * Copy to target/test/warp_compact.c after applying integration.patch.
 * Run with the target's TESTS=WarpCompact: filter. See DOCS.md.
 * These expected hashes were independently obtained from the host core and
 * validated by test.py; they hash all 608 physical source/landing pairs. */
#include "global.h"
#include "test/test.h"
#include "test_runner.h"
#include "warp_rando.h"
#include "warp_game.h"
#include "warp_data.h"
#include "main.h"
#include "malloc.h"
#include "overworld.h"
#include "fieldmap.h"
#include "load_save.h"
#include "save.h"
#include "sprite.h"
#include "palette.h"
#include "random.h"
#include "new_game.h"
#include "constants/rgb.h"
#include "constants/maps.h"
#include "constants/vars.h"
#include "constants/flags.h"
#include "constants/metatile_labels.h"
#include "constants/map_scripts.h"
#include "event_data.h"
#include "field_move.h"
#include "pokemon.h"
#include "item.h"
#include "constants/script_commands.h"
#include "constants/event_objects.h"
#include "script.h"
#include <string.h>

#define EXPECT_SOURCE_HASH_0 0x2aae3861u
#define EXPECT_SOURCE_HASH_42 0x1d5c1c6au

void WarpRando_TestSetupWarp(s8 warpId, struct MapPosition *position);
static MainCallback sReturn;
static u8 sSuccess, sFailure;

static void Success(void)
{
    sSuccess++;
    SetMainCallback2(sReturn);
}

static void Failure(void)
{
    sFailure++;
    SetMainCallback2(sReturn);
}

static u32 FreeBytes(void)
{
    const struct MemBlock *head = HeapHead(), *block = head;
    u32 total = 0;
    do
    {
        if (!block->allocated)
            total += block->size;
        block = block->next;
    } while (block != head);
    return total;
}

static u32 LargestBlock(void)
{
    const struct MemBlock *head = HeapHead(), *block = head;
    u32 largest = 0;
    do
    {
        if (!block->allocated && block->size > largest)
            largest = block->size;
        block = block->next;
    } while (block != head);
    return largest;
}

static void Begin(const u8 *save)
{
    sReturn = gMain.callback2;
    sSuccess = sFailure = 0;
    gMain.heldKeys = 0;
    if (save) {
        REG_TM2CNT_H = 0;
        REG_TM2CNT_L = 0;
        REG_TM2CNT_H = TIMER_ENABLE | TIMER_64CLK;
        u32 framesBefore = gMain.vblankCounter1;
        WarpRando_Continue(save, Success, Failure);
        u16 ticks = REG_TM2CNT_L;
        u32 frames = gMain.vblankCounter1 - framesBefore;
        REG_TM2CNT_H = 0;
        EXPECT(frames < 14); /* Independent check that the 16-bit timer did not wrap. */
        Test_MgbaPrintf("WRCOMPACT saved_table_load_vblanks=%d", frames);
        Test_MgbaPrintf("WRCOMPACT saved_table_load_ticks=%d generation_pumps=%d", ticks, WarpRando_Metrics()->pumps);
        EXPECT_EQ(WarpRando_Metrics()->pumps, 0);
    }
    else
        WarpRando_NewGame(Success, Failure);
}

static void Pump(int cancelAt)
{
    u32 step = 0, maximum = 0, maximumStep = 0, total = 0;
    u16 previous;
    u32 oldTimeout = gTestRunnerState.timeoutSeconds;
    gTestRunnerState.timeoutSeconds = 300;
    REG_TM2CNT_H = 0;
    REG_TM2CNT_L = 0;
    REG_TM2CNT_H = TIMER_ENABLE | TIMER_64CLK;
    previous = REG_TM2CNT_L;
    while (gMain.callback2 != Success && gMain.callback2 != Failure && step < 5000)
    {
        u32 before, elapsed;
        VBlankIntrWait();
        gMain.heldKeys = cancelAt >= 0 && step == (u32)cancelAt ? B_BUTTON : 0;
        before = REG_TM2CNT_L;
        gMain.callback2();
        elapsed = (u16)(REG_TM2CNT_L - before);
        total += (u16)(REG_TM2CNT_L - previous);
        previous = REG_TM2CNT_L;
        if (elapsed > maximum)
        {
            maximum = elapsed;
            maximumStep = step;
        }
        step++;
    }
    REG_TM2CNT_H = 0;
    gMain.heldKeys = 0;
    EXPECT(step < 5000);
    if (gMain.callback2 == Success || gMain.callback2 == Failure)
        gMain.callback2();
    gTestRunnerState.timeoutSeconds = oldTimeout;
    Test_MgbaPrintf("WRCOMPACT cpu_ticks=%d max_step_ticks=%d max_pump_ticks=%d",
                    WarpRando_Metrics()->cpuTicks, WarpRando_Metrics()->maxStepTicks,
                    WarpRando_Metrics()->maxPumpTicks);
    Test_MgbaPrintf(
        "WRCOMPACT run steps=%d ticks=%d max_callback_ticks=%d max_step=%d success=%d failure=%d",
        step, total, maximum, maximumStep, sSuccess, sFailure);
}

static u32 CheckAllSources(void)
{
    u16 i;
    u32 hash = 2166136261u;
    for (i = 0; i < WR_SOURCE_COUNT; i++)
    {
        const struct WrSourceRoute *r = &wr_source_routes[i];
        const struct MapHeader *map =
            Overworld_GetMapHeaderByGroupAndId(r->source.group, r->source.map);
        const struct WarpEvent *event = &map->events->warps[r->source.warp];
        s8 dg = event->mapGroup, dm = event->mapNum, dw = event->warpId;
        u8 bytes[6], j;
        EXPECT_EQ(event->x, r->x);
        EXPECT_EQ(event->y, r->y);
        EXPECT_EQ(event->elevation, r->elevation);
        EXPECT(WarpRando_Resolve(r->source.group, r->source.map, r->source.warp, event->x, event->y,
                                 event->elevation, &dg, &dm, &dw));
        bytes[0] = r->source.group;
        bytes[1] = r->source.map;
        bytes[2] = r->source.warp;
        bytes[3] = dg;
        bytes[4] = dm;
        bytes[5] = dw;
        for (j = 0; j < 6; j++)
            hash = (hash ^ bytes[j]) * 16777619u;
        dg = event->mapGroup;
        dm = event->mapNum;
        dw = event->warpId;
        EXPECT(!WarpRando_Resolve(r->source.group, r->source.map, r->source.warp, event->x ^ 1,
                                  event->y, event->elevation, &dg, &dm, &dw));
        EXPECT_EQ(dg, event->mapGroup);
        EXPECT_EQ(dm, event->mapNum);
        EXPECT_EQ(dw, event->warpId);
    }
    return hash;
}

static void CheckEngine(struct WrKey source, bool8 allowed)
{
    const struct MapHeader *map = Overworld_GetMapHeaderByGroupAndId(source.group, source.map);
    const struct WarpEvent *event = &map->events->warps[source.warp];
    s8 dg = event->mapGroup, dm = event->mapNum, dw = event->warpId;
    struct MapPosition position;
    EXPECT_EQ(WarpRando_Resolve(source.group, source.map, source.warp, event->x, event->y,
                                event->elevation, &dg, &dm, &dw),
              allowed);
    gSaveBlock1Ptr->location.mapGroup = source.group;
    gSaveBlock1Ptr->location.mapNum = source.map;
    gSaveBlock1Ptr->location.warpId = source.warp;
    gMapHeader = *map;
    position.x = event->x + MAP_OFFSET;
    position.y = event->y + MAP_OFFSET;
    position.elevation = event->elevation;
    WarpRando_TestSetupWarp(source.warp, &position);
    WarpIntoMap();
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, dg);
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, dm);
    EXPECT_EQ(gSaveBlock1Ptr->location.warpId, dw);
}

TEST("WarpCompact: generation, source gates, actual event hook and flash Continue")
{
    u32 before = FreeBytes(), largest = LargestBlock();
    u8 save[WARP_RANDO_SAVE_BYTES], replay[WARP_RANDO_SAVE_BYTES];
    struct WrIdentity identity;
    u16 attempt, i;
    Begin(NULL);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    EXPECT_EQ(sFailure, 0);
    EXPECT_EQ(FreeBytes(), before);
    EXPECT_EQ(LargestBlock(), largest);
    EXPECT(WarpRando_Save(save));
    EXPECT_EQ(wr_decode(&wr_graph, save, &identity, &attempt), WR_OK);
    EXPECT_EQ(identity.seed, 0);
    EXPECT_EQ(attempt, 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_0);
    for (i = 0; i < WR_SOURCE_COUNT; i++)
    {
        const struct WrSourceRoute *r = &wr_source_routes[i];
        if (memcmp(&r->expected, &r->trigger, sizeof(r->trigger)))
            CheckEngine(r->source, TRUE);
    }
    CheckEngine((struct WrKey){0, 10, 0}, TRUE);
    CheckEngine((struct WrKey){13, 8, 0}, FALSE);
    CheckEngine((struct WrKey){13, 8, 1}, FALSE);
    CheckEngine((struct WrKey){24, 33, 2}, FALSE);
    memcpy(gSaveBlock3Ptr->warpRando, save, sizeof(save));
    /* The runner replaces timer 2's flash IRQ with its watchdog. Flash needs
     * its real handler while saving, then the runner gets ownership back. */
    void (*watchdog)(void) = gIntrTable[7];
    InitFlashTimer();
    Save_ResetSaveCounters();
    EXPECT_EQ(TrySavingData(SAVE_NORMAL), SAVE_STATUS_OK);
    memset(gSaveBlock3Ptr->warpRando, 0, sizeof(save));
    EXPECT_EQ(LoadGameSave(SAVE_NORMAL), SAVE_STATUS_OK);
    EXPECT_EQ(memcmp(gSaveBlock3Ptr->warpRando, save, sizeof(save)), 0);
    REG_TM2CNT_H = 0;
    gIntrTable[7] = watchdog;
    Begin(gSaveBlock3Ptr->warpRando);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    EXPECT_EQ(sFailure, 0);
    EXPECT(WarpRando_Save(replay));
    EXPECT_EQ(memcmp(save, replay, sizeof(save)), 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_0);
    EXPECT_EQ(FreeBytes(), before);
    Test_MgbaPrintf("WRCOMPACT verified sources=%d SaveBlock3=%d WrWork=%d WrActive=%d flash=1",
                    WR_SOURCE_COUNT, sizeof(struct SaveBlock3), sizeof(struct WrWork),
                    sizeof(struct WrActive));
}

TEST("WarpCompact: cancellation before begin and mid-generation")
{
    u32 before = FreeBytes();
    u8 save[WARP_RANDO_SAVE_BYTES];
    Begin(NULL);
    Pump(0);
    EXPECT_EQ(sSuccess, 0);
    EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(save));
    EXPECT_EQ(FreeBytes(), before);
    Begin(NULL);
    Pump(3);
    EXPECT_EQ(sSuccess, 0);
    EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(save));
    EXPECT_EQ(FreeBytes(), before);
}

TEST("WarpCompact: allocation failure cleans up and rejects Continue corruption")
{
    u32 before = FreeBytes(), largest = LargestBlock();
    void *block = AllocZeroedUnchecked(largest - 10000);
    u8 bad[WARP_RANDO_SAVE_BYTES] = {0};
    EXPECT(block != NULL);
    Begin(NULL);
    Pump(-1);
    EXPECT_EQ(sSuccess, 0);
    EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(bad));
    Free(block);
    EXPECT_EQ(FreeBytes(), before);
    EXPECT_EQ(LargestBlock(), largest);
    Begin(bad);
    Pump(-1);
    EXPECT_EQ(sSuccess, 0);
    EXPECT_EQ(sFailure, 1);
}

TEST("WarpCompact: seed 42 second-attempt identity and corruption rejection")
{
    u8 saved[WARP_RANDO_SAVE_BYTES], actual[WARP_RANDO_SAVE_BYTES];
    u32 before;
    void WarpRando_TestNewSeed(uint32_t, MainCallback, MainCallback);
    sReturn = gMain.callback2;
    sSuccess = sFailure = 0;
    WarpRando_TestNewSeed(42, Success, Failure);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    EXPECT(WarpRando_Save(saved));
    before = FreeBytes();
    Begin(saved);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    EXPECT_EQ(sFailure, 0);
    EXPECT(WarpRando_Save(actual));
    EXPECT_EQ(memcmp(saved, actual, sizeof(saved)), 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_42);
    EXPECT_EQ(FreeBytes(), before);
    /* CRC damage must refuse entry without starting generation. */
    saved[16] ^= 1;
    Begin(saved);
    Pump(-1);
    EXPECT_EQ(sSuccess, 0);
    EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(actual));
}

void WarpRando_TestBirchStart(void);
void WarpRando_TestBirchNaming(void);
bool8 WarpRando_TestBirchIsMain(void);
void WarpRando_TestBirchCleanup(void);

static void SceneFrame(u16 keys)
{
    VBlankIntrWait();
    gMain.heldKeys = gMain.newKeys = keys;
    gMain.callback2();
}

TEST("WarpCompact: Birch background, naming pause, green fade and completed handoff")
{
    u32 i, pumps, maxCallback = 0, oldTimeout = gTestRunnerState.timeoutSeconds;
    u32 began, elapsed, maxFrame = 0, pumpsBefore, maxRunning = 0, maxHadWork = 0;
    rng_value_t rng;
    u8 save[WARP_RANDO_SAVE_BYTES];
    sReturn = gMain.callback2;
    gTestRunnerState.timeoutSeconds = 150;
    WarpRando_TestBirchStart();
    for (i = 0; i < 120; i++)
        SceneFrame(0);
    EXPECT(!WarpRando_Save(save));
    EXPECT(IndexOfSpritePaletteTag(0xFDF0) != 0xFF);
    pumps = WarpRando_Metrics()->pumps;
    WarpRando_TestBirchNaming();
    EXPECT(!WarpRando_TestBirchIsMain());
    EXPECT_EQ(IndexOfSpritePaletteTag(0xFDF0), 0xFF);
    for (i = 0; i < 100; i++)
        SceneFrame(0);
    EXPECT_EQ(WarpRando_Metrics()->pumps, pumps);
    SceneFrame(START_BUTTON);
    SceneFrame(0);
    SceneFrame(A_BUTTON);
    for (i = 0; i < 180 && !WarpRando_TestBirchIsMain(); i++)
        SceneFrame(0);
    EXPECT(WarpRando_TestBirchIsMain());
    EXPECT_EQ(WarpRando_Metrics()->pumps, pumps);
    rng = gRngValue;
    REG_TM2CNT_H = 0;
    REG_TM2CNT_L = 0;
    REG_TM2CNT_H = TIMER_ENABLE | TIMER_64CLK;
    for (i = 0; i < 4000 && !WarpRando_Save(save); i++)
    {
        VBlankIntrWait();
        gMain.heldKeys = gMain.newKeys = 0;
        pumpsBefore = WarpRando_Metrics()->pumps;
        began = REG_TM2CNT_L;
        gMain.callback2();
        elapsed = (u16)(REG_TM2CNT_L - began);
        if (elapsed > maxCallback)
        {
            maxCallback = elapsed;
            maxFrame = i;
            maxHadWork = WarpRando_Metrics()->pumps != pumpsBefore;
        }
        if (WarpRando_Metrics()->pumps != pumpsBefore && elapsed > maxRunning)
            maxRunning = elapsed;
    }
    REG_TM2CNT_H = 0;
    EXPECT(i < 4000);
    EXPECT_EQ(memcmp(&gRngValue, &rng, sizeof(rng)), 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_0);
    EXPECT(IndexOfSpritePaletteTag(0xFDF0) != 0xFF);
    EXPECT_EQ(gPlttBufferUnfaded[OBJ_PLTT_ID(IndexOfSpritePaletteTag(0xFDF0)) + 1], RGB_GREEN);
    pumps = WarpRando_Metrics()->pumps;
    for (i = 0; i < 100; i++)
        SceneFrame(0);
    EXPECT_EQ(WarpRando_Metrics()->pumps, pumps);
    EXPECT_EQ(IndexOfSpritePaletteTag(0xFDF0), 0xFF);
    WarpRando_TestBirchCleanup();
    sSuccess = sFailure = 0;
    WarpRando_NewGame(Success, Failure);
    EXPECT_EQ(gMain.callback2, Success);
    EXPECT_EQ(WarpRando_Metrics()->pumps, pumps);
    gMain.callback2();
    /* Exercise the real save-block reset that follows the handoff. */
    NewGameInitData();
    EXPECT(WarpRando_Save(gSaveBlock3Ptr->warpRando));
    EXPECT_EQ(memcmp(save, gSaveBlock3Ptr->warpRando, sizeof(save)), 0);
    EXPECT_EQ(sSuccess, 1);
    Test_MgbaPrintf("WRCOMPACT intro pumps=%d cpu_ticks=%d max_step=%d max_pump=%d main_max=%d "
                    "naming_pause=1 ready_handoff=1",
                    pumps, WarpRando_Metrics()->cpuTicks, WarpRando_Metrics()->maxStepTicks,
                    WarpRando_Metrics()->maxPumpTicks, maxCallback);
    Test_MgbaPrintf("WRCOMPACT scene_max=%d busy_frames=%d main_max_frame=%d",
                    WarpRando_Metrics()->maxSceneTicks, WarpRando_Metrics()->busyFrames, maxFrame);
    Test_MgbaPrintf("WRCOMPACT main_work_max=%d main_max_had_work=%d", maxRunning, maxHadWork);
    gTestRunnerState.timeoutSeconds = oldTimeout;
}

TEST("WarpCompact: short Birch intro adopts unfinished work on loading screen")
{
    u32 pumps;
    u8 saved[WARP_RANDO_SAVE_BYTES];
    sReturn = gMain.callback2;
    sSuccess = sFailure = 0;
    WarpRando_TestBirchStart();
    for (u16 i = 0; i < 120; i++)
        SceneFrame(0);
    pumps = WarpRando_Metrics()->pumps;
    EXPECT(pumps > 0);
    EXPECT(!WarpRando_Save(saved));
    WarpRando_TestBirchCleanup();
    WarpRando_NewGame(Success, Failure);
    EXPECT_EQ(WarpRando_Metrics()->pumps, pumps);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    EXPECT_EQ(sFailure, 0);
    EXPECT_EQ(CheckAllSources(), EXPECT_SOURCE_HASH_0);
    EXPECT(WarpRando_Save(saved));
}

TEST("WarpCompact: stored table CRC and structurally invalid destinations fail closed")
{
    u8 save[WARP_RANDO_SAVE_BYTES];
    Begin(NULL); Pump(-1);
    EXPECT(WarpRando_Save(save));
    save[56] ^= 1;
    Begin(save); Pump(-1);
    EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(save));
    save[56] = save[57] = 0xFF;
    u32 crc = 0xFFFFFFFFu;
    for (u32 i = 0; i < sizeof(save) - 4; i++) {
        crc ^= save[i];
        for (u8 b = 0; b < 8; b++) crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
    crc = ~crc;
    for (u8 b = 0; b < 4; b++) save[sizeof(save) - 4 + b] = crc >> (8 * b);
    Begin(save); Pump(-1);
    EXPECT_EQ(sFailure, 1);
    EXPECT(!WarpRando_Save(save));
}

TEST("WarpCompact: League front rear state doors and saved map reload")
{
    static const u16 rooms[] = {MAP_EVER_GRANDE_CITY_SIDNEYS_ROOM,
                               MAP_EVER_GRANDE_CITY_PHOEBES_ROOM,
                               MAP_EVER_GRANDE_CITY_GLACIAS_ROOM,
                               MAP_EVER_GRANDE_CITY_DRAKES_ROOM};
    static const u16 flags[] = {FLAG_DEFEATED_ELITE_4_SIDNEY, FLAG_DEFEATED_ELITE_4_PHOEBE,
                               FLAG_DEFEATED_ELITE_4_GLACIA, FLAG_DEFEATED_ELITE_4_DRAKE};
    u8 save[WARP_RANDO_SAVE_BYTES];
    unsigned room, entry, state, defeated, i;
    Begin(NULL);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    for (room = 0; room < ARRAY_COUNT(rooms); room++)
        for (entry = 0; entry < 2; entry++)
            for (state = 0; state < 6; state++)
                for (defeated = 0; defeated < 2; defeated++)
                {
                    VarSet(VAR_ELITE_4_STATE, state);
                    for (i = 0; i < ARRAY_COUNT(flags); i++)
                        if (defeated) FlagSet(flags[i]); else FlagClear(flags[i]);
                    SetWarpDestinationToMapWarp(MAP_GROUP(rooms[room]), MAP_NUM(rooms[room]), entry);
                    WarpIntoMap();
                    EXPECT_EQ(gSaveBlock1Ptr->pos.x, 6);
                    EXPECT_EQ(gSaveBlock1Ptr->pos.y, entry ? 3 : 13);
                    InitMap(); /* Real layout and real vanilla OnLoad, then adapter. */
                    EXPECT_EQ(VarGet(VAR_ELITE_4_STATE), room + 1);
                    EXPECT_EQ(MapHeaderCheckScriptTable(MAP_SCRIPT_ON_FRAME_TABLE), NULL);
                    for (i = 0; i < ARRAY_COUNT(flags); i++)
                        EXPECT_EQ(FlagGet(flags[i]), defeated);
                    EXPECT_EQ(MapGridGetMetatileIdAt(6 + MAP_OFFSET, 2 + MAP_OFFSET),
                              METATILE_EliteFour_OpenDoor_Opening);
                    EXPECT_EQ(MapGridGetMetatileIdAt(6 + MAP_OFFSET, 13 + MAP_OFFSET),
                              METATILE_EliteFour_OpenDoor_Opening);
                    EXPECT_EQ(MapGridGetCollisionAt(6 + MAP_OFFSET, 2 + MAP_OFFSET), 0);
                    EXPECT_EQ(MapGridGetCollisionAt(6 + MAP_OFFSET, 3 + MAP_OFFSET), 0);
                    EXPECT_EQ(MapGridGetCollisionAt(6 + MAP_OFFSET, 12 + MAP_OFFSET), 0);
                    EXPECT_EQ(MapGridGetCollisionAt(6 + MAP_OFFSET, 13 + MAP_OFFSET), 0);
                }
    EXPECT(WarpRando_Save(save));
    gSaveBlock1Ptr->pos.x = 4;
    gSaveBlock1Ptr->pos.y = 8;
    SaveMapView();
    Begin(save);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    InitMapFromSavedGame();
    EXPECT_EQ(gSaveBlock1Ptr->pos.x, 4);
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, 8);
    EXPECT_EQ(MapGridGetCollisionAt(6 + MAP_OFFSET, 13 + MAP_OFFSET), 0);
    EXPECT_EQ(MapHeaderCheckScriptTable(MAP_SCRIPT_ON_FRAME_TABLE), NULL);
    /* A non-League map must not change the shared League state. */
    VarSet(VAR_ELITE_4_STATE, 5);
    SetWarpDestinationToMapWarp(MAP_GROUP(MAP_OLDALE_TOWN), MAP_NUM(MAP_OLDALE_TOWN), 0);
    WarpIntoMap();
    WarpRando_MapLoaded();
    EXPECT_EQ(VarGet(VAR_ELITE_4_STATE), 5);
    for (room = 0; room < ARRAY_COUNT(rooms); room++)
        for (entry = 0; entry < 2; entry++)
            CheckEngine((struct WrKey){MAP_GROUP(rooms[room]), MAP_NUM(rooms[room]), entry}, TRUE);
    /* No valid randomizer table: preserve vanilla scripts and coordinates. */
    memset(save, 0, sizeof(save));
    Begin(save);
    Pump(-1);
    EXPECT_EQ(sFailure, 1);
    VarSet(VAR_ELITE_4_STATE, 0);
    FlagClear(FLAG_DEFEATED_ELITE_4_SIDNEY);
    SetWarpDestinationToMapWarp(MAP_GROUP(rooms[0]), MAP_NUM(rooms[0]), 1);
    WarpIntoMap();
    InitMap();
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, 2);
    EXPECT_EQ(VarGet(VAR_ELITE_4_STATE), 0);
    EXPECT(MapHeaderCheckScriptTable(MAP_SCRIPT_ON_FRAME_TABLE) != NULL);
    Test_MgbaPrintf("WRCOMPACT League: 96 arrivals, real OnLoad/collision, reload coordinates");
}

TEST("WarpCompact: Cut requires Stone Badge independently of receiving HM")
{
    bool8 badge = FlagGet(FLAG_BADGE01_GET), hm = FlagGet(FLAG_RECEIVED_HM_CUT);
    FlagClear(FLAG_BADGE01_GET);
    FlagClear(FLAG_RECEIVED_HM_CUT);
    EXPECT(!IsFieldMoveUnlocked(FIELD_MOVE_CUT));
    FlagSet(FLAG_RECEIVED_HM_CUT);
    EXPECT(!IsFieldMoveUnlocked(FIELD_MOVE_CUT));
    FlagSet(FLAG_BADGE01_GET);
    EXPECT(IsFieldMoveUnlocked(FIELD_MOVE_CUT));
    FlagClear(FLAG_RECEIVED_HM_CUT);
    EXPECT(IsFieldMoveUnlocked(FIELD_MOVE_CUT));
    /* This is the badge gate only, not the party/move or tree-use check. */
    if (!badge) FlagClear(FLAG_BADGE01_GET);
    if (hm) FlagSet(FLAG_RECEIVED_HM_CUT);
}


TEST("WarpCompact: real new game and all Littleroot event exclusions")
{
    static const u16 maps[] = {MAP_LITTLEROOT_TOWN,
        MAP_LITTLEROOT_TOWN_BRENDANS_HOUSE_1F, MAP_LITTLEROOT_TOWN_BRENDANS_HOUSE_2F,
        MAP_LITTLEROOT_TOWN_MAYS_HOUSE_1F, MAP_LITTLEROOT_TOWN_MAYS_HOUSE_2F,
        MAP_LITTLEROOT_TOWN_PROFESSOR_BIRCHS_LAB};
    unsigned i, warp, count = 0;
    Begin(NULL);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    NewGameInitData();
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, MAP_GROUP(MAP_INSIDE_OF_TRUCK));
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, MAP_NUM(MAP_INSIDE_OF_TRUCK));
    EXPECT_EQ(gPartiesCount[B_TRAINER_PLAYER], 0);
    EXPECT(!FlagGet(FLAG_SYS_POKEMON_GET));
    EXPECT(!FlagGet(FLAG_RESCUED_BIRCH));
    EXPECT(!FlagGet(FLAG_SYS_POKEDEX_GET));
    EXPECT(!FlagGet(FLAG_BADGE01_GET));
    EXPECT(WarpRando_Save(gSaveBlock3Ptr->warpRando));
    for (i = 0; i < ARRAY_COUNT(maps); i++)
    {
        const struct MapHeader *map = Overworld_GetMapHeaderByGroupAndId(
            MAP_GROUP(maps[i]), MAP_NUM(maps[i]));
        for (warp = 0; warp < map->events->warpCount; warp++)
        {
            CheckEngine((struct WrKey){MAP_GROUP(maps[i]), MAP_NUM(maps[i]), warp}, FALSE);
            count++;
        }
    }
    EXPECT_EQ(count, 13);
    CheckEngine((struct WrKey){MAP_GROUP(MAP_OLDALE_TOWN), MAP_NUM(MAP_OLDALE_TOWN), 0}, TRUE);
    /* The actual coordinate-form destination used by Birch's rescue script
     * bypasses ordinary event redirection and keeps its requested position. */
    SetWarpDestination(MAP_GROUP(MAP_LITTLEROOT_TOWN_PROFESSOR_BIRCHS_LAB),
                       MAP_NUM(MAP_LITTLEROOT_TOWN_PROFESSOR_BIRCHS_LAB), -1, 6, 5);
    WarpIntoMap();
    EXPECT_EQ(gSaveBlock1Ptr->location.mapGroup, MAP_GROUP(MAP_LITTLEROOT_TOWN_PROFESSOR_BIRCHS_LAB));
    EXPECT_EQ(gSaveBlock1Ptr->location.mapNum, MAP_NUM(MAP_LITTLEROOT_TOWN_PROFESSOR_BIRCHS_LAB));
    EXPECT_EQ(gSaveBlock1Ptr->pos.x, 6);
    EXPECT_EQ(gSaveBlock1Ptr->pos.y, 5);
    Test_MgbaPrintf("WRCOMPACT opening: truck/empty party, 13 vanilla events, scripted lab coordinate");
}

TEST("WarpCompact: actual Cut script command checks badge learned move and egg")
{
    /* Same instruction as EventScript_CutTree, using named opcode/enum values.
     * Run in the real interpreter; no dialog, animation or tree is simulated. */
    static const u8 checkCut[] = {SCR_OP_CHECKFIELDMOVE, FIELD_MOVE_CUT, TRUE, SCR_OP_END};
    struct Pokemon *mon = &gParties[B_TRAINER_PLAYER][0];
    unsigned badge, knows, egg;
    bool8 eggValue;
    ZeroPlayerPartyMons();
    CreateMon(mon, SPECIES_TREECKO, 10, 0, OTID_STRUCT_PRESET(0));
    EXPECT(CanLearnTeachableMove(SPECIES_TREECKO, MOVE_CUT));
    gPartiesCount[B_TRAINER_PLAYER] = 1;
    FlagSet(FLAG_RECEIVED_HM_CUT);
    for (badge = 0; badge < 2; badge++)
        for (knows = 0; knows < 2; knows++)
            for (egg = 0; egg < 2; egg++)
            {
                if (badge) FlagSet(FLAG_BADGE01_GET); else FlagClear(FLAG_BADGE01_GET);
                SetMonMoveSlot(mon, knows ? MOVE_CUT : MOVE_POUND, 0);
                eggValue = egg;
                SetMonData(mon, MON_DATA_IS_EGG, &eggValue);
                RunScriptImmediately(checkCut);
                EXPECT_EQ(gSpecialVar_Result, badge && knows && !egg ? 0 : PARTY_SIZE);
            }
    /* Once learned, inventory/received-HM flag is not a tree-use prerequisite. */
    eggValue = FALSE;
    SetMonData(mon, MON_DATA_IS_EGG, &eggValue);
    FlagClear(FLAG_RECEIVED_HM_CUT);
    RunScriptImmediately(checkCut);
    EXPECT_EQ(gSpecialVar_Result, 0);
    ZeroPlayerPartyMons();
    RunScriptImmediately(checkCut);
    EXPECT_EQ(gSpecialVar_Result, PARTY_SIZE);
    Test_MgbaPrintf("WRCOMPACT Cut: real interpreter, 8 badge/move/egg cases and empty party");
}


TEST("WarpCompact: Gym compatibility normalizes Norman without awarding victories")
{
    unsigned state, defeated, i;
    u8 save[WARP_RANDO_SAVE_BYTES];
    Begin(NULL);
    Pump(-1);
    EXPECT_EQ(sSuccess, 1);
    FlagClear(FLAG_SYS_GAME_CLEAR);
    FlagClear(FLAG_BADGE05_GET);
    FlagClear(FLAG_RECEIVED_HM_SURF);
    for (state = 0; state <= 9; state++)
        for (defeated = 0; defeated < 2; defeated++)
        {
            SetWarpDestinationToMapWarp(MAP_GROUP(MAP_PETALBURG_CITY_GYM),
                                       MAP_NUM(MAP_PETALBURG_CITY_GYM), 0);
            WarpIntoMap();
            LoadObjEventTemplatesFromHeader();
            SetObjEventTemplateCoords(LOCALID_PETALBURG_GYM_NORMAN, 4, 107);
            VarSet(VAR_PETALBURG_GYM_STATE, state);
            VarSet(VAR_PETALBURG_CITY_STATE, 0);
            if (defeated) FlagSet(FLAG_DEFEATED_PETALBURG_GYM);
            else FlagClear(FLAG_DEFEATED_PETALBURG_GYM);
            FlagSet(FLAG_HIDE_PETALBURG_GYM_NORMAN);
            FlagClear(FLAG_HIDE_PETALBURG_GYM_WALLY);
            VarSet(VAR_PETALBURG_WOODS_STATE, 0);
            FlagClear(FLAG_HIDE_PETALBURG_WOODS_DEVON_EMPLOYEE);
            FlagClear(FLAG_HIDE_PETALBURG_WOODS_AQUA_GRUNT);
            RunOnTransitionMapScript();
            InitMap();
            EXPECT_EQ(VarGet(VAR_PETALBURG_GYM_STATE), defeated ? 7 : 6);
            EXPECT_EQ(VarGet(VAR_PETALBURG_CITY_STATE), 1);
            EXPECT_EQ(FlagGet(FLAG_DEFEATED_PETALBURG_GYM), defeated);
            EXPECT(!FlagGet(FLAG_BADGE05_GET));
            EXPECT(!FlagGet(FLAG_RECEIVED_HM_SURF));
            EXPECT(!FlagGet(FLAG_HIDE_PETALBURG_GYM_NORMAN));
            EXPECT(FlagGet(FLAG_HIDE_PETALBURG_GYM_WALLY));
            EXPECT_EQ(VarGet(VAR_PETALBURG_WOODS_STATE), 1);
            EXPECT(FlagGet(FLAG_HIDE_PETALBURG_WOODS_DEVON_EMPLOYEE));
            EXPECT(FlagGet(FLAG_HIDE_PETALBURG_WOODS_AQUA_GRUNT));
            EXPECT_EQ(MapHeaderCheckScriptTable(MAP_SCRIPT_ON_FRAME_TABLE), NULL);
            EXPECT_EQ(MapGridGetCollisionAt(6 + MAP_OFFSET, 85 + MAP_OFFSET), 0);
            for (i = 0; i < gMapHeader.events->objectEventCount; i++)
                if (gSaveBlock1Ptr->objectEventTemplates[i].localId == LOCALID_PETALBURG_GYM_NORMAN)
                {
                    EXPECT_EQ(gSaveBlock1Ptr->objectEventTemplates[i].x, 4);
                    EXPECT_EQ(gSaveBlock1Ptr->objectEventTemplates[i].y, 2);
                    break;
                }
            EXPECT(i < gMapHeader.events->objectEventCount);
        }
    VarSet(VAR_PETALBURG_WOODS_STATE, 2);
    WarpRando_PrepareMap();
    EXPECT_EQ(VarGet(VAR_PETALBURG_WOODS_STATE), 2);
    /* Preserve the Surf escort's state, and repair saved templates on Continue. */
    VarSet(VAR_PETALBURG_CITY_STATE, 4);
    VarSet(VAR_PETALBURG_GYM_STATE, 9);
    SetObjEventTemplateCoords(LOCALID_PETALBURG_GYM_NORMAN, 4, 107);
    EXPECT(WarpRando_Save(save));
    SaveMapView();
    Begin(save);
    Pump(-1);
    InitMapFromSavedGame();
    EXPECT_EQ(VarGet(VAR_PETALBURG_CITY_STATE), 4);
    EXPECT_EQ(VarGet(VAR_PETALBURG_GYM_STATE), 7);
    /* Postgame rematch state is not reinterpreted as a first battle. */
    FlagSet(FLAG_SYS_GAME_CLEAR);
    VarSet(VAR_PETALBURG_GYM_STATE, 8);
    WarpRando_PrepareMap();
    EXPECT_EQ(VarGet(VAR_PETALBURG_GYM_STATE), 8);
    FlagClear(FLAG_SYS_GAME_CLEAR);
    /* Norman's reward script can hide Wattson before Wattson was defeated. */
    SetWarpDestinationToMapWarp(MAP_GROUP(MAP_MAUVILLE_CITY_GYM), MAP_NUM(MAP_MAUVILLE_CITY_GYM), 0);
    WarpIntoMap();
    FlagSet(FLAG_HIDE_MAUVILLE_GYM_WATTSON);
    FlagClear(FLAG_DEFEATED_MAUVILLE_GYM);
    FlagClear(FLAG_BADGE03_GET);
    InitMap();
    EXPECT(!FlagGet(FLAG_HIDE_MAUVILLE_GYM_WATTSON));
    EXPECT(!FlagGet(FLAG_DEFEATED_MAUVILLE_GYM));
    EXPECT(!FlagGet(FLAG_BADGE03_GET));
    /* Invalid table disables the compatibility preset. */
    memset(save, 0, sizeof(save));
    Begin(save);
    Pump(-1);
    EXPECT_EQ(sFailure, 1);
    FlagSet(FLAG_HIDE_MAUVILLE_GYM_WATTSON);
    InitMap();
    EXPECT(FlagGet(FLAG_HIDE_MAUVILLE_GYM_WATTSON));
    Test_MgbaPrintf("WRCOMPACT Gym compatibility: 20 Norman states, reload, rematch guard, Wattson");
}


extern const u8 RustboroCity_Gym_EventScript_GiveRockTomb[];
extern const u8 RustboroCity_Gym_EventScript_RandoCityState[];
extern const u8 MauvilleCity_Gym_EventScript_RandoPlotReward[];
extern const u8 PetalburgCity_Gym_EventScript_RandoPlotReward[];

/* Execute the native-call instruction from the linked production script,
 * stopping before its dialogue/movement. This checks real special-table wiring. */
static void RunRewardInstruction(const u8 *source)
{
    u8 script[6];
    unsigned size = source[0] == SCR_OP_SPECIALVAR ? 5 : 3;
    EXPECT(source[0] == SCR_OP_SPECIALVAR || source[0] == SCR_OP_SPECIAL);
    memcpy(script, source, size);
    script[size] = SCR_OP_END;
    RunScriptImmediately(script);
}

TEST("WarpCompact: Devon reward retries full bag and preserves completed progress")
{
    unsigned i;
    u8 save[WARP_RANDO_SAVE_BYTES];
    Begin(NULL);
    Pump(-1);
    NewGameInitData();
    /* No badge: the callable reward cannot grant progress prematurely. */
    RunRewardInstruction(RustboroCity_Gym_EventScript_GiveRockTomb);
    EXPECT_EQ(gSpecialVar_Result, 0);
    EXPECT(!CheckBagHasItem(ITEM_LETTER, 1));
    FlagSet(FLAG_BADGE01_GET);
    VarSet(VAR_RUSTBORO_CITY_STATE, 8);
    RunRewardInstruction(RustboroCity_Gym_EventScript_RandoCityState);
    EXPECT_EQ(VarGet(VAR_RUSTBORO_CITY_STATE), 8);
    VarSet(VAR_RUSTBORO_CITY_STATE, 0);
    RunRewardInstruction(RustboroCity_Gym_EventScript_RandoCityState);
    EXPECT_EQ(VarGet(VAR_RUSTBORO_CITY_STATE), 1);
    for (i = 0; i < gBagPockets[POCKET_KEY_ITEMS].capacity; i++)
        BagPocket_SetSlotItemIdAndCount(&gBagPockets[POCKET_KEY_ITEMS], i, ITEM_MACH_BIKE, 1);
    RunRewardInstruction(RustboroCity_Gym_EventScript_GiveRockTomb);
    EXPECT_EQ(gSpecialVar_Result, 2);
    EXPECT(!FlagGet(FLAG_RECEIVED_POKENAV));
    EXPECT(!FlagGet(FLAG_RECOVERED_DEVON_GOODS));
    EXPECT(!CheckBagHasItem(ITEM_LETTER, 1));
    ClearBag();
    RunRewardInstruction(RustboroCity_Gym_EventScript_GiveRockTomb);
    EXPECT_EQ(gSpecialVar_Result, 1);
    EXPECT_EQ(CountTotalItemQuantityInBag(ITEM_LETTER), 1);
    EXPECT(FlagGet(FLAG_SYS_POKENAV_GET));
    EXPECT(FlagGet(FLAG_HAS_MATCH_CALL));
    EXPECT(FlagGet(FLAG_RECOVERED_DEVON_GOODS));
    EXPECT_EQ(VarGet(VAR_BRINEY_LOCATION), 1);
    RunRewardInstruction(RustboroCity_Gym_EventScript_GiveRockTomb);
    EXPECT_EQ(gSpecialVar_Result, 0);
    EXPECT_EQ(CountTotalItemQuantityInBag(ITEM_LETTER), 1);
    FlagSet(FLAG_DELIVERED_STEVEN_LETTER);
    EXPECT(RemoveBagItem(ITEM_LETTER, 1));
    FlagSet(FLAG_RUSTURF_TUNNEL_OPENED);
    FlagSet(FLAG_HIDE_RUSTURF_TUNNEL_WANDA);
    FlagSet(FLAG_HIDE_RUSTURF_TUNNEL_WANDAS_BOYFRIEND);
    FlagSet(FLAG_BADGE05_GET);
    FlagSet(FLAG_HIDE_BRINEYS_HOUSE_MR_BRINEY);
    VarSet(VAR_BRINEY_LOCATION, 3);
    VarSet(VAR_RUSTBORO_CITY_STATE, 8);
    VarSet(VAR_DEVON_CORP_3F_STATE, 2);
    RunRewardInstruction(RustboroCity_Gym_EventScript_GiveRockTomb);
    EXPECT(!CheckBagHasItem(ITEM_LETTER, 1));
    EXPECT(FlagGet(FLAG_HIDE_RUSTURF_TUNNEL_WANDA));
    EXPECT(FlagGet(FLAG_HIDE_RUSTURF_TUNNEL_WANDAS_BOYFRIEND));
    EXPECT(FlagGet(FLAG_HIDE_BRINEYS_HOUSE_MR_BRINEY));
    EXPECT_EQ(VarGet(VAR_BRINEY_LOCATION), 3);
    EXPECT_EQ(VarGet(VAR_RUSTBORO_CITY_STATE), 8);
    EXPECT_EQ(VarGet(VAR_DEVON_CORP_3F_STATE), 2);
    EXPECT(WarpRando_Save(save));
    Begin(save);
    Pump(-1);
    RunRewardInstruction(RustboroCity_Gym_EventScript_GiveRockTomb);
    EXPECT_EQ(gSpecialVar_Result, 0);
    EXPECT(!CheckBagHasItem(ITEM_LETTER, 1));
    memset(save, 0, sizeof(save));
    Begin(save);
    Pump(-1);
    FlagClear(FLAG_RECEIVED_POKENAV);
    RunRewardInstruction(RustboroCity_Gym_EventScript_GiveRockTomb);
    EXPECT_EQ(gSpecialVar_Result, 0);
    EXPECT(!FlagGet(FLAG_RECEIVED_POKENAV));
    VarSet(VAR_RUSTBORO_CITY_STATE, 8);
    RunRewardInstruction(RustboroCity_Gym_EventScript_RandoCityState);
    EXPECT_EQ(VarGet(VAR_RUSTBORO_CITY_STATE), 1);
}

TEST("WarpCompact: plotless volcano and weather rewards work in either Gym order")
{
    unsigned order;
    Begin(NULL);
    Pump(-1);
    for (order = 0; order < 2; order++)
    {
        FlagClear(FLAG_BADGE03_GET);
        FlagClear(FLAG_BADGE05_GET);
        FlagClear(FLAG_HIDE_ROUTE_112_TEAM_MAGMA);
        FlagClear(FLAG_HIDE_ROUTE_119_TEAM_AQUA);
        VarSet(VAR_METEOR_FALLS_STATE, 0);
        VarSet(VAR_WEATHER_INSTITUTE_STATE, 0);
        RunRewardInstruction(MauvilleCity_Gym_EventScript_RandoPlotReward);
        RunRewardInstruction(PetalburgCity_Gym_EventScript_RandoPlotReward);
        EXPECT_EQ(VarGet(VAR_WEATHER_INSTITUTE_STATE), 0);
        EXPECT_EQ(VarGet(VAR_METEOR_FALLS_STATE), 0);
        FlagSet(order ? FLAG_BADGE05_GET : FLAG_BADGE03_GET);
        RunRewardInstruction(order ? PetalburgCity_Gym_EventScript_RandoPlotReward
                                  : MauvilleCity_Gym_EventScript_RandoPlotReward);
        EXPECT_EQ(VarGet(VAR_WEATHER_INSTITUTE_STATE), 2);
        EXPECT(FlagGet(FLAG_HIDE_ROUTE_119_TEAM_AQUA));
        EXPECT(FlagGet(FLAG_HIDE_WEATHER_INSTITUTE_2F_AQUA_GRUNT_M));
        EXPECT(!FlagGet(FLAG_HIDE_WEATHER_INSTITUTE_1F_WORKERS));
        EXPECT(FlagGet(FLAG_HIDE_WEATHER_INSTITUTE_2F_WORKERS));
        EXPECT_EQ(VarGet(VAR_METEOR_FALLS_STATE), order ? 0 : 1);
        FlagSet(order ? FLAG_BADGE03_GET : FLAG_BADGE05_GET);
        RunRewardInstruction(order ? MauvilleCity_Gym_EventScript_RandoPlotReward
                                  : PetalburgCity_Gym_EventScript_RandoPlotReward);
        EXPECT_EQ(VarGet(VAR_METEOR_FALLS_STATE), 1);
        EXPECT(FlagGet(FLAG_HIDE_ROUTE_112_TEAM_MAGMA));
        EXPECT(FlagGet(FLAG_HIDE_METEOR_FALLS_TEAM_MAGMA));
        EXPECT(FlagGet(FLAG_HIDE_METEOR_FALLS_TEAM_AQUA));
        EXPECT(FlagGet(FLAG_DEFEATED_EVIL_TEAM_MT_CHIMNEY));
        /* Retrying never lowers a later state or grants an HM/encounter reward. */
        VarSet(VAR_WEATHER_INSTITUTE_STATE, 3);
        VarSet(VAR_METEOR_FALLS_STATE, 2);
        FlagClear(FLAG_RECEIVED_CASTFORM);
        FlagClear(FLAG_RECEIVED_HM_SURF);
        RunRewardInstruction(MauvilleCity_Gym_EventScript_RandoPlotReward);
        EXPECT_EQ(VarGet(VAR_WEATHER_INSTITUTE_STATE), 3);
        EXPECT_EQ(VarGet(VAR_METEOR_FALLS_STATE), 2);
        EXPECT(!FlagGet(FLAG_RECEIVED_CASTFORM));
        EXPECT(!FlagGet(FLAG_RECEIVED_HM_SURF));
    }
}
