/* Engine ownership, frame scheduling and intro indicator. GPL-3.0-or-later. */
#include "global.h"
#include "warp_rando.h"
#include "warp_game.h"
#include "warp_data.h"
#include "main.h"
#include "malloc.h"
#include "bg.h"
#include "gpu_regs.h"
#include "menu.h"
#include "palette.h"
#include "util.h"
#include "sprite.h"
#include "text.h"
#include "text_window.h"
#include "window.h"
#include "overworld.h"
#include "constants/rgb.h"
#include "constants/maps.h"
#include "constants/vars.h"
#include "constants/flags.h"
#include "constants/event_objects.h"
#include "constants/metatile_labels.h"
#include "event_data.h"
#include "fieldmap.h"
#include "item.h"
#include <string.h>

STATIC_ASSERT(WARP_RANDO_SAVE_BYTES == WR_SAVE_BYTES + 2 * ARRAY_COUNT(idx_emit_nodes) + 4, WarpTableEncodingSize);
STATIC_ASSERT(sizeof(((struct SaveBlock3 *)0)->warpRando) == WARP_RANDO_SAVE_BYTES, WarpTableFieldSize);

/* Development seed. A future seed-entry screen can pass its value to Start.
 * Never use the gameplay RNG to make the individual pairing choices. */
#ifndef WARP_RANDO_SEED
#define WARP_RANDO_SEED 0u
#endif

EWRAM_DATA static struct WrActive sActive = {0};
EWRAM_DATA static struct WrJob sJob = {0};
EWRAM_DATA static struct WrWork *sWork = NULL;
EWRAM_DATA static MainCallback sSuccess = NULL;
EWRAM_DATA static MainCallback sFailure = NULL;
EWRAM_DATA static uint16_t sExpectedAttempt = 0;
EWRAM_DATA static bool8 sRestoring = FALSE;
EWRAM_DATA static bool8 sIntro = FALSE;
EWRAM_DATA static bool8 sHasIntro = FALSE;
EWRAM_DATA static bool8 sTimingIntro = FALSE;
EWRAM_DATA static u8 sDot = 0;
EWRAM_DATA static u16 sDoneFrames = 0;
EWRAM_DATA static struct WarpRandoMetrics sMetrics = {0};
/* Timer 3 is reserved while pumping. Timers 0/1 belong to audio/naming.
 * CPU/64: 262144 ticks per second. Budgets are soft: the last step can overrun. */
#define BACKGROUND_TICKS 524u
#define FOREGROUND_TICKS 2621u
#define DOT_TAG 0xFDF0
static const u32 sDotTiles[8] = {0x00011000, 0x00111100, 0x01111110, 0x11111111,
                                 0x11111111, 0x01111110, 0x00111100, 0x00011000};
static const struct SpriteSheet sDotSheet = {sDotTiles, sizeof(sDotTiles), DOT_TAG};
static const struct OamData sDotOam = {
    .shape = SPRITE_SHAPE(8x8), .size = SPRITE_SIZE(8x8), .priority = 0};
static const struct SpriteTemplate sDotTemplate = {.tileTag = DOT_TAG,
                                                   .paletteTag = DOT_TAG,
                                                   .oam = &sDotOam,
                                                   .anims = gDummySpriteAnimTable,
                                                   .images = NULL,
                                                   .affineAnims = gDummySpriteAffineAnimTable,
                                                   .callback = SpriteCallbackDummy};

const struct WarpRandoMetrics *WarpRando_Metrics(void)
{
    return &sMetrics;
}

static void ReleaseWork(void)
{
    if (sWork)
        Free(sWork);
    sWork = NULL;
}

void WarpRando_IntroHide(void)
{
    sIntro = FALSE;
    if (sDot != 0)
        DestroySprite(&gSprites[sDot - 1]);
    sDot = 0;
    FreeSpriteTilesByTag(DOT_TAG);
    FreeSpritePaletteByTag(DOT_TAG);
}

static void ShowDot(void)
{
    u32 palette;
    if (sDot != 0 || sDoneFrames >= 90)
        return;
    palette = AllocSpritePalette(DOT_TAG);
    if (palette == 0xFF)
        return; /* Cosmetic failure must not stop generation. */
    if (LoadSpriteSheet(&sDotSheet) == 0xFFFF)
    {
        FreeSpritePaletteByTag(DOT_TAG);
        return;
    }
    sDot = CreateSprite(&sDotTemplate, 232, 8, 0) + 1;
    if (sDot == MAX_SPRITES + 1)
    {
        sDot = 0;
        FreeSpriteTilesByTag(DOT_TAG);
        FreeSpritePaletteByTag(DOT_TAG);
    }
}

static int PumpWork(u16 budget)
{
    int result = sJob.result;
    u16 began, elapsed, before;
    if (!sWork)
        return result;
    REG_TM3CNT_H = 0;
    REG_TM3CNT_L = 0;
    REG_TM3CNT_H = TIMER_ENABLE | TIMER_64CLK;
    began = REG_TM3CNT_L;
    do
    {
        before = REG_TM3CNT_L;
        result = wr_advance(&sJob);
        elapsed = (u16)(REG_TM3CNT_L - before);
        if (elapsed > sMetrics.maxStepTicks)
            sMetrics.maxStepTicks = elapsed;
        elapsed = (u16)(REG_TM3CNT_L - began);
    } while (result == WR_PENDING && elapsed < budget);
    REG_TM3CNT_H = 0;
    sMetrics.pumps++;
    sMetrics.cpuTicks += elapsed;
    if (elapsed > sMetrics.maxPumpTicks)
        sMetrics.maxPumpTicks = elapsed;
    if (result == WR_OK && sRestoring && sActive.attempt != sExpectedAttempt)
    {
        wr_invalidate(&sActive);
        result = sJob.result = WR_BAD_IDENTITY;
    }
    if (result != WR_PENDING)
        ReleaseWork();
    return result;
}

static struct WrIdentity NewIdentity(void)
{
    struct WrIdentity identity = {WARP_RANDO_SEED, WR_ALGORITHM, 1, {0}};
    memcpy(identity.data, wr_graph.fingerprint, sizeof(identity.data));
    return identity;
}

static void BeginWork(const struct WrIdentity *identity, bool8 restoring, u16 attempt)
{
    ReleaseWork();
    memset(&sMetrics, 0, sizeof(sMetrics));
    wr_invalidate(&sActive);
    sRestoring = restoring;
    sExpectedAttempt = attempt;
    sWork = AllocZeroedUnchecked(sizeof(*sWork));
    if (!sWork)
    {
        memset(&sJob, 0, sizeof(sJob));
        sJob.active = &sActive;
        sJob.result = WR_BAD_DATA;
        return;
    }
    if (wr_begin(&sJob, &wr_graph, identity, 8, &sActive, sWork) != WR_PENDING)
        ReleaseWork();
}

void WarpRando_IntroStart(void)
{
    struct WrIdentity identity = NewIdentity();
    /* Called once, after Birch's sprite reset; naming resumes the same job. */
    sHasIntro = TRUE;
    sDoneFrames = 0;
    sDot = 0;
    BeginWork(&identity, FALSE, 0);
    sIntro = TRUE;
}

void WarpRando_IntroResume(void)
{
    sIntro = TRUE;
}

/* Start before the scene tasks so a busy text/graphics transition can get
 * this frame to itself. This uses the same reserved timer as PumpWork. */
void WarpRando_IntroFrameBegin(void)
{
    sTimingIntro = sIntro;
    if (!sTimingIntro)
        return;
    REG_TM3CNT_H = 0;
    REG_TM3CNT_L = 0;
    REG_TM3CNT_H = TIMER_ENABLE | TIMER_64CLK;
}

void WarpRando_IntroPump(void)
{
    u16 color, sceneTicks;
    if (!sTimingIntro)
        return; /* Intro initialization just ran this frame. */
    sceneTicks = REG_TM3CNT_L;
    REG_TM3CNT_H = 0;
    sTimingIntro = FALSE;
    if (!sIntro)
        return;
    if (sceneTicks > sMetrics.maxSceneTicks)
        sMetrics.maxSceneTicks = sceneTicks;
    if (sceneTicks < 1600) /* ~6.1 ms; leave margin for work, sprites and interrupts. */
        PumpWork(BACKGROUND_TICKS);
    else
        sMetrics.busyFrames++;
    ShowDot();
    color = sJob.result == WR_OK ? RGB_GREEN : RGB_RED;
    if (sJob.result == WR_OK && sDoneFrames < 90)
        sDoneFrames++;
    if (sDot != 0)
    {
        u8 palette = gSprites[sDot - 1].oam.paletteNum;
        LoadPalette(&color, OBJ_PLTT_ID(palette) + 1, sizeof(color));
        if (sDoneFrames > 30)
            BlendPalette(OBJ_PLTT_ID(palette) + 1, 1, (sDoneFrames - 30) * 16 / 60, RGB_WHITE);
        if (sDoneFrames >= 90)
        {
            DestroySprite(&gSprites[sDot - 1]);
            sDot = 0;
            FreeSpriteTilesByTag(DOT_TAG);
            FreeSpritePaletteByTag(DOT_TAG);
        }
    }
}

static const struct BgTemplate sBackground[] = {
    {.bg = 0,
     .charBaseIndex = 2,
     .mapBaseIndex = 31,
     .screenSize = 0,
     .paletteMode = 0,
     .priority = 0,
     .baseTile = 0},
};
static const struct WindowTemplate sWindow[] = {{.bg = 0,
                                                 .tilemapLeft = 1,
                                                 .tilemapTop = 5,
                                                 .width = 28,
                                                 .height = 8,
                                                 .paletteNum = 14,
                                                 .baseBlock = 20},
                                                DUMMY_WIN_TEMPLATE};
static const u8 sMessage[] = _("BUILDING WORLD\nB: CANCEL\nPreparing randomized entrances.");

static void VBlank(void)
{
    LoadOam();
    ProcessSpriteCopyRequests();
    TransferPlttBuffer();
}

static bool8 InitScreen(void)
{
    SetVBlankCallback(NULL);
    SetHBlankCallback(NULL);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    DmaFill16(3, 0, VRAM, VRAM_SIZE);
    DmaFill32(3, 0, OAM, OAM_SIZE);
    DmaFill16(3, 0, PLTT, PLTT_SIZE);
    ResetSpriteData();
    ResetPaletteFade();
    ResetBgsAndClearDma3BusyFlags(0);
    InitBgsFromTemplates(0, sBackground, ARRAY_COUNT(sBackground));
    if (!InitWindows(sWindow))
        return FALSE;
    DeactivateAllTextPrinters();
    FillBgTilemapBufferRect_Palette0(0, 0, 0, 0, DISPLAY_TILE_WIDTH, DISPLAY_TILE_HEIGHT);
    LoadUserWindowBorderGfx(0, 1, BG_PLTT_ID(13));
    Menu_LoadStdPalAt(BG_PLTT_ID(14));
    FillWindowPixelBuffer(0, PIXEL_FILL(1));
    DrawStdFrameWithCustomTileAndPalette(0, FALSE, 1, 13);
    AddTextPrinterParameterized(0, FONT_SMALL, sMessage, 8, 5, TEXT_SKIP_DRAW, NULL);
    PutWindowTilemap(0);
    CopyWindowToVram(0, COPYWIN_FULL);
    SetBackdropFromColor(RGB_BLACK);
    SetGpuReg(REG_OFFSET_DISPCNT, DISPCNT_MODE_0 | DISPCNT_BG0_ON);
    SetGpuReg(REG_OFFSET_BLDCNT, 0);
    ShowBg(0);
    SetVBlankCallback(VBlank);
    return TRUE;
}

static void Finish(int result)
{
    MainCallback next = result == WR_OK ? sSuccess : sFailure;
    if (result != WR_OK)
        wr_invalidate(&sActive);
    ReleaseWork();
    SetVBlankCallback(NULL);
    FreeAllWindowBuffers();
    HideBg(0);
    SetGpuReg(REG_OFFSET_DISPCNT, 0);
    SetMainCallback2(next);
}

static void Generate(void)
{
    int result;
    /* Cancellation is observed between operations, never during a graph walk. */
    if (JOY_HELD(B_BUTTON))
    {
        wr_cancel(&sJob);
        Finish(WR_CANCELLED);
        return;
    }
    result = PumpWork(FOREGROUND_TICKS);
    if (result != WR_PENDING)
    {
        Finish(result);
        return;
    }
    /* A pulse is activity only; retries can undo pairing progress. */
    FillWindowPixelRect(0, PIXEL_FILL((gMain.vblankCounter1 / 16) % 2 ? 4 : 2), 8, 58, 8, 4);
    CopyWindowToVram(0, COPYWIN_GFX);
    BuildOamBuffer();
    UpdatePaletteFade();
}

static void LoadingScreen(MainCallback success, MainCallback failure)
{
    sSuccess = success;
    sFailure = failure;
    if (!InitScreen())
    {
        Finish(WR_BAD_DATA);
        return;
    }
    SetMainCallback2(Generate);
}

void WarpRando_NewGame(MainCallback success, MainCallback failure)
{
    struct WrIdentity identity = NewIdentity();
    /* Intro completion survives NewGameInitData; save it after that reset. */
    if (sHasIntro)
    {
        sHasIntro = FALSE;
        WarpRando_IntroHide();
        if (sJob.result == WR_OK)
        {
            SetMainCallback2(success);
            return;
        }
    }
    else
        BeginWork(&identity, FALSE, 0);
    LoadingScreen(success, failure);
}

void WarpRando_Continue(const uint8_t *save, MainCallback success, MainCallback failure)
{
    int result = WR_BAD_DATA;
    WarpRando_IntroHide();
    sHasIntro = FALSE;
    ReleaseWork();
    wr_invalidate(&sActive);
    memset(&sMetrics, 0, sizeof(sMetrics));
    sWork = AllocZeroedUnchecked(sizeof(*sWork));
    if (sWork) {
        result = wr_table_begin(&sJob, &wr_graph, save, WARP_RANDO_SAVE_BYTES, &sActive, sWork);
        while (result == WR_PENDING) result = wr_advance(&sJob);
    }
    ReleaseWork();
    if (result != WR_OK) wr_invalidate(&sActive);
    SetMainCallback2(result == WR_OK ? success : failure);
}

#if TESTING
void WarpRando_TestNewSeed(uint32_t seed, MainCallback success, MainCallback failure)
{
    struct WrIdentity id = NewIdentity();
    id.seed = seed;
    WarpRando_IntroHide();
    sHasIntro = FALSE;
    BeginWork(&id, FALSE, 0);
    LoadingScreen(success, failure);
}
#endif

int WarpRando_Save(uint8_t *save)
{
    return wr_table_encode(&wr_graph, &sActive, save, WARP_RANDO_SAVE_BYTES) == WR_OK;
}

int WarpRando_Resolve(int sg, int sm, int sw, uint16_t x, uint16_t y, uint8_t elevation, int8_t *dg,
                      int8_t *dm, int8_t *dw)
{
    struct WrKey source, requested, normalized;
    const struct MapHeader *landing;
    if (sg < 0 || sg > 127 || sm < 0 || sm > 127 || sw < 0 || sw > 127 || !dg || !dm || !dw ||
        *dg < 0 || *dm < 0 || *dw < 0)
        return FALSE;
    source = (struct WrKey){sg, sm, sw};
    requested = (struct WrKey){*dg, *dm, *dw};
    if (!wr_source_normalize(wr_source_routes, WR_SOURCE_COUNT, &source, &requested, x, y,
                             elevation, &normalized))
        return FALSE;
    if (wr_lookup(&sActive, &sActive.identity, &normalized) != 1)
        return FALSE;
    if (normalized.group >= ARRAY_COUNT(wr_target_map_counts) ||
        normalized.map >= wr_target_map_counts[normalized.group])
        return FALSE;
    landing = Overworld_GetMapHeaderByGroupAndId(normalized.group, normalized.map);
    if (landing->events == NULL || normalized.warp >= landing->events->warpCount)
        return FALSE;
    *dg = normalized.group;
    *dm = normalized.map;
    *dw = normalized.warp;
    return TRUE;
}

/* These four rooms assume an ordered, south-only entrance in vanilla.
 * Name each room explicitly: map numbering is not a gameplay contract. */
static int LeagueRoom(void)
{
    static const u16 rooms[] = {MAP_EVER_GRANDE_CITY_SIDNEYS_ROOM,
                               MAP_EVER_GRANDE_CITY_PHOEBES_ROOM,
                               MAP_EVER_GRANDE_CITY_GLACIAS_ROOM,
                               MAP_EVER_GRANDE_CITY_DRAKES_ROOM};
    unsigned i;
    if (!sActive.valid)
        return -1;
    for (i = 0; i < ARRAY_COUNT(rooms); i++)
        if (gSaveBlock1Ptr->location.mapGroup == MAP_GROUP(rooms[i]) &&
            gSaveBlock1Ptr->location.mapNum == MAP_NUM(rooms[i]))
            return i;
    return -1;
}

void WarpRando_Arrival(void)
{
    /* Run only when computing a new warp arrival, never on saved coordinates.
     * Rear event 1 is on the north door; land one tile inside instead. */
    if (LeagueRoom() >= 0 && gSaveBlock1Ptr->location.warpId == 1)
    {
        gSaveBlock1Ptr->pos.x = 6;
        gSaveBlock1Ptr->pos.y = 3;
    }
}

void WarpRando_MapLoaded(void)
{
    int room = LeagueRoom();
    if (room < 0)
        return;
    /* Each OnFrame table tests room's zero-based index. The next value skips
     * the six-step walk and door closure, including on subsequent visits.
     * Do not grant victories or change any trainer/defeat flag. */
    VarSet(VAR_ELITE_4_STATE, room + 1);
    /* After vanilla OnLoad: reopen the central path through both doors.
     * The surrounding door panels can remain closed. Collision is explicit. */
    MapGridSetMetatileIdAt(6 + MAP_OFFSET, 1 + MAP_OFFSET, METATILE_EliteFour_OpenDoor_Frame);
    MapGridSetMetatileIdAt(6 + MAP_OFFSET, 2 + MAP_OFFSET, METATILE_EliteFour_OpenDoor_Opening);
    MapGridSetMetatileIdAt(6 + MAP_OFFSET, 12 + MAP_OFFSET, METATILE_EliteFour_OpenDoor_Frame);
    MapGridSetMetatileIdAt(6 + MAP_OFFSET, 13 + MAP_OFFSET, METATILE_EliteFour_OpenDoor_Opening);
}


/* Compatibility preset, first port: Gyms must tolerate out-of-order visits.
 * Run before transition/load scripts and object creation, including Continue.
 * No badge, HM, trainer victory or global plot completion is awarded here. */
void WarpRando_PrepareMap(void)
{
    u16 map;
    unsigned i;
    if (!sActive.valid)
        return;
    map = (gSaveBlock1Ptr->location.mapGroup << 8) | gSaveBlock1Ptr->location.mapNum;
    if (map == MAP_MAUVILLE_CITY_GYM)
    {
        /* Norman's vanilla reward script hides Wattson before a player who
         * visited Gyms out of order necessarily had a chance to battle him. */
        FlagClear(FLAG_HIDE_MAUVILLE_GYM_WATTSON);
    }
    else if (map == MAP_PETALBURG_CITY_GYM && !FlagGet(FLAG_SYS_GAME_CLEAR))
    {
        /* Other badges increment this same variable. Derive its meaning from
         * Norman's actual victory flag instead of treating it as a badge count.
         * Leave postgame rematch selection to the target's normal scripts. */
        VarSet(VAR_PETALBURG_GYM_STATE, FlagGet(FLAG_DEFEATED_PETALBURG_GYM) ? 7 : 6);
        if (VarGet(VAR_PETALBURG_CITY_STATE) == 0)
            VarSet(VAR_PETALBURG_CITY_STATE, 1);
        FlagSet(FLAG_HIDE_PETALBURG_GYM_WALLY);
        /* The skipped Wally tutorial used to apply this early plotless step. */
        if (VarGet(VAR_PETALBURG_WOODS_STATE) == 0)
            VarSet(VAR_PETALBURG_WOODS_STATE, 1);
        FlagSet(FLAG_HIDE_PETALBURG_WOODS_DEVON_EMPLOYEE);
        FlagSet(FLAG_HIDE_PETALBURG_WOODS_AQUA_GRUNT);
        FlagClear(FLAG_HIDE_PETALBURG_GYM_NORMAN);
        /* An old save can retain the tutorial position near the entrance.
         * Restore the canonical target template position, not a copied 1.9 ID. */
        for (i = 0; i < gMapHeader.events->objectEventCount; i++)
        {
            const struct ObjectEventTemplate *object = &gMapHeader.events->objectEvents[i];
            if (object->localId == LOCALID_PETALBURG_GYM_NORMAN)
            {
                SetObjEventTemplateCoords(object->localId, object->x, object->y);
                break;
            }
        }
    }
}


/* Script special result: 0 = no announcement, 1 = setup granted, 2 = bag full.
 * Add the Letter before changing story state, so a failed reward is retryable.
 * Existing target flags supply idempotence; no new save field is needed. */
u16 WarpRando_DevonReward(void)
{
    bool8 hadNav;
    if (!sActive.valid || !FlagGet(FLAG_BADGE01_GET))
        return 0;
    if (!FlagGet(FLAG_DELIVERED_STEVEN_LETTER) && !CheckBagHasItem(ITEM_LETTER, 1)
        && !AddBagItem(ITEM_LETTER, 1))
        return 2;
    hadNav = FlagGet(FLAG_RECEIVED_POKENAV);
    FlagSet(FLAG_SYS_POKENAV_GET);
    FlagSet(FLAG_RECEIVED_POKENAV);
    FlagSet(FLAG_HAS_MATCH_CALL);
    FlagSet(FLAG_ADDED_MATCH_CALL_TO_POKENAV);
    FlagSet(FLAG_HIDE_RUSTBORO_CITY_POKEMON_SCHOOL_SCOTT);
    FlagSet(FLAG_HIDE_RUSTBORO_CITY_SCIENTIST);
    FlagSet(FLAG_RETURNED_DEVON_GOODS);
    FlagSet(FLAG_RECOVERED_DEVON_GOODS);
    FlagClear(FLAG_DEVON_GOODS_STOLEN);
    FlagSet(FLAG_HIDE_RUSTBORO_CITY_DEVON_EMPLOYEE_1);
    /* State 6 starts the obsolete Nav tutorial; preserve states beyond it. */
    if (VarGet(VAR_RUSTBORO_CITY_STATE) < 5 || VarGet(VAR_RUSTBORO_CITY_STATE) == 6)
        VarSet(VAR_RUSTBORO_CITY_STATE, 5);
    if (VarGet(VAR_DEVON_CORP_3F_STATE) == 0)
        VarSet(VAR_DEVON_CORP_3F_STATE, 1);
    if (!FlagGet(FLAG_RUSTURF_TUNNEL_OPENED))
    {
        FlagSet(FLAG_HIDE_ROUTE_116_WANDAS_BOYFRIEND);
        FlagClear(FLAG_HIDE_RUSTURF_TUNNEL_WANDAS_BOYFRIEND);
        FlagClear(FLAG_HIDE_RUSTURF_TUNNEL_WANDA);
    }
    /* Do not pull Briney back from a voyage or undo Norman's later removal. */
    if (!FlagGet(FLAG_BADGE05_GET) && VarGet(VAR_BRINEY_LOCATION) == 0)
    {
        VarSet(VAR_BRINEY_LOCATION, 1);
        VarSet(VAR_BRINEY_HOUSE_STATE, 1);
        FlagClear(FLAG_HIDE_BRINEYS_HOUSE_MR_BRINEY);
        FlagClear(FLAG_HIDE_BRINEYS_HOUSE_PEEKO);
    }
    return hadNav ? 0 : 1;
}

void WarpRando_WeatherReward(void)
{
    if (!sActive.valid || !(FlagGet(FLAG_BADGE03_GET) || FlagGet(FLAG_BADGE05_GET)))
        return;
    if (VarGet(VAR_WEATHER_INSTITUTE_STATE) < 2)
        VarSet(VAR_WEATHER_INSTITUTE_STATE, 2);
    FlagSet(FLAG_HIDE_ROUTE_119_TEAM_AQUA);
    FlagSet(FLAG_HIDE_WEATHER_INSTITUTE_2F_AQUA_GRUNT_M);
    FlagClear(FLAG_HIDE_WEATHER_INSTITUTE_1F_WORKERS);
    FlagSet(FLAG_HIDE_WEATHER_INSTITUTE_2F_WORKERS);
}

void WarpRando_VolcanoReward(void)
{
    if (!sActive.valid || !FlagGet(FLAG_BADGE03_GET))
        return;
    FlagSet(FLAG_HIDE_ROUTE_112_TEAM_MAGMA);
    if (VarGet(VAR_METEOR_FALLS_STATE) == 0)
        VarSet(VAR_METEOR_FALLS_STATE, 1);
    FlagSet(FLAG_HIDE_METEOR_FALLS_TEAM_AQUA);
    FlagSet(FLAG_HIDE_METEOR_FALLS_TEAM_MAGMA);
    FlagSet(FLAG_MET_PROF_COZMO);
    FlagSet(FLAG_HIDE_MT_CHIMNEY_TEAM_AQUA);
    FlagSet(FLAG_HIDE_MT_CHIMNEY_TEAM_MAGMA);
    FlagSet(FLAG_DEFEATED_EVIL_TEAM_MT_CHIMNEY);
    FlagClear(FLAG_HIDE_FALLARBOR_HOUSE_PROF_COZMO);
    FlagSet(FLAG_HIDE_METEOR_FALLS_1F_1R_COZMO);
    WarpRando_WeatherReward();
}


/* Vanilla Roxanne writes state 1 before her item reward. Preserve an already
 * completed Devon/rival sequence reached through randomized doors first. */
void WarpRando_RustboroAfterBattle(void)
{
    if (!sActive.valid || VarGet(VAR_RUSTBORO_CITY_STATE) == 0)
        VarSet(VAR_RUSTBORO_CITY_STATE, 1);
}
