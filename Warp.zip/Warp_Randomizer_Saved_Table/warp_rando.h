#ifndef WARP_RANDO_H
#define WARP_RANDO_H
#include <stdint.h>
#include <stddef.h>
#define WR_NONE UINT16_MAX
#define WR_ALGORITHM 8u
#define WR_SAVE_BYTES 56u
#define WR_MAX_NODES 1024u
#define WR_MAX_CAPS 32u
#define WR_NEEDS_RETURN 1u
#define WR_NO_RETURN 2u
struct WrKey
{
    uint8_t group, map, warp;
};
struct WrNode
{
    struct WrKey id, trigger;
    uint16_t rep;
    uint8_t active, tags;
};
struct WrEdge
{
    uint16_t to, cap;
};
struct WrReq
{
    uint16_t index;
    uint8_t capability;
};
struct WrRule
{
    uint16_t grant, offset, count;
};
#define WR_MAX_COMPONENTS 400u
#define WR_COMPONENT_WORDS ((WR_MAX_COMPONENTS + 31u) / 32u)
#define WR_REP_WORDS ((WR_MAX_NODES + 31u) / 32u)
struct WrIndex;
struct WrGraph
{
    uint16_t n, caps, edge_count, rule_count, req_count, goal_count, root;
    const struct WrNode *nodes;
    const struct WrEdge *edges, *reverse_edges;
    const uint16_t *bounds, *reverse_bounds;
    const struct WrRule *rules;
    const struct WrReq *reqs;
    const uint16_t *goals;
    uint8_t fingerprint[32];
    const struct WrIndex *index;
};
struct WrRecord
{
    struct WrKey trigger, landing;
};
struct WrIdentity
{
    uint32_t seed, algorithm, ruleset;
    uint8_t data[32];
};
struct WrActive
{
    struct WrIdentity identity;
    struct WrRecord records[WR_MAX_NODES];
    uint16_t count, attempt;
    uint8_t valid;
};
/* Caller-owned workspace. Place explicitly in EWRAM on target. No heap/RNG globals. */
struct WrVerifyWork
{
    uint16_t partner[WR_MAX_NODES], destination[WR_MAX_NODES];
    uint16_t queue[WR_MAX_NODES], candidates[WR_MAX_NODES];
    uint16_t reverse_head[WR_MAX_NODES], reverse_next[WR_MAX_NODES];
    uint8_t reached[WR_MAX_NODES], home[WR_MAX_NODES], scratch[WR_MAX_NODES], caps[WR_MAX_CAPS];
    struct WrRecord candidate[WR_MAX_NODES];
    uint16_t attempts, rejection_counts[12];
};
enum WrResult
{
    WR_OK,
    WR_BAD_DATA,
    WR_ODD_POOL,
    WR_NO_SOURCE,
    WR_NO_PARTNER,
    WR_BAD_PAIR,
    WR_CONFLICT,
    WR_COVERAGE,
    WR_TRAP,
    WR_OBJECTIVE,
    WR_RETRIES,
    WR_BAD_IDENTITY
};
int wr_graph_check(const struct WrGraph *g);
int wr_emit(const struct WrGraph *g, const uint16_t *partner, struct WrRecord *out,
            uint16_t *count);
int wr_validate(const struct WrGraph *g, const struct WrRecord *table, uint16_t count,
                struct WrVerifyWork *w);
struct WrWork;
int wr_generate(const struct WrGraph *g, const struct WrIdentity *identity, uint16_t retries,
                struct WrActive *active, struct WrWork *work, int *last_rejection);
int wr_publish(const struct WrGraph *g, const struct WrIdentity *identity,
               const struct WrRecord *table, uint16_t count, struct WrActive *active,
               struct WrVerifyWork *work);
void wr_invalidate(struct WrActive *active);
/* Explicit little-endian metadata. Never save the workspace or a C struct. */
int wr_encode(const struct WrActive *active, uint8_t out[WR_SAVE_BYTES]);
int wr_decode(const struct WrGraph *graph, const uint8_t in[WR_SAVE_BYTES],
              struct WrIdentity *identity, uint16_t *attempt);
/* 1: remapped, 0: unchanged, -1: stale/inactive. */
int wr_lookup(const struct WrActive *active, const struct WrIdentity *identity,
              struct WrKey *requested);

struct WrSourceRoute
{
    struct WrKey source, expected, trigger;
    uint16_t x, y;
    uint8_t elevation;
};
int wr_source_normalize(const struct WrSourceRoute *routes, size_t count,
                        const struct WrKey *source, const struct WrKey *requested, uint16_t x,
                        uint16_t y, uint8_t elevation, struct WrKey *out);

struct WrConditional
{
    uint16_t from, to, cap;
};
struct WrIndex
{
    uint16_t nodes, components, words, active_count, conditional_count, representative_count;
    uint16_t representative_words, emit_count;
    const uint16_t *node_component, *active_offsets, *active_nodes;
    const uint16_t *representatives, *representative_active_offsets;
    const uint16_t *representative_active_indices;
    const uint16_t *representative_index_by_node, *component_representative_offsets;
    const uint16_t *component_representative_indices, *emit_nodes, *emit_index_by_node;
    const uint32_t *forward, *reverse;
    const uint16_t *forward_conditional_offsets;
    const struct WrConditional *forward_conditional;
    const uint16_t *reverse_conditional_offsets;
    const struct WrConditional *reverse_conditional;
    const uint16_t *capability_conditional_offsets;
    const struct WrConditional *capability_conditional;
};
struct WrWork
{
    uint16_t partner[WR_MAX_NODES], candidates[WR_MAX_NODES];
    uint32_t reached[WR_COMPONENT_WORDS], home[WR_COMPONENT_WORDS], scratch[WR_COMPONENT_WORDS];
    uint32_t base_reached[WR_COMPONENT_WORDS], base_home[WR_COMPONENT_WORDS];
    uint32_t best_reached[WR_COMPONENT_WORDS], best_home[WR_COMPONENT_WORDS];
    uint32_t free_reps[WR_REP_WORDS];
    uint32_t reached_reps[WR_REP_WORDS], home_reps[WR_REP_WORDS];
    uint32_t base_reached_reps[WR_REP_WORDS], base_home_reps[WR_REP_WORDS];
    uint32_t best_reached_reps[WR_REP_WORDS], best_home_reps[WR_REP_WORDS];
    uint8_t caps[WR_MAX_CAPS], best_caps[WR_MAX_CAPS], new_caps[WR_MAX_CAPS];
    struct WrRecord candidate[WR_MAX_NODES];
    uint16_t attempts, rejection_counts[12];
    uint16_t queue[WR_MAX_COMPONENTS], reverse_head[WR_MAX_COMPONENTS];
    uint16_t reverse_next[WR_MAX_NODES];
};

#define WR_PENDING 100
#define WR_CANCELLED 101
struct WrJob
{
    const struct WrGraph *graph;
    const struct WrIndex *index;
    struct WrWork *work;
    struct WrActive *active;
    struct WrIdentity identity;
    uint32_t seed, state, steps;
    uint16_t trial_cap, retries, attempt, left, n, source, target, trial, ties, j, limit;
    uint16_t best_unsafe, count, successful_attempt, head, tail, cursor, free_count, safe_count;
    int best, unsafe, trial_unsafe, score, last_rejection, result;
    uint8_t phase;
};
int wr_begin(struct WrJob *, const struct WrGraph *, const struct WrIdentity *, uint16_t retries,
             struct WrActive *, struct WrWork *);
int wr_advance(struct WrJob *);
void wr_cancel(struct WrJob *);

/* Table envelope: 56-byte identity, one LE u16 destination node per emitted
 * record, then CRC32 over identity and destinations. Exact size is required. */
size_t wr_table_bytes(const struct WrGraph *graph);
int wr_table_encode(const struct WrGraph *graph, const struct WrActive *active,
                    uint8_t *out, size_t size);
int wr_table_begin(struct WrJob *job, const struct WrGraph *graph,
                   const uint8_t *save, size_t size,
                   struct WrActive *active, struct WrWork *work);
#endif
