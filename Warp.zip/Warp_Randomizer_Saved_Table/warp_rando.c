/* GPL-3.0-or-later. Checked node-level validation plus one indexed, resumable
 * constructor adapted from the supplied C9/C10 experiments. See DOCS.md. */
#include "warp_rando.h"
#include <string.h>

/* 1. Keys, identity and immutable graph checks. */
static int keyeq(struct WrKey a, struct WrKey b)
{
    return a.group == b.group && a.map == b.map && a.warp == b.warp;
}

static int keycmp(struct WrKey a, struct WrKey b)
{
    if (a.group != b.group)
        return a.group < b.group ? -1 : 1;
    if (a.map != b.map)
        return a.map < b.map ? -1 : 1;
    return (a.warp > b.warp) - (a.warp < b.warp);
}

static int identityeq(const struct WrIdentity *a, const struct WrIdentity *b)
{
    return a->seed == b->seed && a->algorithm == b->algorithm && a->ruleset == b->ruleset &&
           !memcmp(a->data, b->data, 32);
}

static int identityok(const struct WrGraph *graph, const struct WrIdentity *i)
{
    return i->algorithm == WR_ALGORITHM && i->ruleset == 1 &&
           !memcmp(i->data, graph->fingerprint, 32);
}

void wr_invalidate(struct WrActive *a)
{
    a->valid = 0;
    a->count = 0;
}

static int allowed(const struct WrNode *a, const struct WrNode *b)
{
    return !((a->tags & WR_NEEDS_RETURN && b->tags & WR_NO_RETURN) ||
             (b->tags & WR_NEEDS_RETURN && a->tags & WR_NO_RETURN));
}

int wr_graph_check(const struct WrGraph *graph)
{
    uint16_t i, j;
    if (!graph || !graph->n || graph->n > WR_MAX_NODES || graph->caps > WR_MAX_CAPS ||
        graph->root >= graph->n || !graph->nodes || !graph->bounds || !graph->reverse_bounds ||
        !graph->edges || !graph->reverse_edges || !graph->rules || !graph->reqs || !graph->goals)
        return WR_BAD_DATA;
    if (graph->bounds[0] || graph->reverse_bounds[0] ||
        graph->bounds[graph->n] != graph->edge_count ||
        graph->reverse_bounds[graph->n] != graph->edge_count)
        return WR_BAD_DATA;
    for (i = 0; i < graph->n; i++)
    {
        const struct WrNode *v = &graph->nodes[i];
        if (v->rep >= graph->n || graph->nodes[v->rep].rep != v->rep ||
            v->active != graph->nodes[v->rep].active || v->active > 1 || v->tags > 3 ||
            v->tags != graph->nodes[v->rep].tags || graph->bounds[i] > graph->bounds[i + 1] ||
            graph->reverse_bounds[i] > graph->reverse_bounds[i + 1])
            return WR_BAD_DATA;
        for (j = 0; j < i; j++)
            if (keyeq(v->id, graph->nodes[j].id) ||
                (v->active != graph->nodes[j].active && keyeq(v->trigger, graph->nodes[j].trigger)))
                return WR_BAD_DATA;
    }
    for (i = 0; i < graph->edge_count; i++)
    {
        const struct WrEdge *e = &graph->edges[i], *r = &graph->reverse_edges[i];
        if (e->to >= graph->n || r->to >= graph->n ||
            (e->cap != WR_NONE && e->cap >= graph->caps) ||
            (r->cap != WR_NONE && r->cap >= graph->caps))
            return WR_BAD_DATA;
    }
    /* Prove that the reverse adjacency supplied by the compiler is exact. */
    for (i = 0; i < graph->n; i++)
        for (j = graph->bounds[i]; j < graph->bounds[i + 1]; j++)
        {
            uint16_t k, hits = 0, to = graph->edges[j].to;
            for (k = graph->reverse_bounds[to]; k < graph->reverse_bounds[to + 1]; k++)
                if (graph->reverse_edges[k].to == i &&
                    graph->reverse_edges[k].cap == graph->edges[j].cap)
                    hits++;
            if (hits != 1)
                return WR_BAD_DATA;
        }
    for (i = 0; i < graph->n; i++)
        for (j = graph->reverse_bounds[i]; j < graph->reverse_bounds[i + 1]; j++)
        {
            uint16_t k, hits = 0, to = graph->reverse_edges[j].to;
            for (k = graph->bounds[to]; k < graph->bounds[to + 1]; k++)
                if (graph->edges[k].to == i && graph->edges[k].cap == graph->reverse_edges[j].cap)
                    hits++;
            if (hits != 1)
                return WR_BAD_DATA;
        }
    for (i = 0; i < graph->rule_count; i++)
    {
        const struct WrRule *r = &graph->rules[i];
        if (r->grant >= graph->caps || (uint32_t)r->offset + r->count > graph->req_count)
            return WR_BAD_DATA;
    }
    for (i = 0; i < graph->req_count; i++)
        if (graph->reqs[i].capability > 1 ||
            graph->reqs[i].index >= (graph->reqs[i].capability ? graph->caps : graph->n))
            return WR_BAD_DATA;
    for (i = 0; i < graph->goal_count; i++)
        if (graph->goals[i] >= graph->n)
            return WR_BAD_DATA;
    return WR_OK;
}

/* 2. Translate canonical pairs into the table the engine will consume. */
int wr_emit(const struct WrGraph *graph, const uint16_t *p, struct WrRecord *out, uint16_t *count)
{
    uint16_t i, j, n = 0;
    *count = 0;
    if (wr_graph_check(graph))
        return WR_BAD_DATA;
    for (i = 0; i < graph->n; i++)
        if (graph->nodes[i].active)
        {
            uint16_t r = graph->nodes[i].rep, t = p[r];
            struct WrRecord row;
            if (t >= graph->n || t == r || !graph->nodes[t].active || graph->nodes[t].rep != t ||
                p[t] != r || !allowed(&graph->nodes[r], &graph->nodes[t]))
                return WR_BAD_PAIR;
            row.trigger = graph->nodes[i].trigger;
            row.landing = graph->nodes[t].id;
            for (j = 0; j < n; j++)
                if (keyeq(out[j].trigger, row.trigger))
                    break;
            if (j < n)
            {
                if (!keyeq(out[j].landing, row.landing))
                    return WR_CONFLICT;
            }
            else
                out[n++] = row;
        }
    /* Stable insertion sort; output has at most n physical triggers. */
    for (i = 1; i < n; i++)
    {
        struct WrRecord row = out[i];
        j = i;
        while (j && keycmp(row.trigger, out[j - 1].trigger) < 0)
        {
            out[j] = out[j - 1];
            j--;
        }
        out[j] = row;
    }
    *count = n;
    return WR_OK;
}

/* 3. Directed traversal and permanent-capability closure. */
static void traverse(const struct WrGraph *graph, struct WrVerifyWork *work, int reverse)
{
    uint16_t head = 0, tail = 0, i, v, t;
    uint8_t *seen = reverse ? work->home : work->reached;
    const uint16_t *bounds = reverse ? graph->reverse_bounds : graph->bounds;
    const struct WrEdge *edges = reverse ? graph->reverse_edges : graph->edges;
    memset(seen, 0, graph->n);
    seen[graph->root] = 1;
    work->queue[tail++] = graph->root;
    while (head < tail)
    {
        v = work->queue[head++];
        for (i = bounds[v]; i < bounds[v + 1]; i++)
        {
            t = edges[i].to;
            if ((edges[i].cap == WR_NONE || work->caps[edges[i].cap]) && !seen[t])
            {
                seen[t] = 1;
                work->queue[tail++] = t;
            }
        }
        if (reverse)
        {
            for (t = work->reverse_head[v]; t != WR_NONE; t = work->reverse_next[t])
                if (!seen[t])
                {
                    seen[t] = 1;
                    work->queue[tail++] = t;
                }
        }
        else
        {
            t = work->destination[v];
            if (t != WR_NONE && !seen[t])
            {
                seen[t] = 1;
                work->queue[tail++] = t;
            }
        }
    }
}

static void reverse_warps(const struct WrGraph *graph, struct WrVerifyWork *work)
{
    uint16_t i, t;
    for (i = 0; i < graph->n; i++)
        work->reverse_head[i] = WR_NONE;
    for (i = 0; i < graph->n; i++)
    {
        t = work->destination[i];
        if (t != WR_NONE)
        {
            work->reverse_next[i] = work->reverse_head[t];
            work->reverse_head[t] = i;
        }
    }
}

/* Fresh-state monotone closure. Only collect at locations already able to return
 * to the anchor with current capabilities. This is deliberately conservative. */
static int closure_until(const struct WrGraph *graph, struct WrVerifyWork *work, int stop_unsafe)
{
    uint16_t i, j;
    int changed, unsafe = 0;
    uint8_t next_caps[WR_MAX_CAPS];
    memset(work->caps, 0, graph->caps);
    reverse_warps(graph, work);
    do
    {
        changed = 0;
        traverse(graph, work, 0);
        traverse(graph, work, 1);
        for (i = 0; i < graph->n; i++)
            if (work->reached[i] && !work->home[i])
                unsafe = 1;
        if (unsafe && stop_unsafe)
            return 1;
        memcpy(next_caps, work->caps, graph->caps);
        for (i = 0; i < graph->rule_count; i++)
        {
            const struct WrRule *r = &graph->rules[i];
            int all = 1;
            if (work->caps[r->grant])
                continue;
            for (j = 0; j < r->count; j++)
            {
                const struct WrReq *q = &graph->reqs[r->offset + j];
                if (q->capability ? !work->caps[q->index]
                                  : !(work->reached[q->index] && work->home[q->index]))
                {
                    all = 0;
                    break;
                }
            }
            if (all)
            {
                next_caps[r->grant] = 1;
                changed = 1;
            }
        }
        memcpy(work->caps, next_caps, graph->caps);
    } while (changed);
    return unsafe;
}

static int closure(const struct WrGraph *graph, struct WrVerifyWork *work)
{
    return closure_until(graph, work, 0);
}

/* 4. Accept the emitted table from fresh state, then publish it. */
int wr_validate(const struct WrGraph *graph, const struct WrRecord *table, uint16_t count,
                struct WrVerifyWork *work)
{
    uint16_t i, j, t;
    int result = wr_graph_check(graph);
    if (result || count > graph->n)
        return WR_BAD_DATA;
    for (i = 0; i < count; i++)
    {
        int used = 0;
        for (j = 0; j < i; j++)
            if (keyeq(table[i].trigger, table[j].trigger))
                return WR_CONFLICT;
        for (j = 0; j < graph->n; j++)
            if (graph->nodes[j].active && keyeq(table[i].trigger, graph->nodes[j].trigger))
                used = 1;
        if (!used)
            return WR_COVERAGE;
    }
    for (i = 0; i < graph->n; i++)
    {
        work->destination[i] = WR_NONE;
        work->partner[i] = WR_NONE;
        if (!graph->nodes[i].active)
            continue;
        for (j = 0; j < count; j++)
            if (keyeq(table[j].trigger, graph->nodes[i].trigger))
                break;
        if (j == count)
            return WR_COVERAGE;
        for (t = 0; t < graph->n; t++)
            if (keyeq(graph->nodes[t].id, table[j].landing))
                break;
        if (t == graph->n || !graph->nodes[t].active || graph->nodes[t].rep != t)
            return WR_BAD_PAIR;
        work->destination[i] = t;
    }
    for (i = 0; i < graph->n; i++)
        if (graph->nodes[i].active)
        {
            uint16_t r = graph->nodes[i].rep;
            t = work->destination[i];
            if (t == r || work->destination[r] != t || work->destination[t] != r ||
                !allowed(&graph->nodes[r], &graph->nodes[t]))
                return WR_BAD_PAIR;
        }
    if (closure(graph, work))
        return WR_TRAP;
    for (i = 0; i < graph->n; i++)
        if (work->reached[i] && !work->home[i])
            return WR_TRAP;
    for (i = 0; i < graph->goal_count; i++)
        if (!work->reached[graph->goals[i]])
            return WR_OBJECTIVE;
    return WR_OK;
}

int wr_publish(const struct WrGraph *graph, const struct WrIdentity *id,
               const struct WrRecord *table, uint16_t count, struct WrActive *a,
               struct WrVerifyWork *work)
{
    int result;
    wr_invalidate(a);
    if (!identityok(graph, id))
        return WR_BAD_IDENTITY;
    result = wr_validate(graph, table, count, work);
    if (result)
        return result;
    memcpy(a->records, table, count * sizeof(*table));
    a->identity = *id;
    a->count = count;
    a->attempt = 0;
    a->valid = 1;
    return WR_OK;
}

/* 5. Dedicated deterministic random generator; never touch gameplay RNG. */
static uint32_t rng(uint32_t *s)
{
    *s = *s * 1664525u + 1013904223u;
    return *s;
}

static uint16_t choose(uint32_t *s, uint16_t count)
{
    /* rejection sampling, including seed zero, without gameplay RNG */
    uint32_t r, threshold = (0u - (uint32_t)count) % count;
    do
    {
        r = rng(s);
    } while (r < threshold);
    return (uint16_t)(r % count);
}

/* 6. Gameplay lookup and explicitly encoded save identity. */
int wr_lookup(const struct WrActive *a, const struct WrIdentity *id, struct WrKey *requested)
{
    uint16_t i;
    if (!a->valid || !identityeq(&a->identity, id))
        return -1;
    for (i = 0; i < a->count; i++)
        if (keyeq(a->records[i].trigger, *requested))
        {
            *requested = a->records[i].landing;
            return 1;
        }
    return 0;
}

static void put32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v;
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static uint32_t get32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint32_t crc32(const uint8_t *p, size_t n)
{
    uint32_t crc = UINT32_MAX;
    size_t i;
    unsigned b;
    for (i = 0; i < n; i++)
    {
        crc ^= p[i];
        for (b = 0; b < 8; b++)
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}

int wr_encode(const struct WrActive *a, uint8_t out[WR_SAVE_BYTES])
{
    if (!a->valid)
        return WR_BAD_IDENTITY;
    memset(out, 0, WR_SAVE_BYTES);
    memcpy(out, "WR08", 4);
    put32(out + 4, a->identity.seed);
    put32(out + 8, a->identity.algorithm);
    put32(out + 12, a->identity.ruleset);
    memcpy(out + 16, a->identity.data, 32);
    out[48] = (uint8_t)a->attempt;
    out[49] = (uint8_t)(a->attempt >> 8);
    put32(out + 52, crc32(out, 52));
    return WR_OK;
}

int wr_decode(const struct WrGraph *graph, const uint8_t in[WR_SAVE_BYTES], struct WrIdentity *id,
              uint16_t *attempt)
{
    struct WrIdentity candidate;
    if (memcmp(in, "WR08", 4) || in[50] || in[51] || crc32(in, 52) != get32(in + 52))
        return WR_BAD_IDENTITY;
    candidate.seed = get32(in + 4);
    candidate.algorithm = get32(in + 8);
    candidate.ruleset = get32(in + 12);
    memcpy(candidate.data, in + 16, 32);
    if (!identityok(graph, &candidate))
        return WR_BAD_IDENTITY;
    *id = candidate;
    *attempt = (uint16_t)(in[48] | ((uint16_t)in[49] << 8));
    return WR_OK;
}

/* 7. Admit only known physical source events before trigger lookup. */
static int key_compare(const struct WrKey *a, const struct WrKey *b)
{
    if (a->group != b->group)
        return (int)a->group - b->group;
    if (a->map != b->map)
        return (int)a->map - b->map;
    return (int)a->warp - b->warp;
}

int wr_source_normalize(const struct WrSourceRoute *routes, size_t count,
                        const struct WrKey *source, const struct WrKey *requested, uint16_t x,
                        uint16_t y, uint8_t elevation, struct WrKey *out)
{
    size_t lo = 0, hi = count;
    const struct WrSourceRoute *row;
    if (!routes || !source || !requested || !out)
        return 0;
    while (lo < hi)
    {
        size_t mid = lo + (hi - lo) / 2;
        if (key_compare(&routes[mid].source, source) < 0)
            lo = mid + 1;
        else
            hi = mid;
    }
    if (lo == count)
        return 0;
    row = &routes[lo];
    if (key_compare(&row->source, source) || key_compare(&row->expected, requested) ||
        row->x != x || row->y != y || row->elevation != elevation)
        return 0;
    *out = row->trigger;
    return 1;
}

/* 8. Indexed generator: immutable closure in ROM, mutable pair edges in work.
 * The phases below are ordinary resumable functions, not threads. */
enum Phase
{
    PH_ATTEMPT_INIT = 0,
    PH_SELECT,
    PH_SELECT_SOURCE,
    PH_SELECT_PARTNER,
    PH_TRIAL_SETUP,
    PH_TRIAL_PAIR_FORWARD_PREP,
    PH_TRIAL_PAIR_FORWARD,
    PH_TRIAL_PAIR_REVERSE_PREP,
    PH_TRIAL_PAIR_REVERSE,
    PH_TRIAL_CHECK,
    PH_TRIAL_CAP_FORWARD_PREP,
    PH_TRIAL_CAP_FORWARD,
    PH_TRIAL_CAP_REVERSE_PREP,
    PH_TRIAL_CAP_REVERSE,
    PH_TRIAL_SCORE,
    PH_TRIAL_REPAIR_PREP,
    PH_TRIAL_REPAIR,
    PH_TRIAL_REPAIR_CHECK,
    PH_TRIAL_FINISH,
    PH_COMMIT,
    PH_EMIT,
    PH_VALIDATE_INIT,
    PH_VALIDATE_FORWARD,
    PH_VALIDATE_REVERSE_PREP,
    PH_VALIDATE_REVERSE,
    PH_VALIDATE_CHECK,
    PH_VALIDATE_CAP_FORWARD_PREP,
    PH_VALIDATE_CAP_FORWARD,
    PH_VALIDATE_CAP_REVERSE_PREP,
    PH_VALIDATE_CAP_REVERSE,
    PH_VALIDATE_GOALS,
    PH_DONE
};
static int has(const uint32_t *bits, uint16_t component)
{
    return (int)((bits[component >> 5] >> (component & 31)) & 1u);
}
static void add_component_reps(const struct WrIndex *x, uint32_t *rep_bits, uint16_t component)
{
    uint16_t i;
    if (!rep_bits)
        return;
    for (i = x->component_representative_offsets[component];
         i < x->component_representative_offsets[component + 1]; i++)
    {
        uint16_t ordinal = x->component_representative_indices[i];
        rep_bits[ordinal >> 5] |= 1u << (ordinal & 31);
    }
}
static int add(uint32_t *bits, uint32_t *rep_bits, const uint32_t *rows, uint16_t component,
               const struct WrIndex *x)
{
    uint16_t word;
    int changed = 0;
    const uint32_t *row = rows + (uint32_t)component * x->words;

    for (word = 0; word < x->words; word++)
    {
        uint32_t added = row[word] & ~bits[word];
        bits[word] |= row[word];
        changed |= added != 0;
        while (added)
        {
            uint16_t bit = (uint16_t)__builtin_ctz(added);
            add_component_reps(x, rep_bits, (uint16_t)(word * 32u + bit));
            added &= added - 1u;
        }
    }
    return changed;
}
static void enqueue_bits(const uint32_t *bits, uint16_t words, uint16_t *queue, uint16_t *tail)
{
    uint16_t word;
    for (word = 0; word < words; word++)
    {
        uint32_t pending = bits[word];
        while (pending)
        {
            uint16_t bit = (uint16_t)__builtin_ctz(pending);
            queue[(*tail)++] = (uint16_t)(word * 32u + bit);
            pending &= pending - 1u;
        }
    }
}
static void add_queue(uint32_t *bits, uint32_t *rep_bits, const uint32_t *rows, uint16_t component,
                      const struct WrIndex *x, uint16_t *queue, uint16_t *tail)
{
    uint16_t word;
    const uint32_t *row = rows + (uint32_t)component * x->words;
    for (word = 0; word < x->words; word++)
    {
        uint32_t added = row[word] & ~bits[word];
        bits[word] |= row[word];
        while (added)
        {
            uint16_t bit = (uint16_t)__builtin_ctz(added);
            uint16_t added_component = (uint16_t)(word * 32u + bit);
            add_component_reps(x, rep_bits, added_component);
            queue[(*tail)++] = added_component;
            added &= added - 1u;
        }
    }
}
static void set_free(struct WrWork *w, const struct WrIndex *x, uint16_t node, int free)
{
    uint16_t ordinal = x->representative_index_by_node[node];
    uint32_t mask = 1u << (ordinal & 31);
    if (free)
        w->free_reps[ordinal >> 5] |= mask;
    else
        w->free_reps[ordinal >> 5] &= ~mask;
}

static void reverse_pair(const struct WrIndex *x, struct WrWork *w, uint16_t source,
                         uint16_t target, int add)
{
    uint16_t i, start, end, active_index, destination;
    if (add)
    {
        start = x->representative_active_offsets[source];
        end = x->representative_active_offsets[source + 1];
        destination = x->node_component[target];
        for (i = start; i < end; i++)
        {
            active_index = x->representative_active_indices[i];
            w->reverse_next[active_index] = w->reverse_head[destination];
            w->reverse_head[destination] = active_index;
        }
        start = x->representative_active_offsets[target];
        end = x->representative_active_offsets[target + 1];
        destination = x->node_component[source];
        for (i = start; i < end; i++)
        {
            active_index = x->representative_active_indices[i];
            w->reverse_next[active_index] = w->reverse_head[destination];
            w->reverse_head[destination] = active_index;
        }
    }
    else
    {
        start = x->representative_active_offsets[target];
        end = x->representative_active_offsets[target + 1];
        destination = x->node_component[source];
        for (i = end; i > start;)
        {
            active_index = x->representative_active_indices[--i];
            w->reverse_head[destination] = w->reverse_next[active_index];
        }
        start = x->representative_active_offsets[source];
        end = x->representative_active_offsets[source + 1];
        destination = x->node_component[target];
        for (i = end; i > start;)
        {
            active_index = x->representative_active_indices[--i];
            w->reverse_head[destination] = w->reverse_next[active_index];
        }
    }
}

static void forward_one(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w,
                        uint16_t *head, uint16_t *tail)
{
    uint16_t component = w->queue[(*head)++], i;
    for (i = x->active_offsets[component]; i < x->active_offsets[component + 1]; i++)
    {
        uint16_t v = x->active_nodes[i], p = w->partner[g->nodes[v].rep];
        if (p != WR_NONE && !has(w->reached, x->node_component[p]))
            add_queue(w->reached, w->reached_reps, x->forward, x->node_component[p], x, w->queue,
                      tail);
    }
    for (i = x->forward_conditional_offsets[component];
         i < x->forward_conditional_offsets[component + 1]; i++)
    {
        const struct WrConditional *e = &x->forward_conditional[i];
        if (w->caps[e->cap] && !has(w->reached, e->to))
            add_queue(w->reached, w->reached_reps, x->forward, e->to, x, w->queue, tail);
    }
}
static void reverse_one(const struct WrIndex *x, struct WrWork *w, uint32_t *seen,
                        uint32_t *seen_reps, uint16_t *head, uint16_t *tail)
{
    uint16_t component = w->queue[(*head)++], i;
    for (i = w->reverse_head[component]; i != WR_NONE; i = w->reverse_next[i])
    {
        uint16_t source = x->node_component[x->active_nodes[i]];
        if (!has(seen, source))
            add_queue(seen, seen_reps, x->reverse, source, x, w->queue, tail);
    }
    for (i = x->reverse_conditional_offsets[component];
         i < x->reverse_conditional_offsets[component + 1]; i++)
    {
        const struct WrConditional *e = &x->reverse_conditional[i];
        if (w->caps[e->cap] && !has(seen, e->from))
            add_queue(seen, seen_reps, x->reverse, e->from, x, w->queue, tail);
    }
}

/* The few atomic setup/commit walks reuse exactly the same component step. */
static void propagate_forward(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w,
                              uint16_t tail)
{
    uint16_t head = 0;
    while (head < tail)
        forward_one(g, x, w, &head, &tail);
}

static void propagate_reverse(const struct WrIndex *x, struct WrWork *w, uint32_t *seen,
                              uint32_t *seen_reps, uint16_t tail)
{
    uint16_t head = 0;
    while (head < tail)
        reverse_one(x, w, seen, seen_reps, &head, &tail);
}

static void expand_forward_full(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w)
{
    uint16_t tail = 0;
    enqueue_bits(w->reached, x->words, w->queue, &tail);
    propagate_forward(g, x, w, tail);
}
static void expand_reverse_full(const struct WrIndex *x, struct WrWork *w, uint32_t *seen,
                                uint32_t *seen_reps)
{
    uint16_t tail = 0;
    enqueue_bits(seen, x->words, w->queue, &tail);
    propagate_reverse(x, w, seen, seen_reps, tail);
}
static void expand_forward_caps(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w)
{
    uint16_t cap, i, tail = 0;
    for (cap = 0; cap < g->caps; cap++)
        if (w->new_caps[cap])
            for (i = x->capability_conditional_offsets[cap];
                 i < x->capability_conditional_offsets[cap + 1]; i++)
            {
                const struct WrConditional *e = &x->capability_conditional[i];
                if (has(w->reached, e->from) && !has(w->reached, e->to))
                    add_queue(w->reached, w->reached_reps, x->forward, e->to, x, w->queue, &tail);
            }
    propagate_forward(g, x, w, tail);
}
static void expand_reverse_caps(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w,
                                uint32_t *seen, uint32_t *seen_reps)
{
    uint16_t cap, i, tail = 0;
    for (cap = 0; cap < g->caps; cap++)
        if (w->new_caps[cap])
            for (i = x->capability_conditional_offsets[cap];
                 i < x->capability_conditional_offsets[cap + 1]; i++)
            {
                const struct WrConditional *e = &x->capability_conditional[i];
                if (has(seen, e->to) && !has(seen, e->from))
                    add_queue(seen, seen_reps, x->reverse, e->from, x, w->queue, &tail);
            }
    propagate_reverse(x, w, seen, seen_reps, tail);
}
static void expand_pair_zero(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w,
                             uint16_t source, uint16_t target)
{
    uint16_t direction, i, tail = 0;
    for (direction = 0; direction < 2; direction++)
    {
        uint16_t representative = direction ? target : source;
        uint16_t destination = direction ? source : target;
        for (i = x->representative_active_offsets[representative];
             i < x->representative_active_offsets[representative + 1]; i++)
        {
            uint16_t active_index = x->representative_active_indices[i];
            uint16_t v = x->active_nodes[active_index];
            if (has(w->reached, x->node_component[v]) &&
                !has(w->reached, x->node_component[destination]))
                add_queue(w->reached, w->reached_reps, x->forward, x->node_component[destination],
                          x, w->queue, &tail);
        }
    }
    propagate_forward(g, x, w, tail);
    tail = 0;
    for (direction = 0; direction < 2; direction++)
    {
        uint16_t representative = direction ? target : source;
        uint16_t destination = direction ? source : target;
        for (i = x->representative_active_offsets[representative];
             i < x->representative_active_offsets[representative + 1]; i++)
        {
            uint16_t active_index = x->representative_active_indices[i];
            uint16_t v = x->active_nodes[active_index];
            if (has(w->home, x->node_component[destination]) && !has(w->home, x->node_component[v]))
                add_queue(w->home, w->home_reps, x->reverse, x->node_component[v], x, w->queue,
                          &tail);
        }
    }
    propagate_reverse(x, w, w->home, w->home_reps, tail);
}

static int unsafe(const struct WrIndex *x, const struct WrWork *w)
{
    uint16_t i;
    for (i = 0; i < x->words; i++)
        if (w->reached[i] & ~w->home[i])
            return 1;
    return 0;
}
static int grant(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w)
{
    uint16_t i, j;
    int changed = 0;
    uint8_t next[WR_MAX_CAPS];
    memcpy(next, w->caps, g->caps);
    memset(w->new_caps, 0, g->caps);
    for (i = 0; i < g->rule_count; i++)
    {
        const struct WrRule *r = &g->rules[i];
        int all = 1;
        if (w->caps[r->grant])
            continue;
        for (j = 0; j < r->count; j++)
        {
            const struct WrReq *q = &g->reqs[r->offset + j];
            if (q->capability ? !w->caps[q->index]
                              : !(has(w->reached, x->node_component[q->index]) &&
                                  has(w->home, x->node_component[q->index])))
            {
                all = 0;
                break;
            }
        }
        if (all)
        {
            next[r->grant] = 1;
            w->new_caps[r->grant] = 1;
            changed = 1;
        }
    }
    memcpy(w->caps, next, g->caps);
    return changed;
}
/* Initial zero-pair closure. Trials later reuse base_* and propagate additions. */
static int indexed_closure(const struct WrGraph *g, const struct WrIndex *x, struct WrWork *w,
                           int save_zero)
{
    memset(w->reached, 0, x->words * sizeof(uint32_t));
    memset(w->home, 0, x->words * sizeof(uint32_t));
    memset(w->reached_reps, 0, x->representative_words * sizeof(uint32_t));
    memset(w->home_reps, 0, x->representative_words * sizeof(uint32_t));
    memset(w->caps, 0, g->caps);
    add(w->reached, w->reached_reps, x->forward, x->node_component[g->root], x);
    add(w->home, w->home_reps, x->reverse, x->node_component[g->root], x);
    expand_forward_full(g, x, w);
    expand_reverse_full(x, w, w->home, w->home_reps);
    for (;;)
    {
        if (save_zero)
        {
            memcpy(w->base_reached, w->reached, x->words * sizeof(uint32_t));
            memcpy(w->base_home, w->home, x->words * sizeof(uint32_t));
            memcpy(w->base_reached_reps, w->reached_reps,
                   x->representative_words * sizeof(uint32_t));
            memcpy(w->base_home_reps, w->home_reps, x->representative_words * sizeof(uint32_t));
            save_zero = 0;
        }
        if (unsafe(x, w))
            return 1;
        if (!grant(g, x, w))
            return 0;
        expand_forward_caps(g, x, w);
        expand_reverse_caps(g, x, w, w->home, w->home_reps);
    }
}
static int finish(struct WrJob *q, int result)
{
    q->result = result;
    q->phase = PH_DONE;
    return result;
}
static int reject(struct WrJob *q, int rejection)
{
    q->last_rejection = rejection;
    q->work->rejection_counts[rejection]++;
    q->count = 0;
    q->attempt++;
    if (q->attempt >= q->retries)
        return finish(q, WR_RETRIES);
    q->phase = PH_ATTEMPT_INIT;
    return WR_PENDING;
}
static void pair_forward_prep(struct WrJob *q)
{
    const struct WrIndex *x = q->index;
    struct WrWork *w = q->work;
    uint16_t i;
    uint16_t representative = q->cursor ? q->trial : q->source;
    uint16_t destination = q->cursor ? q->source : q->trial;
    for (i = x->representative_active_offsets[representative];
         i < x->representative_active_offsets[representative + 1]; i++)
    {
        uint16_t active_index = x->representative_active_indices[i];
        uint16_t v = x->active_nodes[active_index];
        if (has(w->reached, x->node_component[v]) &&
            !has(w->reached, x->node_component[destination]))
            add_queue(w->reached, w->reached_reps, x->forward, x->node_component[destination], x,
                      w->queue, &q->tail);
    }
}
static void pair_reverse_prep(struct WrJob *q)
{
    const struct WrIndex *x = q->index;
    struct WrWork *w = q->work;
    uint16_t i;
    uint16_t representative = q->cursor ? q->trial : q->source;
    uint16_t destination = q->cursor ? q->source : q->trial;
    for (i = x->representative_active_offsets[representative];
         i < x->representative_active_offsets[representative + 1]; i++)
    {
        uint16_t active_index = x->representative_active_indices[i];
        uint16_t v = x->active_nodes[active_index];
        if (has(w->home, x->node_component[destination]) && !has(w->home, x->node_component[v]))
            add_queue(w->home, w->home_reps, x->reverse, x->node_component[v], x, w->queue,
                      &q->tail);
    }
}
static void cap_forward_prep(struct WrJob *q)
{
    const struct WrIndex *x = q->index;
    struct WrWork *w = q->work;
    uint16_t i, cap = q->cursor;
    if (!w->new_caps[cap])
        return;
    for (i = x->capability_conditional_offsets[cap]; i < x->capability_conditional_offsets[cap + 1];
         i++)
    {
        const struct WrConditional *e = &x->capability_conditional[i];
        if (has(w->reached, e->from) && !has(w->reached, e->to))
            add_queue(w->reached, w->reached_reps, x->forward, e->to, x, w->queue, &q->tail);
    }
}
static void cap_reverse_prep(struct WrJob *q, uint32_t *seen, uint32_t *seen_reps)
{
    const struct WrIndex *x = q->index;
    struct WrWork *w = q->work;
    uint16_t i, cap = q->cursor;
    if (!w->new_caps[cap])
        return;
    for (i = x->capability_conditional_offsets[cap]; i < x->capability_conditional_offsets[cap + 1];
         i++)
    {
        const struct WrConditional *e = &x->capability_conditional[i];
        if (has(seen, e->to) && !has(seen, e->from))
            add_queue(seen, seen_reps, x->reverse, e->from, x, w->queue, &q->tail);
    }
}

/* One bounded unit per call. The game adapter decides how many fit this frame.
 * See the phase table in DOCS.md before changing cached base/best state. */
static int step_inner(struct WrJob *q)
{
    const struct WrGraph *g = q->graph;
    const struct WrIndex *x = q->index;
    struct WrWork *w = q->work;
    uint16_t word;
    if (q->phase == PH_DONE)
        return q->result;
    switch (q->phase)
    {
    case PH_ATTEMPT_INIT:
        w->attempts++;
        q->state = q->seed + 0x9e3779b9u * q->attempt;
        q->left = x->representative_count;
        for (word = 0; word < g->n; word++)
            w->partner[word] = WR_NONE;
        for (word = 0; word < x->components; word++)
            w->reverse_head[word] = WR_NONE;
        if (q->left % 2)
            return reject(q, WR_ODD_POOL);
        memset(w->free_reps, 0xff, x->representative_words * sizeof(uint32_t));
        if (q->left & 31)
            w->free_reps[x->representative_words - 1] = (1u << (q->left & 31)) - 1u;
        q->unsafe = indexed_closure(g, x, w, 1);
        q->phase = q->left ? PH_SELECT : PH_EMIT;
        return WR_PENDING;
    case PH_SELECT:
        q->n = 0;
        q->cursor = 0;
        q->phase = PH_SELECT_SOURCE;
        return WR_PENDING;
    case PH_SELECT_SOURCE:
        word = q->cursor++;
        {
            uint32_t pending = w->free_reps[word] & w->reached_reps[word];
            pending &= q->unsafe ? ~w->home_reps[word] : w->home_reps[word];
            while (pending)
            {
                uint16_t bit = (uint16_t)__builtin_ctz(pending);
                w->candidates[q->n++] = x->representatives[word * 32u + bit];
                pending &= pending - 1u;
            }
        }
        if (q->cursor < x->representative_words)
            return WR_PENDING;
        if (!q->n)
            return reject(q, q->unsafe ? WR_TRAP : WR_NO_SOURCE);
        q->source = w->candidates[choose(&q->state, q->n)];
        q->n = 0;
        q->cursor = 0;
        q->phase = PH_SELECT_PARTNER;
        return WR_PENDING;
    case PH_SELECT_PARTNER:
        word = q->cursor++;
        {
            uint32_t pending = w->free_reps[word] & (q->unsafe ? w->home_reps[word] : ~0u);
            while (pending)
            {
                uint16_t bit = (uint16_t)__builtin_ctz(pending);
                uint16_t v = x->representatives[word * 32u + bit];
                if (v != q->source && allowed(&g->nodes[q->source], &g->nodes[v]))
                    w->candidates[q->n++] = v;
                pending &= pending - 1u;
            }
        }
        if (q->cursor < x->representative_words)
            return WR_PENDING;
        q->limit = q->n < q->trial_cap ? q->n : q->trial_cap;
        q->target = WR_NONE;
        q->ties = 0;
        q->j = 0;
        q->best = -1;
        q->best_unsafe = 0;
        q->phase = q->limit ? PH_TRIAL_SETUP : PH_COMMIT;
        return WR_PENDING;
    case PH_TRIAL_SETUP:
    {
        uint16_t pick = (uint16_t)(q->j + choose(&q->state, (uint16_t)(q->n - q->j)));
        uint16_t tmp = w->candidates[q->j];
        q->trial = w->candidates[pick];
        w->candidates[q->j] = q->trial;
        w->candidates[pick] = tmp;
        w->partner[q->source] = q->trial;
        w->partner[q->trial] = q->source;
        set_free(w, x, q->source, 0);
        set_free(w, x, q->trial, 0);
        reverse_pair(x, w, q->source, q->trial, 1);
        memcpy(w->reached, w->base_reached, x->words * sizeof(uint32_t));
        memcpy(w->home, w->base_home, x->words * sizeof(uint32_t));
        memcpy(w->reached_reps, w->base_reached_reps, x->representative_words * sizeof(uint32_t));
        memcpy(w->home_reps, w->base_home_reps, x->representative_words * sizeof(uint32_t));
        memset(w->caps, 0, g->caps);
        q->head = 0;
        q->tail = 0;
        q->cursor = 0;
        q->phase = PH_TRIAL_PAIR_FORWARD_PREP;
        return WR_PENDING;
    }
    case PH_TRIAL_PAIR_FORWARD_PREP:
        pair_forward_prep(q);
        q->cursor++;
        if (q->cursor == 2)
        {
            q->head = 0;
            q->phase = PH_TRIAL_PAIR_FORWARD;
        }
        return WR_PENDING;
    case PH_TRIAL_PAIR_FORWARD:
        if (q->head < q->tail)
            forward_one(g, x, w, &q->head, &q->tail);
        if (q->head == q->tail)
        {
            q->tail = 0;
            q->cursor = 0;
            q->phase = PH_TRIAL_PAIR_REVERSE_PREP;
        }
        return WR_PENDING;
    case PH_TRIAL_PAIR_REVERSE_PREP:
        pair_reverse_prep(q);
        q->cursor++;
        if (q->cursor == 2)
        {
            q->head = 0;
            q->phase = PH_TRIAL_PAIR_REVERSE;
        }
        return WR_PENDING;
    case PH_TRIAL_PAIR_REVERSE:
        if (q->head < q->tail)
            reverse_one(x, w, w->home, w->home_reps, &q->head, &q->tail);
        if (q->head == q->tail)
            q->phase = PH_TRIAL_CHECK;
        return WR_PENDING;
    case PH_TRIAL_CHECK:
        if (unsafe(x, w))
        {
            q->trial_unsafe = 1;
            q->cursor = 0;
            q->free_count = 0;
            q->safe_count = 0;
            q->phase = PH_TRIAL_SCORE;
            return WR_PENDING;
        }
        if (!grant(g, x, w))
        {
            q->trial_unsafe = 0;
            q->cursor = 0;
            q->free_count = 0;
            q->safe_count = 0;
            q->phase = PH_TRIAL_SCORE;
            return WR_PENDING;
        }
        q->cursor = 0;
        q->tail = 0;
        q->phase = PH_TRIAL_CAP_FORWARD_PREP;
        return WR_PENDING;
    case PH_TRIAL_CAP_FORWARD_PREP:
        cap_forward_prep(q);
        q->cursor++;
        if (q->cursor == g->caps)
        {
            q->head = 0;
            q->phase = PH_TRIAL_CAP_FORWARD;
        }
        return WR_PENDING;
    case PH_TRIAL_CAP_FORWARD:
        if (q->head < q->tail)
            forward_one(g, x, w, &q->head, &q->tail);
        if (q->head == q->tail)
        {
            q->cursor = 0;
            q->tail = 0;
            q->phase = PH_TRIAL_CAP_REVERSE_PREP;
        }
        return WR_PENDING;
    case PH_TRIAL_CAP_REVERSE_PREP:
        cap_reverse_prep(q, w->home, w->home_reps);
        q->cursor++;
        if (q->cursor == g->caps)
        {
            q->head = 0;
            q->phase = PH_TRIAL_CAP_REVERSE;
        }
        return WR_PENDING;
    case PH_TRIAL_CAP_REVERSE:
        if (q->head < q->tail)
            reverse_one(x, w, w->home, w->home_reps, &q->head, &q->tail);
        if (q->head == q->tail)
            q->phase = PH_TRIAL_CHECK;
        return WR_PENDING;
    case PH_TRIAL_SCORE:
    {
        uint32_t reachable = w->free_reps[q->cursor] & w->reached_reps[q->cursor];
        q->free_count = (uint16_t)(q->free_count + __builtin_popcount(reachable));
        q->safe_count =
            (uint16_t)(q->safe_count + __builtin_popcount(reachable & w->home_reps[q->cursor]));
        q->cursor++;
        if (q->cursor < x->representative_words)
            return WR_PENDING;
        q->score = (int)q->free_count;
        if (q->left > 2 && !q->free_count)
        {
            q->score = -1;
            q->phase = PH_TRIAL_FINISH;
        }
        else if (q->trial_unsafe)
        {
            if (!q->safe_count)
            {
                q->score = -1;
                q->phase = PH_TRIAL_FINISH;
            }
            else
            {
                memset(w->scratch, 0, x->words * sizeof(uint32_t));
                q->cursor = 0;
                q->tail = 0;
                q->phase = PH_TRIAL_REPAIR_PREP;
            }
        }
        else
            q->phase = PH_TRIAL_FINISH;
        return WR_PENDING;
    }
    case PH_TRIAL_REPAIR_PREP:
    {
        uint32_t pending = w->free_reps[q->cursor] & w->reached_reps[q->cursor];
        while (pending)
        {
            uint16_t bit = (uint16_t)__builtin_ctz(pending);
            uint16_t ordinal = (uint16_t)(q->cursor * 32u + bit), v = x->representatives[ordinal];

            if (!has(w->scratch, x->node_component[v]))
                add_queue(w->scratch, 0, x->reverse, x->node_component[v], x, w->queue, &q->tail);
            pending &= pending - 1u;
        }
        q->cursor++;
        if (q->cursor == x->representative_words)
        {
            q->head = 0;
            q->phase = PH_TRIAL_REPAIR;
        }
        return WR_PENDING;
    }
    case PH_TRIAL_REPAIR:
        if (q->head < q->tail)
            reverse_one(x, w, w->scratch, 0, &q->head, &q->tail);
        if (q->head == q->tail)
        {
            q->cursor = 0;
            q->phase = PH_TRIAL_REPAIR_CHECK;
        }
        return WR_PENDING;
    case PH_TRIAL_REPAIR_CHECK:
        if ((w->reached[q->cursor] & ~w->home[q->cursor]) & ~w->scratch[q->cursor])
            q->score = -1;
        q->cursor++;
        if (q->score < 0 || q->cursor == x->words)
            q->phase = PH_TRIAL_FINISH;
        return WR_PENDING;
    case PH_TRIAL_FINISH:
        reverse_pair(x, w, q->source, q->trial, 0);
        set_free(w, x, q->source, 1);
        set_free(w, x, q->trial, 1);
        w->partner[q->source] = WR_NONE;
        w->partner[q->trial] = WR_NONE;
        if (q->score >= 0 &&
            (q->score > q->best || (q->score == q->best && choose(&q->state, ++q->ties) == 0)))
        {
            if (q->score > q->best)
                q->ties = 1;
            q->best = q->score;
            q->target = q->trial;
            q->best_unsafe = (uint16_t)q->trial_unsafe;
            memcpy(w->best_reached, w->reached, x->words * sizeof(uint32_t));
            memcpy(w->best_home, w->home, x->words * sizeof(uint32_t));
            memcpy(w->best_reached_reps, w->reached_reps,
                   x->representative_words * sizeof(uint32_t));
            memcpy(w->best_home_reps, w->home_reps, x->representative_words * sizeof(uint32_t));
            memcpy(w->best_caps, w->caps, g->caps);
        }
        q->j++;
        q->phase = q->j == q->limit ? PH_COMMIT : PH_TRIAL_SETUP;
        return WR_PENDING;
    case PH_COMMIT:
        if (q->target == WR_NONE)
            return reject(q, WR_NO_PARTNER);
        w->partner[q->source] = q->target;
        w->partner[q->target] = q->source;
        q->left -= 2;
        set_free(w, x, q->source, 0);
        set_free(w, x, q->target, 0);
        reverse_pair(x, w, q->source, q->target, 1);
        memcpy(w->reached, w->base_reached, x->words * sizeof(uint32_t));
        memcpy(w->home, w->base_home, x->words * sizeof(uint32_t));
        memcpy(w->reached_reps, w->base_reached_reps, x->representative_words * sizeof(uint32_t));
        memcpy(w->home_reps, w->base_home_reps, x->representative_words * sizeof(uint32_t));
        memset(w->caps, 0, g->caps);
        expand_pair_zero(g, x, w, q->source, q->target);
        memcpy(w->base_reached, w->reached, x->words * sizeof(uint32_t));
        memcpy(w->base_home, w->home, x->words * sizeof(uint32_t));
        memcpy(w->base_reached_reps, w->reached_reps, x->representative_words * sizeof(uint32_t));
        memcpy(w->base_home_reps, w->home_reps, x->representative_words * sizeof(uint32_t));
        memcpy(w->reached, w->best_reached, x->words * sizeof(uint32_t));
        memcpy(w->home, w->best_home, x->words * sizeof(uint32_t));
        memcpy(w->reached_reps, w->best_reached_reps, x->representative_words * sizeof(uint32_t));
        memcpy(w->home_reps, w->best_home_reps, x->representative_words * sizeof(uint32_t));
        memcpy(w->caps, w->best_caps, g->caps);
        q->unsafe = q->best_unsafe;
        q->cursor = 0;
        q->count = 0;
        q->phase = q->left ? PH_SELECT : PH_EMIT;
        return WR_PENDING;
    case PH_EMIT:
        if (q->cursor < x->emit_count)
        {
            uint16_t node = x->emit_nodes[q->cursor], r = g->nodes[node].rep;
            uint16_t t = w->partner[r];
            if (t >= g->n || t == r || !g->nodes[t].active || g->nodes[t].rep != t ||
                w->partner[t] != r || !allowed(&g->nodes[r], &g->nodes[t]))
                return reject(q, WR_BAD_PAIR);
            w->candidate[q->cursor].trigger = g->nodes[node].trigger;
            w->candidate[q->cursor].landing = g->nodes[t].id;
            q->cursor++;
        }
        if (q->cursor == x->emit_count)
        {
            q->count = x->emit_count;
            q->phase = PH_VALIDATE_INIT;
        }
        return WR_PENDING;
    case PH_VALIDATE_INIT:
        memset(w->reached, 0, x->words * sizeof(uint32_t));
        memset(w->home, 0, x->words * sizeof(uint32_t));
        memset(w->reached_reps, 0, x->representative_words * sizeof(uint32_t));
        memset(w->home_reps, 0, x->representative_words * sizeof(uint32_t));
        memset(w->caps, 0, g->caps);
        add(w->reached, w->reached_reps, x->forward, x->node_component[g->root], x);
        add(w->home, w->home_reps, x->reverse, x->node_component[g->root], x);
        q->tail = 0;
        enqueue_bits(w->reached, x->words, w->queue, &q->tail);
        q->head = 0;
        q->phase = PH_VALIDATE_FORWARD;
        return WR_PENDING;
    case PH_VALIDATE_FORWARD:
        if (q->head < q->tail)
            forward_one(g, x, w, &q->head, &q->tail);
        if (q->head == q->tail)
            q->phase = PH_VALIDATE_REVERSE_PREP;
        return WR_PENDING;
    case PH_VALIDATE_REVERSE_PREP:
        q->tail = 0;
        enqueue_bits(w->home, x->words, w->queue, &q->tail);
        q->head = 0;
        q->phase = PH_VALIDATE_REVERSE;
        return WR_PENDING;
    case PH_VALIDATE_REVERSE:
        if (q->head < q->tail)
            reverse_one(x, w, w->home, w->home_reps, &q->head, &q->tail);
        if (q->head == q->tail)
            q->phase = PH_VALIDATE_CHECK;
        return WR_PENDING;
    case PH_VALIDATE_CHECK:
        if (unsafe(x, w))
            return reject(q, WR_TRAP);
        if (!grant(g, x, w))
        {
            q->cursor = 0;
            q->phase = PH_VALIDATE_GOALS;
            return WR_PENDING;
        }
        q->cursor = 0;
        q->tail = 0;
        q->phase = PH_VALIDATE_CAP_FORWARD_PREP;
        return WR_PENDING;
    case PH_VALIDATE_CAP_FORWARD_PREP:
        cap_forward_prep(q);
        q->cursor++;
        if (q->cursor == g->caps)
        {
            q->head = 0;
            q->phase = PH_VALIDATE_CAP_FORWARD;
        }
        return WR_PENDING;
    case PH_VALIDATE_CAP_FORWARD:
        if (q->head < q->tail)
            forward_one(g, x, w, &q->head, &q->tail);
        if (q->head == q->tail)
        {
            q->cursor = 0;
            q->tail = 0;
            q->phase = PH_VALIDATE_CAP_REVERSE_PREP;
        }
        return WR_PENDING;
    case PH_VALIDATE_CAP_REVERSE_PREP:
        cap_reverse_prep(q, w->home, w->home_reps);
        q->cursor++;
        if (q->cursor == g->caps)
        {
            q->head = 0;
            q->phase = PH_VALIDATE_CAP_REVERSE;
        }
        return WR_PENDING;
    case PH_VALIDATE_CAP_REVERSE:
        if (q->head < q->tail)
            reverse_one(x, w, w->home, w->home_reps, &q->head, &q->tail);
        if (q->head == q->tail)
            q->phase = PH_VALIDATE_CHECK;
        return WR_PENDING;
    case PH_VALIDATE_GOALS:
        if (q->cursor < g->goal_count && !has(w->reached, x->node_component[g->goals[q->cursor]]))
            return reject(q, WR_OBJECTIVE);
        q->cursor++;
        if (q->cursor >= g->goal_count)
        {
            q->successful_attempt = q->attempt;
            return finish(q, WR_OK);
        }
        return WR_PENDING;
    default:
        return finish(q, WR_BAD_DATA);
    }
}

int wr_begin(struct WrJob *q, const struct WrGraph *g, const struct WrIdentity *id,
             uint16_t retries, struct WrActive *active, struct WrWork *work)
{
    memset(q, 0, sizeof(*q));
    memset(work, 0, sizeof(*work));
    wr_invalidate(active);
    q->graph = g;
    q->index = g->index;
    q->work = work;
    q->active = active;
    q->identity = *id;
    q->seed = id->seed;
    q->trial_cap = 3;
    q->retries = retries;
    q->result = WR_PENDING;
    if (!identityok(g, id))
        return finish(q, WR_BAD_IDENTITY);
    if (!g->index || g->n > WR_MAX_NODES || g->caps > WR_MAX_CAPS ||
        g->index->components > WR_MAX_COMPONENTS || g->index->representative_count > WR_MAX_NODES)
        return finish(q, WR_BAD_DATA);
    if (g->index->representative_count % 2)
        return finish(q, WR_ODD_POOL);
    if (!retries)
        return finish(q, WR_RETRIES);
    q->phase = PH_ATTEMPT_INIT;
    return WR_PENDING;
}
int wr_advance(struct WrJob *q)
{
    int result;
    if (q->phase == PH_DONE)
        return q->result;
    q->steps++;
    result = step_inner(q);
    if (result == WR_OK)
    {
        memcpy(q->active->records, q->work->candidate, q->count * sizeof(struct WrRecord));
        q->active->identity = q->identity;
        q->active->count = q->count;
        q->active->attempt = q->successful_attempt;
        q->active->valid = 1;
    }
    return result;
}
void wr_cancel(struct WrJob *q)
{
    wr_invalidate(q->active);
    finish(q, WR_CANCELLED);
}
int wr_generate(const struct WrGraph *g, const struct WrIdentity *id, uint16_t retries,
                struct WrActive *active, struct WrWork *work, int *last)
{
    struct WrJob job;
    int result = wr_begin(&job, g, id, retries, active, work);
    while (result == WR_PENDING)
        result = wr_advance(&job);
    *last = job.last_rejection ? job.last_rejection : result;
    return result;
}


/* 9. Saved-table restoration skips construction but retains fresh acceptance.
 * Node indexes are meaningful only with the exact data fingerprint. */
size_t wr_table_bytes(const struct WrGraph *g)
{
    return WR_SAVE_BYTES + 2u * g->index->emit_count + 4u;
}

int wr_table_encode(const struct WrGraph *g, const struct WrActive *a,
                    uint8_t *out, size_t size)
{
    uint16_t i, node;
    if (size != wr_table_bytes(g) || !a->valid || !identityok(g, &a->identity)
        || a->count != g->index->emit_count)
        return WR_BAD_IDENTITY;
    for (i = 0; i < a->count; i++) {
        if (!keyeq(a->records[i].trigger, g->nodes[g->index->emit_nodes[i]].trigger))
            return WR_BAD_DATA;
        for (node = 0; node < g->n; node++)
            if (keyeq(g->nodes[node].id, a->records[i].landing)) break;
        if (node == g->n || !g->nodes[node].active || g->nodes[node].rep != node)
            return WR_BAD_PAIR;
        out[WR_SAVE_BYTES + 2u * i] = (uint8_t)node;
        out[WR_SAVE_BYTES + 2u * i + 1] = (uint8_t)(node >> 8);
    }
    if (wr_encode(a, out)) return WR_BAD_IDENTITY;
    put32(out + size - 4, crc32(out, size - 4));
    return WR_OK;
}

int wr_table_begin(struct WrJob *q, const struct WrGraph *g,
                   const uint8_t *save, size_t size,
                   struct WrActive *a, struct WrWork *w)
{
    struct WrIdentity id;
    uint16_t attempt, i, r, t;
    int result;
    wr_invalidate(a);
    /* Leave a terminal, safely cancellable job even on an invalid envelope. */
    memset(q, 0, sizeof(*q));
    q->active = a;
    if (size != wr_table_bytes(g) || wr_decode(g, save, &id, &attempt)
        || attempt >= 8 || crc32(save, size - 4) != get32(save + size - 4))
        return finish(q, WR_BAD_IDENTITY);
    result = wr_begin(q, g, &id, 1, a, w);
    if (result != WR_PENDING) return result;
    q->attempt = q->successful_attempt = attempt;
    q->count = g->index->emit_count;
    for (i = 0; i < g->n; i++) w->partner[i] = WR_NONE;
    for (i = 0; i < g->index->components; i++) w->reverse_head[i] = WR_NONE;
    for (i = 0; i < q->count; i++) {
        r = g->nodes[g->index->emit_nodes[i]].rep;
        t = (uint16_t)(save[WR_SAVE_BYTES + 2u * i]
            | ((uint16_t)save[WR_SAVE_BYTES + 2u * i + 1] << 8));
        if (t >= g->n || t == r || !g->nodes[t].active || g->nodes[t].rep != t
            || !allowed(&g->nodes[r], &g->nodes[t])
            || (w->partner[r] != WR_NONE && w->partner[r] != t))
            return finish(q, WR_BAD_PAIR);
        w->partner[r] = t;
        w->candidate[i].trigger = g->nodes[g->index->emit_nodes[i]].trigger;
        w->candidate[i].landing = g->nodes[t].id;
    }
    for (i = 0; i < g->index->representative_count; i++) {
        r = g->index->representatives[i];
        t = w->partner[r];
        if (t == WR_NONE || w->partner[t] != r) return finish(q, WR_BAD_PAIR);
        if (r < t) reverse_pair(g->index, w, r, t, 1);
    }
    /* A rejected stored table must never fall back to constructing a new one.
     * reject() increments attempt before checking retries. */
    q->retries = 0;
    q->phase = PH_VALIDATE_INIT;
    return WR_PENDING;
}
