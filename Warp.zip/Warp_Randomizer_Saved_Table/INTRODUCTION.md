# A smaller warp randomizer

This project rearranges ordinary event warps in Pokémon Emerald Expansion: a door, cave entrance or staircase can lead somewhere different, while the chosen world remains reproducible from a seed. New worlds are still **generated inside the game**. Python prepares the map description when developing the ROM; it does not generate each player's world.

This is a compact development core, not a finished playable randomizer. It generates in small resumable steps during Birch's introduction, pauses during naming, and finishes on a loading screen if needed. Continue restores the saved table and validates it without reconstructing the world. A red dot at the top right becomes green on success, fades toward white, then disappears. The actual starting contract, progression interactions, safe arrival tiles and a Champion/credits run remain unproven.

Read this file for the reasoning, DOCS.md to follow and install the code, and FUTURE.md for the remaining design choices. These are the only three commentary documents. DOCS.md ends with an eight-lesson tutorial for implementing special transitions, from tracing a single scripted warp to testing dynamic returns and recovery policies.

## What was simplified

The supplied archive contained 372 files. It was both an implementation and a laboratory notebook: successive constructors, optimizations, generated indexes, emulator harnesses, historical patches, duplicated data and many checkpoint reports. Those records explain how the project developed, but they need not all be dependencies of the next implementation.

This edition has **twelve maintained files**:

| File | Purpose |
|---|---|
| INTRODUCTION.md | Goals, history and design rationale |
| DOCS.md | Code tutorial, commands and manual integration edits |
| FUTURE.md | Unfinished behavior and alternative implementations |
| world.json | One frozen graph plus target source signatures |
| build.py | Check that input and turn it into C arrays |
| warp_rando.h | Portable graph, job and validation interface |
| warp_game.h | Engine-facing entry points and intro hooks |
| warp_rando.c | Construction, acceptance, lookup and saved-table codec |
| warp_game.c | Frame budget, Birch indicator, loading and event adapter |
| test.py | Host harness and independent Python acceptance checks |
| target_test.c | Real-engine regression tests, including flash save and timing |
| LICENSE | Retained GPLv3 license text |

`warp_data.h` and `verification.json` are generated outputs, not additional sources to maintain. The package also includes integration.patch, the concrete target edits described in DOCS.md; apply the patch or the manual edits, not both. There is no package manager, third-party Python dependency, experiment include stack or runtime graph index generator.

This is a **pruned and rewritten derivative**. The initial compact revision removed too much useful indexing: its ARM callback could stall for 6.4 seconds. This revision reintegrates the supplied C9/C10 ideas into one implementation: unconditional-region closure, bitsets, representative indexes, incremental traversal and a resumable state machine. Historical experiment includes, scheduler variants and duplicate datasets are not dependencies.

Parsimony means having a small number of understandable concepts, not minimizing every line. There is one generator, one engine adapter, one data compiler and one independent test validator. Keeping the game interface in its own header costs one file but makes ownership clearer. Generated indexes cost ROM space so the game can do less work with its limited CPU.

## What the original external randomizer did

The supplied project's source analysis describes KittyPBoxx's UPR-based Java randomizer as two cooperating halves. The original explanation came from the delivered analysis; a fresh review of the same pinned upstream commits is now recorded in FUTURE.md. It is not a review of today's moving branches.

The external program reads annotated warps, flags, key locations and escape-path information. It treats the world as a graph, then connects entrances while taking account of reachability, disconnected components, return obligations and progression locations. It eventually emits remapping records for the ROM. Its priority system is more elaborate than a shuffled list of destinations.

The modified Speedchoice game supplies the other half: lookup, source normalization, arrival fixes, special travel behavior and script changes for map-randomizer mode. A graph generator does not automatically reproduce those game changes. Porting the Java algorithm to C alone was therefore never enough to make Expansion behave like the original randomizer.

One particularly confusing detail is that a legacy remapping record is keyed by the source door's **vanilla destination**, called its `trigger` here. It is not keyed directly by the door's own address. The adapter must first identify the physical source event, check its signature, and translate it into the reference trigger. This distinction explains why apparently harmless destination mismatches can matter.

## A small vocabulary

An **endpoint** is a physical warp event, identified by map group, map number and warp index. A **representative** is the chosen endpoint for a group: a two-tile doorway may have two physical events but should be randomized as one entrance. An **edge** describes repeatable directed travel between endpoints, commonly walking inside or between map areas. A **capability** is a permanent fact such as having the modeled requirements for Surf. A **rule** grants a capability when all its prerequisites hold.

The **root** is the graph's anchor, currently the reference Oldale endpoint. The **frontier** is the set of reachable representative endpoints that have not yet been paired. The frontier is what lets construction expand into more of the world.

A **coupled pair** means that leaving representative A arrives at B and leaving B arrives at A. It does not mean every walking route around A and B is reversible.

## Why “shuffle the doors” was not enough

### The last usable exit can disappear too soon

Imagine the connected starting region has three unassigned doors. Each is paired with a small room containing only its paired exit. All three pairings are individually reversible, but none introduces another unassigned exit. The constructor has spent its entire frontier while hundreds of entrances remain disconnected.

The historical diagnosis in the attachment found this behavior: progression leaves were favored ahead of regions that could keep construction expanding. Counting raw walking edges did not reliably predict how many distinct unpaired entrances a choice would expose.

The amendment is to **try a pairing and count its actual reachable free representatives**. Reject a choice that consumes the frontier before the pool is finished. Among a few acceptable trials, favor the choice that leaves the largest frontier.

### Reversible door pairs can still form a one-way trap

Suppose a ledge lets the player enter room A from outside. A's randomized exit leads to B, and B's leads back to A. The pair is perfectly coupled, but the player can only circulate between A and B. The ledge cannot be climbed in reverse.

The attachment gives a concrete example involving Sky Pillar F5 and the Slateport shipyard stairs. It reports that this failure could persist even with all modeled conditional travel opened. It was not fixed by casually renaming the Weather Institute or Flash conditions.

The amendment is to track **both reachability from the root and the ability to return to it**. During construction, a temporarily trapped region is allowed only while every reached unsafe vertex still has a route to a free endpoint that could repair it. The next pairing prioritizes that repair, connecting an unsafe reached endpoint toward a place that already has a route home.

This is a construction heuristic, not a proof that every partial layout can be completed. A final, fresh validation decides whether the completed layout is acceptable. Failure starts a new deterministic attempt; it never publishes a partial table.

## The actual algorithm

1. Start with no randomized pairings and no earned capabilities.
2. Follow currently available directed travel from the root. Separately follow reversed travel from the root to discover which places can return.
3. Earn capabilities only from locations that are both reachable and returning. Repeat until no new capability is earned, or stop at the first unsafe stage while constructing.
4. Choose a reached unpaired representative. If the current stage has a return problem, choose from the unsafe region first.
5. Sample up to three distinct compatible partners. Temporarily install each pair, update the graph state, and count the free exits it exposes. Reject exhausted-frontier and unrepairable-trap trials.
6. Commit the best trial, breaking equal scores with the dedicated random generator. Resume from smaller steps inside selection and graph propagation.
7. When the pool is paired, expand groups into sorted remap records and validate the completed pairing from fresh state. The compiler rejects conflicting aliases before building the ROM.
8. Publish only on success. Otherwise restart with a derived seed, up to eight attempts in the game adapter.

The three-trial policy is inherited from the supplied experiment's useful scheduling idea. It is easy to explain and avoids trying every possible partner at every step. It does not produce a uniform sample of all valid worlds, and eight attempts do not guarantee that every input seed succeeds.

“Yield” is an ordinary function return. The code saves a small job structure and the next callback resumes from it. There are no threads or coroutines. The main callback repeatedly advances small steps until its timer budget is used. A step processes one component, one bitset word or one emitted record, with a few bounded whole-model operations. The timer budget is soft: the last step can overrun it. Target measurements are therefore essential.

## What acceptance actually promises

At each modeled capability stage, every reachable endpoint must be able to return to the root with the capabilities available at that stage. Only safe reachable locations can grant new capabilities. All explicit goals must ultimately be reachable. Unknown conditions remain unavailable rather than silently becoming free travel.

This is deliberately strict. It rejects a room that contains its own escape item if entering the room is already unsafe before collecting that item. It can also reject a world with a valid winning route but an optional early trap. This policy is easier to reason about than assuming that players will always choose a safe order.

It is still a statement about an abstraction. Reachable gym doors do not prove beatable battles. Reachable item locations do not prove their scripts run correctly. A node address does not prove a safe landing tile. Permanently blocked unknown edges can conceal real-game routes into trouble. Special transitions left vanilla may change actual reachability in ways the graph does not describe.

The model's Oldale root also does not physically relocate the new player. That starting-sequence mismatch is an explicit integration blocker, not an implicit assumption that the ROM already handles it.

## Saved tables and the archived alternative

This revision stores 532 destination-node indexes beside the identity: 1,124 bytes total, fitting the pinned default target's 1,624-byte SaveBlock3 allowance. Continue validates the saved completed world in about 123–125 ms for the two measured seeds, with no construction attempts. New-game generation still runs during Birch's speech and uses loading if the intro finishes early.

The complete preceding seed-only edition, including its per-load loading screen, is preserved in `archive/per-load-reconstruction.zip`. It is an alternative version, not a runtime dependency. `saved-table.patch` upgrades the preceding compact source folder; `integration.patch` installs this edition's engine hooks into a clean pinned target. Use the instructions in DOCS.md to choose the right patch.

This is local algorithm/save identity 8 (`WR08`). Older saves need an explicit migration, which is not supplied; restoring an archived ROM is not a save converter.

## Verification in this revision

The ordinary host suite passes 18 groups: directed traps, a self-locked capability, nine prerequisites, chained derivations, excluded fixed travel, grouped aliases, conflicting triggers, odd pools, exhausted retries, cancellation and deterministic restart. Twelve bundled-world seeds pass independent Python validation: 0, 1, 2, 3, 7, 17, 42, 63, 255, 256, 65535 and 4294967295. Seeds 3, 42, 63 and 255 require the second attempt.

Both the normal ROM and test ELF build against the pinned target. All seven headless engine groups pass, covering 608 source signatures, actual event-hook calls, flash Continue, cancellation, allocation failure, the real Birch/naming callbacks, indicator completion and both ready and unfinished intro handoffs. The 18 host groups also exercise saved-table round trips and pass with AddressSanitizer and UndefinedBehaviorSanitizer, including an exhaustive comparison of the compiled unconditional closures with ordinary node walks.

New-game construction still takes roughly 8.6/12.2 emulated seconds for the measured seeds when performed on a loading screen; Continue now takes about 0.125 seconds instead. The longest measured loading callback is about 11.5 ms. During the measured Birch run, callbacks that advance generation stay below 9.6 ms; a roughly 20.4 ms naming-return scene callback advances no generation because the busy-frame check skips it. Background generation uses about 41 seconds of active intro frames for seed 0, plus naming/transition pauses. Read DOCS.md for the exact measurements and their limits.

Historical 1,024-seed sweeps do not transfer automatically. Neither host agreement nor controlled engine tests prove a physical-hardware frame bound, safe landings, or a Champion/credits run.

## Attribution and frozen inputs

The retained graph has 879 physical nodes, 512 active representatives, 1,394 fixed/conditional edges and 14 capability rules. The 608 participating physical sources expand into 532 unique trigger records in the tested worlds. Counts differ because grouped endpoints and shared triggers are different concepts.

The world model and source signatures are consolidated from `data/reference-normalized.json` and `data/target-source-routes.h` in the supplied archive. The target map counts come from its corresponding Expansion header. Available human-readable node labels are retained from its raw Warps.json. Source signatures and map counts now participate in the same SHA-256 input identity as the graph.

The supplied provenance pins were:

| Component | Commit |
|---|---|
| KittyPBoxx/upr-speedchoice-ex-gen9 | 5abfca86134872dbb3c54fa48e5920b6549cfb69 |
| KittyPBoxx/pokeemerald-ex-speedchoice-maprando-gen9 | f539267677ec3686c7f22bae2a63dc6f1a5267e9 |
| KittyPBoxx/Emerald-Ex-Map-Rando | f0966a668d3e7a7e937a519365cb1391d4a174a4 |
| rh-hideout/pokeemerald-expansion, expansion/1.17.0 | e8bd1cd7b03fc032ea37e3ecd38b379b5d01a1e7 |

Credit belongs to KittyPBoxx and Universal Pokémon Randomizer contributors for the reference design/data; RHH and pret contributors for the target engine; and the authors of the supplied project for the retained implementation and investigations. The derivative code is supplied under the project's GPLv3 terms; retain LICENSE and these credits. No ROM is included.


## First arrival-compatibility slice

Littleroot remains the vanilla starting area: its 13 event warps are excluded from the pool. Oldale remains randomized. The game still starts with the normal opening; the graph's Oldale root does not teleport the player or grant a starter, badges, HMs or story flags.

The four Hoenn Elite Four rooms now have a deliberately small compatibility rule while a validated randomizer table is active. Their north and south doorways remain passable, their automatic six-step entrance sequence is suppressed, and arrival through the north event starts one tile inside the room. This prevents the ordinary randomized-door model from inheriting the rooms' vanilla one-way entrance assumptions. The rule also runs when a saved map is loaded, without moving the saved player position. Trainer battles and defeat flags remain intact. Passing through these rooms without battling is permitted by this rule; Champion and credits completion are still unproven.

This is a first, specific application of the upstream contingency audit, not a port of its plot-removal preset. It adds two small functions to the existing engine adapter and two engine hook calls, with no new runtime source file or save bytes. The saved-table format and generated pairings are unchanged. The old per-load implementation remains archived.


## Progression checkpoint

The opening and Cut now have stronger target checks: real new-game initialization, all 13 Littleroot events through the engine hook, and the actual Cut script command with badge/move/egg combinations. All 11 target groups and 18 host groups pass. This establishes specific prerequisites and exclusions, not a completed player walkthrough.

The host report now includes outward and return graph routes to Roxanne and the Cut giver for each sampled seed, before Cut is granted. Seed 0 needs no modeled HM capabilities to reach either provider. Use these routes as a concrete itinerary for testing the reference graph against real doors, terrain and interactions. DOCS.md explains how to print them and distinguish graph evidence from gameplay evidence. No runtime complexity or save storage was added for this checkpoint.


## Compatibility port: current gameplay rule

We are now using KittyPBoxx's map-randomizer changes as a documented compatibility specification for Expansion 1.17.0. The generator and saved-table system stay compact; FUTURE.md records implemented, planned and omitted gameplay behavior. The Gym access port and early plotless reward chain join the existing Elite Four arrival rule.

Before Champion completion, entering or loading Petalburg Gym prepares Norman for his first battle if he has not been defeated, or for his post-battle dialogue if he has. The normal four-earlier-badge wait and Wally's in-Gym tutorial are bypassed. His canonical target position is restored, including when an older saved map contains his tutorial position. The rule does not award a badge or Surf, reset victories, or replace his postgame rematch script. Entering/loading Mauville Gym keeps Wattson visible even if Norman's reward previously hid him. Battles remain those of 1.17.0. The early plotless reward additions described below now augment three Gym reward scripts.

Littleroot and the starter opening remain vanilla; Oldale and other supported Hoenn warps remain randomized. This is still a partial compatibility port: the later Dive/Space Center/Sootopolis reward chain, transport policy and recovery tools are listed but not enabled. The current graph remains the inherited reference abstraction and is not a completion guarantee.


## Early plotless rewards now ported

Roxanne's reward now supplies Steven's Letter and enables the PokéNav/Match Call setup in randomizer mode, bypassing the corresponding Devon errand sequence. If the Letter cannot fit, the reward reports the normal bag-full message and can be retried. It does not duplicate an owned Letter or replace one already delivered. A short message explains the new reward; Rock Tomb still follows the normal item-reward path.

The skipped Wally Gym tutorial now also skips the early Woods grunt/employee encounter. After Wattson's badge, the Meteor Falls villain scene and Mt. Chimney confrontation are bypassed and the cable-car blockers removed. After either Wattson's or Norman's badge, the Weather Institute/Route119 Aqua blockade is cleared. Neither helper awards an HM, Castform or another Gym badge. Later story states, Briney's travel and a completed Rusturf reunion are preserved when earlier rewards are revisited.

These are intentional story skips, not merely arrival corrections. The larger compatibility inventory remains partial, and the reference graph still needs gameplay verification. Save storage and generated pairings are unchanged. For testing this expanded ruleset, start a fresh game: an older save can load, but already-completed one-time reward scripts are not replayed automatically.
